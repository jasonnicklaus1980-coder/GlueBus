#!/usr/bin/env python3
"""Generate the DJ Scratch MPC screen skin (same skin pipeline and MPC rules as the SP1200 skin).

Three pages (MPC screen tabs):
  SCRATCH  a turntable: the big platter is a touch zone bound to PLATTER (drag on it, or turn Q-Link 1), a rotating record label
           follows it; keys HOLD / AUTO / BACKSPIN / CHOP / FADER (+ Bypass); THROW, INERTIA, RELEASE, OUTPUT; a status display
  GROOVE   LOOP (key + note value + tempo) and TRANSFORMER (key + rate, open %, pattern); a printed legend of the MIDI note map
  SETUP    RETURN mode + catch-up speed, backspin speed / time, chop length, fader time
Every control is bound to "Parameter N"; the indices come from the built plugin (DS_ParamKey), so run `make native` first.
MPC rules (proven on an MPC X with the SP1200 skin): square filmstrip frames, 128 frames, numFrames = last frame index (127),
pieces at most 84 px wide, the knob fully inside its parent box.  Requires Pillow.
Usage: python3 tools/make_skin.py [preview-dir]
"""
import ctypes, json, math, os, random, shutil, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIN_NAME = "ScratchLab - VST - DJ Scratch"          # MPC looks for "<manufacturer> - VST - <plugin name>"
SKIN_DIR = os.path.join(ROOT, "mpc", "skin", SKIN_NAME)
OUT = os.path.join(SKIN_DIR, "Plugin Skins")
W, H = 1280, 628
FRAMES, NUMFRAMES, SS = 128, 127, 4

FONT_DIRS = ["/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu", "/Library/Fonts", "C:/Windows/Fonts"]
def font(size, name="DejaVuSans-Bold.ttf"):
    for d in FONT_DIRS:
        p = os.path.join(d, name)
        if os.path.exists(p): return ImageFont.truetype(p, size)
    return ImageFont.load_default()

# ---------- palette (an SL-1200-type deck: matte black, brushed aluminium, amber lamp) ----------
BODY    = (22, 23, 26)           # graphite panel
PLINTH  = (14, 14, 16)           # matte black plinth
STRIP   = (190, 194, 200)        # brushed aluminium top strip
INK     = (18, 18, 20)
PRINT   = (232, 233, 236)
PRINT_DIM = (150, 154, 164)
RULE    = (168, 172, 180)        # silver section rules
AMBER   = (255, 176, 48)
KEYFACE, KEYFACE_DN = (40, 41, 46), (28, 29, 33)
RED     = (226, 48, 44)
LCD_BG  = (14, 16, 18)
LCD_TXT = (255, 176, 48)
FOCUS_COL, LCD_COL, VALUE_COL = "ffffb030", "ffffb030", "ffffffff"

def rgba(c, a=255): return (c[0], c[1], c[2], a)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def text_c(d, cx, cy, s, f, fill):
    b = d.textbbox((0, 0), s, font=f); d.text((cx - (b[2] - b[0]) / 2 - b[0], cy - (b[3] - b[1]) / 2 - b[1]), s, font=f, fill=fill)
def spaced(s, n=1): return (" " * n).join(s)

# ---------- key images ----------
KEY_W, KEY_H = 64, 66
def key_image(on, red=False):
    """A black rubber square key with a silver bezel; an amber LED bar above it lights when on (red=True keeps the name used by the layout)."""
    s = SS; w, h = KEY_W, KEY_H
    im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx = w * s / 2; kw, kt, kb = 19 * s, 16 * s, 46 * s
    lw, lh, ly = 14 * s, 2.5 * s, 7 * s                          # LED bar
    if on:
        g = Image.new("RGBA", im.size, (0, 0, 0, 0))
        ImageDraw.Draw(g).rounded_rectangle([cx - lw - 4 * s, ly - 6 * s, cx + lw + 4 * s, ly + 6 * s], radius=5 * s, fill=(255, 150, 20, 150))
        im.alpha_composite(g.filter(ImageFilter.GaussianBlur(3 * s))); d = ImageDraw.Draw(im)
    d.rounded_rectangle([cx - lw, ly - lh, cx + lw, ly + lh], radius=2 * s, fill=rgba(AMBER if on else (84, 60, 30)))
    d.rounded_rectangle([cx - kw + 2 * s, kt + 3 * s, cx + kw + 2 * s, kb + 3 * s], radius=3 * s, fill=(0, 0, 0, 120))
    off = 2 * s if on else 0
    face = KEYFACE_DN if on else KEYFACE
    d.rounded_rectangle([cx - kw - 2 * s, kt + off - 2 * s, cx + kw + 2 * s, kb + off + 2 * s], radius=4 * s, fill=rgba((150, 154, 162)))     # silver bezel
    d.rounded_rectangle([cx - kw, kt + off, cx + kw, kb + off], radius=3 * s, fill=rgba(face))
    for k in range(6):                                              # rubber ribbing
        yy = kt + off + (5 + k * 4) * s
        d.line([cx - kw + 5 * s, yy, cx + kw - 5 * s, yy], fill=rgba(mix(face, (0, 0, 0), 0.35)), width=s)
    d.line([cx - kw + 3 * s, kt + off + s, cx + kw - 3 * s, kt + off + s], fill=rgba(mix(face, (255, 255, 255), 0.18)), width=s)
    return im.resize((w, h), Image.LANCZOS)

# ---------- the pitch-fader style output slider: 2 stacked 84 px pieces of one drawing (SP1200 skin's proven filmstrip format) ----------
FW, FHT, FY = 76, 168, 24
TRAVEL0, TRAVEL1 = 24, FHT - 24
def fader_frame(t):
    s = SS; w, h = FW * s, FHT * s
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx = w / 2
    d.rounded_rectangle([cx - 4 * s, TRAVEL0 * s - 12 * s, cx + 4 * s, TRAVEL1 * s + 12 * s], radius=4 * s, fill=rgba((4, 4, 5)))
    d.line([cx, TRAVEL0 * s - 8 * s, cx, TRAVEL1 * s + 8 * s], fill=rgba((52, 53, 58)), width=2 * s)
    cy = (TRAVEL1 + (TRAVEL0 - TRAVEL1) * t) * s
    cw, ch = 28 * s, 20 * s
    sh = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([cx - cw + 2 * s, cy - ch + 6 * s, cx + cw + 2 * s, cy + ch + 6 * s], radius=4 * s, fill=(0, 0, 0, 160))
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(4 * s))); d = ImageDraw.Draw(im)
    cap = Image.new("RGBA", (w, h), (0, 0, 0, 0)); cd = ImageDraw.Draw(cap)
    for yy in range(int(cy - ch), int(cy + ch) + 1):                 # grey ridged cap, lit from above
        k = (yy - (cy - ch)) / (2 * ch)
        col = mix((120, 123, 130), (46, 47, 52), k)
        if int((yy - (cy - ch)) / (3 * s)) % 2 == 1: col = mix(col, (0, 0, 0), 0.22)
        cd.line([cx - cw, yy, cx + cw, yy], fill=rgba(col))
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([cx - cw, cy - ch, cx + cw, cy + ch], radius=4 * s, fill=255)
    im.paste(cap, (0, 0), mask); d = ImageDraw.Draw(im)
    d.rounded_rectangle([cx - cw, cy - ch, cx + cw, cy + ch], radius=4 * s, outline=rgba((170, 174, 182)), width=s)
    d.rectangle([cx - cw + 3 * s, cy - 1.5 * s, cx + cw - 3 * s, cy + 1.5 * s], fill=rgba(PRINT))
    return im.resize((FW, FHT), Image.LANCZOS)
FPIECE, NFP = 84, 2
def fader_pieces():
    strips = [Image.new("RGBA", (FPIECE, FPIECE * FRAMES), (0, 0, 0, 0)) for _ in range(NFP)]
    x0 = (FPIECE - FW) // 2
    for f in range(FRAMES):
        fr = fader_frame(f / (FRAMES - 1))
        for k in range(NFP): strips[k].paste(fr.crop((0, k * FPIECE, FW, (k + 1) * FPIECE)), (x0, f * FPIECE))
    return strips

# ---------- the rotating record label (4 filmstrips of 84 px: a 2 x 2 tiling of one 168 px drawing) ----------
REC, PIECE = 168, 84
def record_frame(angle):
    s = 3; n = REC * s; c = n / 2
    im = Image.new("RGBA", (n, n), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    R = 82 * s
    d.ellipse([c - R, c - R, c + R, c + R], fill=rgba((18, 18, 20)))
    r = 76 * s                                              # label: three unequal sectors so the rotation reads
    box = [c - r, c - r, c + r, c + r]
    d.pieslice(box, angle - 90, angle + 40, fill=rgba(AMBER))
    d.pieslice(box, angle + 40, angle + 150, fill=rgba((236, 230, 214)))
    d.pieslice(box, angle + 150, angle + 270, fill=rgba((52, 56, 70)))
    d.ellipse([c - 40 * s, c - 40 * s, c + 40 * s, c + 40 * s], fill=rgba((24, 26, 30)))      # inner disc
    a = math.radians(angle)
    for k, (rr, wd) in enumerate([(62, 5)]):
        x, y = c + rr * s * math.sin(a), c - rr * s * math.cos(a)
        d.ellipse([x - wd * s, y - wd * s, x + wd * s, y + wd * s], fill=rgba((255, 255, 255)))   # marker dot
    # small text on the inner disc, rotated with the record
    t = Image.new("RGBA", (80 * s, 24 * s), (0, 0, 0, 0)); td = ImageDraw.Draw(t)
    text_c(td, 40 * s, 12 * s, "DJ SCRATCH", font(10 * s), rgba(AMBER)); t = t.rotate(-angle, resample=Image.BICUBIC, expand=True)
    im.alpha_composite(t, (int(c - t.size[0] / 2), int(c - t.size[1] / 2)))
    d.ellipse([c - 5 * s, c - 5 * s, c + 5 * s, c + 5 * s], fill=rgba((200, 200, 205)))       # spindle
    d.ellipse([c - 2 * s, c - 2 * s, c + 2 * s, c + 2 * s], fill=rgba((60, 60, 66)))
    return im.resize((REC, REC), Image.LANCZOS)

def record_strips():
    strips = [Image.new("RGBA", (PIECE, PIECE * FRAMES), (0, 0, 0, 0)) for _ in range(4)]
    for f in range(FRAMES):
        fr = record_frame((f / (FRAMES - 1) - 0.5) * 540.0)      # PLATTER 0..1 = -270 .. +270 degrees
        for k in range(4):
            gx, gy = k % 2, k // 2
            strips[k].paste(fr.crop((gx * PIECE, gy * PIECE, gx * PIECE + PIECE, gy * PIECE + PIECE)), (0, f * PIECE))
    return strips

# ---------- TUI.json (same schema as the SP1200 / GlueBus skins) ----------
NOREMAP = {"version": 1, "map": []}
def bounds(b, focus="No", show="Show", visible="Always"):
    return {"version": 2, "acceptsHWFocus": focus, "showWhenDataModelInvalid": show, "whenVisible": visible,
            "boundsType": "Absolute", "bounds": " ".join(str(int(v)) for v in b), "additionalInvalidatingHandles": []}
def comp(name, typ, data, b, remap=None):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": typ, "data": data},
            "handle remapping": remap or NOREMAP, "bounds": b}
def action(on, handler, extra=""):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": "" if handler == "Show Overlay" else "Data",
            "additionalData": extra, "handle remapping": NOREMAP}
def bgdata(col="0"): return {"version": 1, "focussed": {"version": 1, "colour": col, "image": ""}, "unfocussed": {"version": 1, "colour": col, "image": ""}}
def definition(actions, parts, bgcol="0", ignore=False):
    return {"version": 4, "actions": actions, "backgroundData": bgdata(bgcol), "ignoreMousePresses": ignore,
            "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True, "componentsData": parts}
def label(kind, h, colour, b, case="Original", name=None):
    return comp(name or kind, "Label", {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": "Titillium Web", "style": "SemiBold", "height": float(h)},
                "colour": colour, "justification": "horizontallyCentred verticallyCentred", "case": case}, "type": kind, "handleName": "Data"}, bounds(b))
def focus(b):
    return comp("Focus", "Focus", {"version": 1, "backgroundColour": "00000000", "outlineColour": FOCUS_COL, "backgroundInset": 2.0, "outlineThickness": 2.0},
                bounds(b, visible="WhenFocussed"))

# ---------- parameter indices from the built plugin ----------
LIB = os.path.join(ROOT, "build", "native", "djscratch.so")
def load_keys():
    lib = ctypes.CDLL(LIB)
    lib.DS_ParamKey.restype = ctypes.c_char_p; lib.DS_ParamKey.argtypes = [ctypes.c_int]
    lib.DS_ParamCount.restype = ctypes.c_int
    return {lib.DS_ParamKey(i).decode(): i for i in range(lib.DS_ParamCount())}
P = load_keys()

# ---------- layout ----------
TABS = ["SCRATCH", "GROOVE", "SETUP"]
BG_ITEMS = {t: [] for t in TABS}
PLACED = {t: [] for t in TABS}
DEFS, IMAGES = {}, {}
def img(name, im): IMAGES[name] = im; return name
def defn(key, value): DEFS.setdefault(key, value); return key
def place(tab, name, dkey, param, x, y, w, h, kind, extra=None, touch=True):
    PLACED[tab].append(dict(name=name, dkey=dkey, param=param, x=x, y=y, w=w, h=h, kind=kind, extra=extra, touch=touch))

DRAG = "ds_drag.png"
def drag_strip(sq=16): return Image.new("RGBA", (sq, sq * FRAMES), (0, 0, 0, 0))
CTRL = lambda: [action("Mouse Down", "Q-Link"), action("Double Click", "Show Overlay", "knob overlay"), action("Enter Pressed", "Show Overlay", "knob overlay")]
def drag_knob(w, h, orient="Vertical"):
    img(DRAG, drag_strip())
    return comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": DRAG, "numFrames": NUMFRAMES, "invert": False,
                "dragOrientation": orient, "handleName": "Data"}, bounds((0, 0, w, h)))
def d_box(w, h, fs=17):
    key = f"dsBox{w}x{h}_{fs}"
    return defn(key, definition(CTRL(), [drag_knob(w, h), label("Value", fs, LCD_COL, (0, 0, w, h), case="Upper Case"), focus((0, 0, w, h))]))
def d_text(w, h, fs, col=LCD_COL):
    return defn(f"dsText{w}x{h}_{fs}", definition([], [label("Value", fs, col, (0, 0, w, h))], ignore=True))
def d_zone(w, h):
    return defn(f"dsZone{w}x{h}", definition([action("Mouse Down", "Q-Link")], [drag_knob(w, h)]))
def d_key(key, i, n, red_group=False):
    pass

SLX, SLY, SLW = 1150, 248, 100
SLH = FY + FHT
def slider(tab, name, key, x, y):
    place(tab, name, "dsSlider", P[key], x, y, SLW, SLH, "slider", key)

def section(tab, x0, x1, y, title): BG_ITEMS[tab].append(("section", x0, x1, y, title))
def box(tab, name, key, x, y, w=186, h=44, caption=None, fs=17):
    place(tab, name, d_box(w, h, fs), P[key], x, y, w, h, "box")
    BG_ITEMS[tab].append(("lcd", x, y, w, h, caption))
def text(tab, name, key, x, y, w, h, fs=15):
    place(tab, name, d_text(w, h, fs), P[key], x, y, w, h, "text", fs, touch=False)
def keycap(tab, name, key, x, y, cap, red=True):
    place(tab, name, "dsRedKey" if red else "dsKey", P[key], x, y, KEY_W, KEY_H, "redkey")
    BG_ITEMS[tab].append(("cap", x + KEY_W / 2, y + KEY_H + 10, cap))

# ================================================================= SCRATCH page
T = "SCRATCH"
PCX, PCY = 262, 336                                    # platter centre
for k, st in enumerate(record_strips()): img(f"ds_record{k}.png", st)
rknob = lambda k: comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": f"ds_record{k}.png", "numFrames": NUMFRAMES,
                       "invert": False, "dragOrientation": "Vertical", "handleName": "Data"}, bounds(((k % 2) * PIECE, (k // 2) * PIECE, PIECE, PIECE)))
defn("dsPlatter", definition([action("Mouse Down", "Q-Link")], [rknob(k) for k in range(4)]))
place(T, "Scratch Zone", d_zone(500, 520), P["platter"], 50, 66, 500, 520, "zone")
place(T, "Platter", "dsPlatter", P["platter"], PCX - REC // 2, PCY - REC // 2, REC, REC, "platter")

section(T, 620, 1256, 54, "Record")
KX = [620 + i * 78 for i in range(8)]
keycap(T, "Hold", "hold", KX[0], 92, "HOLD")
keycap(T, "Auto Grab", "auto", KX[1], 92, "AUTO")
keycap(T, "Backspin", "backspin", KX[2], 92, "BACKSPIN")
keycap(T, "Chop", "chop", KX[3], 92, "CHOP")
keycap(T, "Fader", "fader", KX[4], 92, "FADER")
keycap(T, "Loop", "loop", KX[5], 92, "LOOP")
keycap(T, "Transformer", "tform", KX[6], 92, "TRANSFORM")
keycap(T, "Bypass", "bypass", KX[7], 92, "BYPASS")
section(T, 620, 1256, 214, "Platter")
box(T, "Throw", "throw", 620, 280, caption="Throw")
box(T, "Inertia", "inertia", 830, 280, caption="Inertia")
box(T, "Auto Release", "release", 620, 370, caption="Auto Release")
for k, st in enumerate(fader_pieces()): img(f"ds_fader{k}.png", st)
fknob = lambda k: comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": f"ds_fader{k}.png", "numFrames": NUMFRAMES,
                       "invert": False, "dragOrientation": "Vertical", "handleName": "Data"}, bounds(((SLW - FPIECE) // 2, FY + k * FPIECE, FPIECE, FPIECE)))
defn("dsSlider", definition(CTRL(), [focus((0, 0, SLW, SLH))] + [fknob(k) for k in range(NFP)] + [
     label("Value", 14, VALUE_COL, (0, 0, SLW, 22), case="Upper Case")]))
slider(T, "Output", "output", SLX, SLY)
section(T, 620, 1256, 440, "Status")
BG_ITEMS[T].append(("lcd", 620, 486, 636, 56, None))
text(T, "Status", "info", 626, 490, 624, 48, 20)

# ================================================================= GROOVE page
T = "GROOVE"
section(T, 24, 620, 54, "Loop  (repeats the last note value)")
keycap(T, "Loop", "loop", 24, 92, "LOOP")
box(T, "Loop Length", "looplen", 120, 120, caption="Note Value")
box(T, "Tempo", "bpm", 326, 120, caption="Tempo (Host = follow MPC)")
section(T, 660, 1256, 54, "Transformer  (tempo-synced gate)")
keycap(T, "Transformer", "tform", 660, 92, "ON")
box(T, "Gate Rate", "trate", 756, 120, w=150, caption="Rate")
box(T, "Gate Open", "tduty", 920, 120, w=150, caption="Open")
box(T, "Gate Pattern", "tpat", 1084, 120, w=172, caption="Pattern")
section(T, 24, 620, 230, "Play it from notes  (any octave, hold)")
BG_ITEMS[T].append(("legend", 24, 276, [
    "C 1/32     C# 1/16T     D 1/16",
    "D# 1/8T    E 1/8        F 1/4T",
    "F# 1/4     G 1/2        G# 1 bar",
    "A backspin    A# chop    B transformer on/off"]))
section(T, 660, 1256, 230, "Platter")
box(T, "Throw", "throw", 660, 296, caption="Throw")
box(T, "Inertia", "inertia", 865, 296, caption="Inertia")
section(T, 24, 1256, 406, "Status")
BG_ITEMS[T].append(("lcd", 24, 450, 1232, 64, None))
text(T, "Status", "info", 32, 460, 1216, 44, 20)

# ================================================================= SETUP page
T = "SETUP"
section(T, 24, 620, 54, "Return")
box(T, "Return", "return", 24, 120, caption="Return")
box(T, "Catch-up Speed", "catch", 229, 120, caption="Catch-up Speed")
section(T, 660, 1256, 54, "Backspin")
box(T, "Spin Speed", "spinspeed", 660, 120, caption="Spin Speed")
box(T, "Spin Time", "spintime", 865, 120, caption="Spin Time")
section(T, 24, 620, 230, "Fader")
box(T, "Chop Length", "chopms", 24, 296, caption="Chop Length")
box(T, "Fader Time", "cutms", 229, 296, caption="Fader Time")
section(T, 660, 1256, 230, "Platter")
box(T, "Throw", "throw", 660, 296, caption="Throw")
box(T, "Inertia", "inertia", 865, 296, caption="Inertia")
section(T, 24, 1256, 406, "Status")
BG_ITEMS[T].append(("lcd", 24, 450, 1232, 64, None))
text(T, "Status", "info", 32, 460, 1216, 44, 20)

QL = {
    "SCRATCH": ["platter", "hold", "backspin", "chop", "fader", "loop", "tform", "looplen", "trate", "throw", "inertia", "bypass"],
    "GROOVE": ["loop", "looplen", "bpm", "tform", "trate", "tduty", "tpat", "hold", "backspin", "chop", "fader", "output"],
    "SETUP": ["return", "catch", "spinspeed", "spintime", "chopms", "cutms", "throw", "inertia", "release", "output", "platter", "auto"],
}

# ---------- backgrounds ----------
def brushed(w, h, base, seed, amp=5, vertical=False):
    random.seed(seed)
    im = Image.new("RGB", (w, h), base); d = ImageDraw.Draw(im)
    for i in range(h if not vertical else w):
        n = random.randint(-amp, amp); c = (base[0] + n, base[1] + n, base[2] + n)
        if vertical: d.line([i, 0, i, h], fill=c)
        else: d.line([0, i, w, i], fill=c)
    return im

def panel_bg(title_right):
    random.seed(7)
    im = Image.new("RGB", (W, H), BODY); px = im.load()
    for y in range(H):
        for x in range(W):
            n = random.randint(-2, 2); px[x, y] = (BODY[0] + n, BODY[1] + n, BODY[2] + n)
    d = ImageDraw.Draw(im)
    for (y0, y1) in ((0, 40), (H - 26, H)):                               # brushed aluminium strips
        strip = brushed(W, y1 - y0, STRIP, 5 + y0, amp=6)
        im.paste(strip, (0, y0))
    d = ImageDraw.Draw(im)
    d.line([0, 40, W, 40], fill=(90, 92, 98), width=2); d.line([0, H - 26, W, H - 26], fill=(90, 92, 98), width=2)
    d.line([0, 41, W, 41], fill=(230, 232, 236), width=1)
    d.text((24, 6), "DJ SCRATCH", font=font(24), fill=INK)
    d.text((196, 15), spaced("QUARTZ  DIRECT  DRIVE  TURNTABLE", 2), font=font(9), fill=INK)
    tw = d.textlength(spaced(title_right), font=font(13)); d.text((W - 24 - tw, 13), spaced(title_right), font=font(13), fill=INK)
    d.text((24, H - 20), "ScratchLab", font=font(12, "DejaVuSans.ttf"), fill=INK)
    return im, d

def turntable(im):
    """Matte black plinth with a silver bevel, aluminium platter with strobe dots, slipmat, vinyl, tonearm and a strobe lamp.
    The rotating label (a filmstrip) sits in the middle."""
    d = ImageDraw.Draw(im)
    x0, y0, x1, y1 = 30, 56, 570, 598
    d.rounded_rectangle([x0 - 3, y0 - 3, x1 + 3, y1 + 3], radius=14, fill=(150, 154, 162))                # silver edge
    d.rounded_rectangle([x0 - 1, y0 - 1, x1 + 1, y1 + 1], radius=12, fill=(60, 62, 68))
    top = brushed(x1 - x0, y1 - y0, PLINTH, 21, amp=3)                                                   # matte black, fine grain
    mask = Image.new("L", top.size, 0); ImageDraw.Draw(mask).rounded_rectangle([0, 0, top.size[0] - 1, top.size[1] - 1], radius=11, fill=255)
    im.paste(top, (x0, y0), mask); d = ImageDraw.Draw(im)
    S = 3; N = 480; n = N * S; c = n / 2
    pl = Image.new("RGBA", (n, n), (0, 0, 0, 0)); pd = ImageDraw.Draw(pl)
    R = 224 * S
    pd.ellipse([c - R - 7 * S, c - R - 5 * S, c + R + 7 * S, c + R + 9 * S], fill=(0, 0, 0, 150))         # shadow
    for k in range(int(R / S), int(R / S) - 30, -1):                                                      # aluminium ring: radial light falloff
        t = (int(R / S) - k) / 30.0; col = mix((196, 200, 208), (120, 124, 132), t)
        pd.ellipse([c - k * S, c - k * S, c + k * S, c + k * S], fill=rgba(col))
    pd.ellipse([c - 194 * S, c - 194 * S, c + 194 * S, c + 194 * S], fill=rgba((84, 87, 94)))
    for k, (rr, cnt, ln) in enumerate([(216, 192, 5), (207, 160, 3)]):                                    # strobe dot rows (two rings)
        for j in range(cnt):
            a = 2 * math.pi * j / cnt; x, y = c + rr * S * math.cos(a), c + rr * S * math.sin(a)
            rx, ry = ln * S * 0.5, 1.1 * S
            pd.ellipse([x - 1.4 * S, y - 1.4 * S, x + 1.4 * S, y + 1.4 * S], fill=rgba((24, 25, 28)))
    M = 190 * S
    pd.ellipse([c - M, c - M, c + M, c + M], fill=rgba((58, 59, 64)))                                     # slipmat
    random.seed(4)
    for rr in range(186, 100, -5):
        g = random.randint(46, 66); pd.ellipse([c - rr * S, c - rr * S, c + rr * S, c + rr * S], outline=rgba((g, g, g + 3)), width=1)
    V = 178 * S
    pd.ellipse([c - V - 2 * S, c - V - 2 * S, c + V + 2 * S, c + V + 2 * S], fill=rgba((6, 6, 7)))
    pd.ellipse([c - V, c - V, c + V, c + V], fill=rgba((14, 14, 16)))                                     # vinyl
    r = V - 4 * S
    while r > 86 * S:
        g = random.randint(20, 36); pd.ellipse([c - r, c - r, c + r, c + r], outline=rgba((g, g, g + 2)), width=1); r -= random.choice([2, 3, 4]) * S // 2 or 1
    sheen = Image.new("RGBA", (n, n), (0, 0, 0, 0)); sd = ImageDraw.Draw(sheen)
    for a0 in (-62, 118): sd.pieslice([c - V, c - V, c + V, c + V], a0, a0 + 26, fill=(255, 255, 255, 36))
    sheen = sheen.filter(ImageFilter.GaussianBlur(10 * S))
    hole = Image.new("L", (n, n), 0); ImageDraw.Draw(hole).ellipse([c - V, c - V, c + V, c + V], fill=255)
    sheen.putalpha(Image.composite(sheen.getchannel("A"), Image.new("L", (n, n), 0), hole)); pl.alpha_composite(sheen)
    pl = pl.resize((N, N), Image.LANCZOS)
    im.paste(pl, (PCX - N // 2, PCY - N // 2), pl)
    d = ImageDraw.Draw(im)
    d.ellipse([PCX - 86, PCY - 86, PCX + 86, PCY + 86], fill=(12, 12, 14))                                # under the label
    # tonearm at rest on the right: counterweight, pivot base, tube, headshell, rest
    ax, ay = 536, 124
    d.rounded_rectangle([ax - 14, ay - 62, ax + 14, ay - 18], radius=6, fill=(70, 72, 78), outline=(150, 154, 162), width=2)     # counterweight
    for k in range(3): d.line([ax - 12, ay - 52 + k * 11, ax + 12, ay - 52 + k * 11], fill=(40, 41, 46), width=1)
    d.ellipse([ax - 30, ay - 30, ax + 30, ay + 30], fill=(40, 41, 46), outline=(150, 154, 162), width=3)                          # pivot base
    d.ellipse([ax - 20, ay - 20, ax + 20, ay + 20], fill=(104, 107, 114)); d.ellipse([ax - 9, ay - 9, ax + 9, ay + 9], fill=(30, 31, 34))
    d.line([ax, ay + 10, ax, 404], fill=(30, 31, 34), width=10); d.line([ax - 1, ay + 10, ax - 1, 404], fill=(176, 180, 188), width=4)    # tube + highlight
    d.polygon([(ax - 12, 400), (ax + 12, 400), (ax + 9, 436), (ax - 9, 436)], fill=(46, 47, 52), outline=(150, 154, 162))            # headshell
    d.rectangle([ax - 4, 436, ax + 4, 446], fill=(190, 192, 198))                                                                   # cartridge
    d.rounded_rectangle([ax - 16, 450, ax + 16, 470], radius=4, fill=(60, 62, 68), outline=(150, 154, 162), width=1)                 # arm rest
    # strobe lamp, bottom right, with its glow
    lx, ly = 536, 560
    g = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(g).ellipse([lx - 26, ly - 26, lx + 26, ly + 26], fill=(255, 150, 20, 120))
    gb = g.filter(ImageFilter.GaussianBlur(9)); im.paste(gb.convert("RGB"), (0, 0), gb.getchannel("A")); d = ImageDraw.Draw(im)
    d.ellipse([lx - 8, ly - 8, lx + 8, ly + 8], fill=(255, 190, 70), outline=(150, 154, 162), width=2)
    d.text((46, 66), "33 1/3", font=font(13), fill=PRINT_DIM)
    d.text((46, 576 - 14), "DRAG THE PLATTER", font=font(11, "DejaVuSans.ttf"), fill=PRINT_DIM)

def background(tab):
    im, d = panel_bg(tab)
    if tab == "SCRATCH":
        turntable(im); d = ImageDraw.Draw(im)
        # the output fader: ruler lines and a printed label, like a pitch fader
        y0, y1 = SLY + TRAVEL0, SLY + TRAVEL1 + FY - FY
        y0, y1 = SLY + FY + TRAVEL0, SLY + FY + TRAVEL1
        for j in range(13):
            y = y1 + (y0 - y1) * j / 12; big = j in (0, 6, 12)
            d.line([SLX + 8, y, SLX + (24 if big else 18), y], fill=mix(BODY, PRINT, 0.7 if big else 0.4), width=1)
            d.line([SLX + SLW - 8, y, SLX + SLW - (24 if big else 18), y], fill=mix(BODY, PRINT, 0.7 if big else 0.4), width=1)
        text_c(d, SLX + SLW / 2, SLY + SLH + 14, "OUTPUT", font(13, "DejaVuSans.ttf"), PRINT)
    for item in BG_ITEMS[tab]:
        k = item[0]
        if k == "section":
            _, x0, x1, y, title = item
            d.text((x0, y), title, font=font(17, "DejaVuSans.ttf"), fill=PRINT)
            d.line([x0, y + 26, x1, y + 26], fill=RULE, width=2)
        elif k == "lcd":
            _, x, y, w, hh, cap = item
            d.rounded_rectangle([x - 5, y - 5, x + w + 5, y + hh + 5], radius=5, fill=(150, 154, 162))        # silver bezel
            d.rounded_rectangle([x - 3, y - 3, x + w + 3, y + hh + 3], radius=4, fill=(8, 9, 11))
            d.rectangle([x, y, x + w, y + hh], fill=LCD_BG)
            if cap: d.text((x, y - 26), cap, font=font(13, "DejaVuSans.ttf"), fill=PRINT_DIM)
        elif k == "legend":
            _, x, y, lines = item
            for j, ln in enumerate(lines): d.text((x, y + j * 28), ln, font=font(15, "DejaVuSansMono.ttf" if os.path.exists("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf") else "DejaVuSans.ttf"), fill=PRINT_DIM if j == 3 else PRINT)
        elif k == "cap":
            _, cx, cy, cap = item
            text_c(d, cx, cy, cap, font(11, "DejaVuSans.ttf"), PRINT)
    return im

def build():
    if os.path.isdir(SKIN_DIR): shutil.rmtree(SKIN_DIR)
    os.makedirs(OUT)
    img("ds_red_on.png", key_image(True, red=True)); img("ds_red_off.png", key_image(False, red=True))
    defn("dsRedKey", definition([action("Mouse Down", "Q-Link"), action("Enter Pressed", "Toggle Switch")], [
        focus((0, 0, KEY_W, KEY_H)),
        comp("Button", "Button", {"version": 2, "onImage": "ds_red_on.png", "offImage": "ds_red_off.png", "buttonId": 1,
             "numButtonsInGroup": 1, "handleName": "Data", "gestureBehaviour": "Instant"}, bounds((0, 0, KEY_W, KEY_H)))]))
    defs = []
    for tab in TABS:
        bgname = f"ds_bg_{tab.lower()}.png"
        IMAGES[bgname] = background(tab)
        comps = [comp("Background", "Image", {"version": 2, "imageType": "Regular", "colour": "0", "image": bgname}, bounds((0, 0, W, H)))]
        for pl in sorted(PLACED[tab], key=lambda q: 1 if q["touch"] else 0):
            comps.append(comp(pl["name"], pl["dkey"], {"version": 1, "handleName": "Data"},
                              bounds((pl["x"], pl["y"], pl["w"], pl["h"]), focus="Yes" if pl["touch"] else "No", show="Hide" if pl["touch"] else "Show"),
                              {"version": 1, "map": [{"key": "Data", "value": f"Parameter {pl['param']}"}]}))
        DEFS[f"DS|{tab}"] = definition([], comps, "ff16171a")
    for k, v in DEFS.items(): defs.append({"key": k, "value": v})
    tabs = [{"version": 3, "tabName": t, "fnKeyIndex": i, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
             "componentName": f"DS|{t}", "initialSize": f"0 0 {W} {H}", "scale": 1.0} for i, t in enumerate(TABS)]
    tui = {"pageData": {"version": 1,
        "componentDefinitions": {"version": 2, "importFiles": ["/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json",
                                                                "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
                                 "localComponentDefinitions": defs},
        "info": {"version": 1, "type": "CompleteDescription"}, "tabs": tabs}}
    json.dump(tui, open(os.path.join(OUT, "TUI.json"), "w"), indent=2)
    qmap = lambda keys: {f"Q-Link {i + 1}": P[k] for i, k in enumerate(keys)}
    q = {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
         "Screen Mode Q-Links": {"version": 4, "map": [{"Tab": i + 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": qmap(QL[t])} for i, t in enumerate(TABS)]},
         "Program Mode Q-Links": qmap(QL["SCRATCH"])}
    for fn in ("Q-Links.json", "Q-Links - 8by1.json"): json.dump(q, open(os.path.join(OUT, fn), "w"), indent=2)
    total = 0
    for name, im in IMAGES.items():
        im.save(os.path.join(OUT, name), optimize=True); total += im.size[0] * im.size[1] * 4
    open(os.path.join(SKIN_DIR, "version.xml"), "w").write(
        "<?xml version='1.0' encoding='utf-8'?>\n<plugincontent version=\"1.0\">\n\t<identifier>scratchlab.vst.djscratch</identifier>\n"
        "\t<version>1.1.0.0</version>\n</plugincontent>\n")
    print(f"skin written to {SKIN_DIR}: {len(IMAGES) + 2} images, {total / 1e6:.1f} MB decoded")

# ---------- preview (what the screen should look like, drawn from the same layout) ----------
def preview(outdir, state=None):
    os.makedirs(outdir, exist_ok=True)
    vals = {"platter": 0.38, "hold": 0, "auto": 1, "backspin": 0, "chop": 0, "fader": 0, "bypass": 0, "loop": 0, "tform": 1}
    txt = {"throw": "1.00 s", "inertia": "12 ms", "release": "0.40 s", "output": "+0.0 dB", "return": "Slip (jump)", "catch": "3.0x",
           "spinspeed": "8.0x", "spintime": "1.20 s", "chopms": "80 ms", "cutms": "2.0 ms", "info": "SCRATCH  -1.6x   0.18 s back  |  GATE 1/16 Straight",
           "looplen": "1/8", "bpm": "Host", "trate": "1/16", "tduty": "50 %", "tpat": "Straight"}
    inv = {v: k for k, v in P.items()}
    cache = {}
    def im_(n):
        if n not in cache: cache[n] = Image.open(os.path.join(OUT, n)).convert("RGBA")
        return cache[n]
    sheets = []
    for tab in TABS:
        im = im_(f"ds_bg_{tab.lower()}.png").copy(); d = ImageDraw.Draw(im)
        for pl in PLACED[tab]:
            x, y, w, h = int(pl["x"]), int(pl["y"]), int(pl["w"]), int(pl["h"]); key = inv[pl["param"]]; k = pl["kind"]
            if k == "platter":
                fr = round(vals["platter"] * NUMFRAMES)
                for k2 in range(4): im.alpha_composite(im_(f"ds_record{k2}.png").crop((0, fr * PIECE, PIECE, fr * PIECE + PIECE)), (x + (k2 % 2) * PIECE, y + (k2 // 2) * PIECE))
            elif k == "slider":
                fr = round(0.5 * NUMFRAMES)
                for k2 in range(NFP): im.alpha_composite(im_(f"ds_fader{k2}.png").crop((0, fr * FPIECE, FPIECE, fr * FPIECE + FPIECE)), (int(x + (SLW - FPIECE) / 2), y + FY + k2 * FPIECE))
                text_c(d, x + w / 2, y + 11, txt["output"].upper(), font(12), (255, 255, 255))
            elif k == "redkey":
                im.alpha_composite(im_(f"ds_red_{'on' if vals.get(key, 0) >= 0.5 else 'off'}.png"), (x, y))
            elif k in ("box", "text"):
                s = txt[key].upper() if k == "box" else txt[key]
                size = 15 if k == "box" else int(pl["extra"] * 0.8); f = font(size)
                while d.textlength(s, font=f) > w - 8 and size > 7: size -= 1; f = font(size)
                text_c(d, x + w / 2, y + h / 2, s, f, LCD_TXT)
        path = os.path.join(outdir, f"skin-preview-{tab.lower()}.png")
        im.convert("RGB").save(path); sheets.append(im.convert("RGB")); print("preview:", path)
    sheet = Image.new("RGB", (W, H * len(sheets) + 10 * (len(sheets) - 1)), (0, 0, 0))
    for i, s in enumerate(sheets): sheet.paste(s, (0, i * (H + 10)))
    sheet.resize((sheet.size[0] // 2, sheet.size[1] // 2), Image.LANCZOS).save(os.path.join(outdir, "skin-preview-all.png"))

if __name__ == "__main__":
    build()
    if len(sys.argv) > 1: preview(sys.argv[1])
