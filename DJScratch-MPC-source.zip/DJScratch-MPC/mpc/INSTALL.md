# DJ Scratch 1.1.0

Scratch the sound that is coming into an MPC track, submix or the master, like a record on a turntable. A native MPC OS
VST2 **insert effect** with a three-page touchscreen skin. Built the same way as the SP1200 plugin (same installer, same skin pipeline).

## Requirements
- A first-generation MPC OS standalone device (32-bit ARM: MPC X, Live / Live II, One, Key 61, Force).
- **Root shell access** (SSH). Installing plugins this way is unofficial: back up first, use at your own risk.

## Install
1. From your computer: `scp -r DJScratch-1.1.0 root@<device-ip>:/tmp/`  (or `scripts/deploy.sh <device-ip>`)
2. `ssh root@<device-ip> sh /tmp/DJScratch-1.1.0/install.sh`

The installer copies `djscratch.so` to `/sdcard/vst/` and the skin to `/sdcard/Synths/ScratchLab - VST - DJ Scratch/`,
**stops MPC** (save your project first), backs up `MPC.settings`, adds the plugin to the plugin list and starts MPC
again. Re-running upgrades in place. Add `-y` to skip the confirmation.

**MPC One / Live:** if the plugin does not load from the SD card (it can be mounted `noexec` there), install the `.so`
on the internal drive instead: `sh install.sh -t /media/az01-internal/vst` (and the same `-t` for `uninstall.sh`).

Then add **DJ Scratch** as an insert effect on a track, a submix or the master.

The skin is drawn like a classic direct-drive DJ deck (matte black plinth, aluminium platter with strobe dots, tonearm at the side). The
vertical fader on the SCRATCH page is the **Output** level.

## How to scratch
The plugin records whatever passes through it, all the time (the last 8+ seconds). While you are not touching it, it is
completely transparent (bit-exact, zero latency). Move the **PLATTER** and it grabs the record:

- **Drag on the big platter** on the SCRATCH page, or turn **Q-Link 1**. Move it back and the last seconds of the
  audio play backwards; move it forward and they play forwards, at the speed you move. Hold still and the record is silent.
- **AUTO** (on by default): moving the platter grabs the record by itself; after **Auto Release** seconds without moving, it lets go.
- **HOLD**: keeps your hand on the record (silent, nothing releases) until you turn it off. Use it with AUTO off for full manual control.
- When you let go the platter control springs back to the centre, so there is always room to scratch both ways.
- **Return** (SETUP page): *Slip (jump)* crossfades straight back to the live signal, as if the beat kept running under your
  hand (what a DJ mixer's slip mode does). *Catch up* spins the record up and races forward to the live signal (a rewind-whoosh).
- **BACKSPIN** (tap): the record spins backwards at **Spin Speed** and slows to a stop over **Spin Time**, then returns.
- **FADER** (key, latched): the crossfader: closed = output muted.
- **CHOP** (tap): flips the fader for **Chop Length**: with the fader open it is a short mute, with the fader closed it is a short
  burst of sound. Tap CHOP in rhythm with FADER closed for transform scratches.
- **LOOP** (key, latched): repeats the last bit of incoming audio, as long as you leave it on. The length is a note value
  (**Note Value** on the GROOVE page: 1/32, 1/16T, 1/16, 1/8T, 1/8, 1/4T, 1/4, 1/2, 1 Bar) at the MPC's tempo. Change the note value
  while it loops to "roll" (1/8, then 1/16, then 1/32...). While a loop runs the plugin is not recording (the loop *is* the last audio
  it heard); when you turn LOOP off it crossfades back to the live signal. If you hit LOOP before enough audio has played for that
  length, it stays live and the display says "play some audio first" (it never plays a shortened, off-grid loop).
- **TRANSFORMER** (key, latched; GROOVE page): a tempo-synced gate that chops the output in a pattern, the "transformer scratch"
  done by the plugin so both hands stay on the platter. **Rate** is the step length (1/4, 1/8, 1/8T, 1/16, 1/16T, 1/32), **Open** is how much of
  each step is open (10 to 100 %), **Pattern** is Straight (every step), Offbeat (every second step), Gallop (X.XX) or Syncopated (X..X..X., 3+3+2).
  While the transport plays it locks to the MPC's beat position; otherwise it free-runs. It works on whatever is playing: live audio,
  a scratch, or a loop. The hand-operated version (FADER + CHOP, above) is still there.
- **BYPASS**, and the host's own bypass, make the plugin fully transparent (loop and transformer included).

**Tempo.** The plugin asks the MPC for its tempo and beat position. If the MPC does not provide them, the display shows
"(default)" and the plugin assumes 120 BPM. Set **Tempo** (GROOVE page) to a number to override (Host = follow the MPC). A running
loop keeps the length it was captured with; turn LOOP off and on to pick up a new tempo.

**Playing it from MIDI notes** (only if your MPC sends notes to an insert effect; untested, see below). Hold a note, any octave:
C = 1/32, C# = 1/16T, D = 1/16, D# = 1/8T, E = 1/8, F = 1/4T, F# = 1/4, G = 1/2, G# = 1 bar loop for as long as the note is held (the latest held note wins);
A = backspin, A# = chop, B = transformer on/off.

| Control | Range | What it does |
|---|---|---|
| Throw | 0.25 .. 4 s | seconds of audio covered by the full platter travel (a bigger throw = more range per drag) |
| Inertia | 3 .. 60 ms | how heavy the platter feels (small = tight and fast, big = smooth and loose) |
| Auto Release | 0.1 .. 4 s | how long the record is held after you stop moving |
| Output | -24 .. +12 dB | output level |
| Catch-up Speed | 1.5 .. 8x | how fast Catch-up races back |
| Spin Speed / Spin Time | 2 .. 16x, 0.3 .. 4 s | the backspin |
| Chop Length / Fader Time | 10 .. 500 ms, 0.5 .. 20 ms | CHOP tap length, fader open/close time |

**Q-Links** (SCRATCH page): 1 Platter, 2 Hold, 3 Backspin, 4 Chop, 5 Fader, 6 Loop, 7 Transformer, 8 Note Value, 9 Gate Rate,
10 Throw, 11 Inertia, 12 Bypass. GROOVE page: Loop, Note Value, Tempo, Transformer, Rate, Open, Pattern, Hold, Backspin, Chop, Fader, Output.
The SETUP page maps the rest.

Seventeen presets (the plugin's programs): Classic Scratch, Tight Wrist, Heavy Platter, Long Throw, Slip Mode, Catch Up, Manual Grab,
Hand Transformer, Hard Backspin, Soft Backspin, Auto Transformer, Gallop Gate, Syncopated Gate, Triplet Cut, Loop 1/8, Loop 1/16, Loop 1/4.
Presets turn the transformer on or off with them; they never turn LOOP on, and they keep your Tempo setting.

## Uninstall
`ssh root@<device-ip> sh /tmp/DJScratch-1.1.0/uninstall.sh` removes the plugin, its skin and the plugin-list entry.

## Troubleshooting
- Plugin does not appear: it is not listed until MPC restarts. Check `grep djscratch /media/az01-internal/Settings/*/MPC.settings`.
- MPC crashes on load: run `uninstall.sh`, or restore the `MPC.settings.bak-djscratch-*` backup and delete `/sdcard/vst/djscratch.so`.
- Plain parameter list instead of the skin: MPC looks for `/sdcard/Synths/<manufacturer> - VST - <plugin>`, here
  `ScratchLab - VST - DJ Scratch`. Check `/sdcard/Synths` is in MPC's SynthContentLocations; a skin-only change needs no restart,
  just remove and re-insert the plugin.
- Nothing to scratch: the plugin only knows the audio that has passed through it since you inserted it (or since playback started).
  Play something, then scratch.
