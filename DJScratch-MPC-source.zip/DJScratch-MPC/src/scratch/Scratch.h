// DJ Scratch engine: records the incoming audio all the time into a ring buffer and lets you "scratch" it like a record.
//
//   LIVE    the plugin is transparent (bit-exact pass-through, zero latency).
//   GRAB    a hand is on the record: the read head follows the PLATTER control (a jog wheel), so moving it back and
//           forth plays the last seconds of incoming audio backwards / forwards at the speed you move it. Held still = silence.
//   SPIN    backspin: the head spins backwards fast and slows to a stop.
//   RETURN  (Catch-up mode) the record spins up and races forward until it reaches the live signal again.
//
// Leaving GRAB / SPIN, SLIP mode crossfades straight back to the live signal (the beat kept playing underneath, like
// a DJ mixer's slip mode); CATCH-UP mode fast-forwards to it.
//   LOOP    loops the last N beats of the incoming audio (a note value: 1/8, 1/16 ...) until released. While a loop runs the
//           plugin is not recording (the loop is the last audio it heard), and it crossfades back to live on release.
// TRANSFORMER (separate from the states): a tempo-synced gate that chops the output in a pattern, locked to the host's beat
// position when the transport plays and free-running otherwise. The CUT fader mutes the output (crossfader), CHOP taps it
// for a moment (a "transform" scratch).
//
// Audio-thread only. No libstdc++: plain C arrays, one calloc in prepare().
#pragma once
#include <cmath>
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

namespace ds
{
inline float clampf (float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline double clampd (double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

struct Settings
{
    float platter = 0.5f;       // 0..1 jog position (0.5 = centre)
    bool hold = false;          // keep a hand on the record
    bool autoGrab = true;       // moving the platter grabs the record, and it lets go after releaseSec of stillness
    float releaseSec = 0.4f;
    float throwSec = 1.0f;      // seconds of audio covered by the full 0..1 platter range
    float inertiaMs = 12.f;     // how heavy the platter feels (smoothing)
    bool faderClosed = false;   // crossfader: output muted while true
    float chopMs = 80.f;        // length of a CHOP tap
    float cutMs = 2.f;          // fader open/close time
    float spinSpeed = 8.f;      // backspin start speed (x normal)
    float spinSec = 1.2f;       // backspin duration
    int returnMode = 0;         // 0 = slip (jump back to live), 1 = catch up (fast-forward back)
    float catchSpeed = 3.f;
    float outDb = 0.f;
    bool bypass = false;
    // loop (beat repeat of the last audio)
    bool loopOn = false;
    double loopBeats = 1.0;     // loop length in quarter-note beats (1/8 note = 0.5)
    // tempo and position (the plugin gets these from the host, or the BPM control)
    double bpm = 120.0;
    double ppq = 0.0;           // host beat position, valid when ppqValid (transport playing)
    bool ppqValid = false;
    // transformer gate
    bool tOn = false;
    double tStepBeats = 0.25;   // length of one gate step
    float tDuty = 0.5f;         // fraction of each open step that is actually open
    uint32_t tMask = 0xFFFFu;   // which of 16 steps are open
};

class Engine
{
public:
    enum State { LIVE = 0, GRAB = 1, SPIN = 2, RETURN = 3, LOOP = 4 };

    Engine() {}
    ~Engine() { free (mem_); }
    Engine (const Engine&) = delete;
    Engine& operator= (const Engine&) = delete;

    // Host thread (effSetSampleRate / effMainsChanged). Re-allocates only if the sample rate needs a longer ring.
    bool prepare (double sr)
    {
        sr_ = clampd (sr, 8000.0, 192000.0);
        uint32_t n = 1u << 16;
        while ((double) n < sr_ * 8.0) n <<= 1;                  // >= 8 s of history
        if (n != size_)
        {
            float* m = (float*) calloc ((size_t) n * 2, sizeof (float));
            if (m == nullptr) return false;
            free (mem_);
            mem_ = m; size_ = n; mask_ = n - 1;
        }
        reset();
        return true;
    }
    void reset()
    {
        if (mem_ != nullptr) memset (mem_, 0, (size_t) size_ * 2 * sizeof (float));
        wAbs_ = 0; head_ = p1_ = anchorR_ = 0; state_ = LIVE; xf_ = 0; xfTarget_ = 0; cut_ = 1; chopLeft_ = 0;
        idle_ = 1e9; lastPlatter_ = 0.5f; vel_ = 0; spinVel_ = 0; vRet_ = 0; anchorP_ = 0.5f;
        spinReq_ = chopReq_ = false;
        loopStart_ = loopLen_ = loopPos_ = 0; loopExiting_ = false; loopFail_ = false; loopBeatsAct_ = -1; loopXf_ = 0;
        internalBeats_ = 0; tg_ = 1;
    }

    void triggerBackspin() { spinReq_ = true; }
    void triggerChop() { chopReq_ = true; }
    // The plugin moved the platter control itself (re-centring): don't count it as a hand movement.
    void notePlatter (float p) { lastPlatter_ = p; }

    State state() const { return state_; }
    bool idleLive() const { return state_ == LIVE && xf_ <= 0.f; }
    float velocity() const { return (float) vel_; }
    float behindSec() const { return (float) ((double) wAbs_ - head_) / (float) sr_; }
    float loopSec() const { return (float) ((double) loopLen_ / sr_); }
    float inputPeak() const { return inPeak_; }          // incoming signal level (linear peak of the last block, slow decay)
    bool loopFailed() const { return loopFail_; }       // a loop was asked for but there is not enough recorded audio yet
    double sampleRate() const { return sr_; }

    void process (const float* inL, const float* inR, float* outL, float* outR, int n, const Settings& s)
    {
        if (mem_ == nullptr)
        {
            if (outL != inL) memcpy (outL, inL, sizeof (float) * (size_t) n);
            if (outR != inR) memcpy (outR, inR, sizeof (float) * (size_t) n);
            return;
        }
        float* const bl = mem_;
        float* const br = mem_ + size_;
        const double sr = sr_;
        const float p = clampf (s.platter, 0.f, 1.f);
        { float pk = 0.f; for (int i = 0; i < n; ++i) { const float a = std::fmax (std::fabs (inL[i]), std::fabs (inR[i])); if (a > pk) pk = a; } inPeak_ = std::fmax (pk, inPeak_ * 0.9f); }

        // ---------------------------------------------------------------- block-level control
        const bool moved = std::fabs (p - lastPlatter_) > 1e-5f;
        const double relFrames = clampd (s.releaseSec, 0.05, 10.0) * sr;
        if (! s.autoGrab) idle_ = 1e9; else if (moved) idle_ = 0; else idle_ += n;
        const bool wantGrab = ! s.bypass && (s.hold || (s.autoGrab && idle_ < relFrames));
        const float engageP = moved ? lastPlatter_ : p;     // the move that grabbed the record counts

        if (s.bypass) { state_ = LIVE; xf_ = xfTarget_ = 0; spinReq_ = false; loopExiting_ = false; loopFail_ = false; }
        if (chopReq_) { chopReq_ = false; chopLeft_ = (int64_t) (clampd (s.chopMs, 5.0, 2000.0) * 0.001 * sr); }

        const double hiLive = (double) wAbs_ - 3.0;
        const bool wantLoop = ! s.bypass && s.loopOn;
        if (wantLoop)
        {
            const bool active = state_ == LOOP && ! loopExiting_;
            if (! active || loopBeatsAct_ != s.loopBeats) engageLoop (s);
        }
        else
        {
            loopFail_ = false;
            if (state_ == LOOP && ! loopExiting_) { loopExiting_ = true; xfTarget_ = 0; }
        }
        if (spinReq_)
        {
            spinReq_ = false;
            if (! s.bypass && state_ != LOOP)
            {
                if (state_ == LIVE && xf_ <= 0.f) head_ = hiLive;
                p1_ = head_; state_ = SPIN; spinVel_ = -clampd (s.spinSpeed, 1.0, 16.0); xfTarget_ = 1;
            }
        }
        switch (state_)
        {
            case LIVE:
                if (wantGrab) { head_ = p1_ = anchorR_ = (xf_ <= 0.f) ? hiLive : head_; anchorP_ = engageP; state_ = GRAB; xfTarget_ = 1; }
                break;
            case GRAB:
                if (! wantGrab) release (s);
                break;
            case SPIN:
                if (wantGrab) { p1_ = anchorR_ = head_; anchorP_ = engageP; spinVel_ = 0; state_ = GRAB; }
                break;
            case RETURN:
                if (wantGrab) { p1_ = anchorR_ = head_; anchorP_ = engageP; state_ = GRAB; }
                break;
            case LOOP:
                break;
        }

        const double tauPole = clampd (s.inertiaMs, 2.0, 100.0) * 0.001 * 0.5;       // two cascaded poles
        const double a = 1.0 - std::exp (-1.0 / (tauPole * sr));
        const double aRet = 1.0 - std::exp (-1.0 / (0.015 * sr));
        const double spinDecay = std::exp (-1.0 / ((clampd (s.spinSec, 0.1, 6.0) / 4.6) * sr));
        const double throwFrames = clampd (s.throwSec, 0.1, 4.0) * sr;
        const double catchSpd = clampd (s.catchSpeed, 1.5, 8.0);
        const float xfStep = (float) (1.0 / (0.005 * sr));
        const float cutStep = (float) (1.0 / (clampd (s.cutMs, 0.2, 50.0) * 0.001 * sr));
        const float gain = std::pow (10.f, clampf (s.outDb, -60.f, 24.f) / 20.f);
        const double vmax = 12.0;
        const double bpf = clampd (s.bpm, 40.0, 240.0) / 60.0 / sr;                 // beats per frame
        const double beat0 = s.ppqValid ? s.ppq : internalBeats_;
        const double stepBeats = clampd (s.tStepBeats, 0.05, 4.0);
        const double duty = clampd ((double) s.tDuty, 0.05, 1.0);

        // ---------------------------------------------------------------- audio
        for (int i = 0; i < n; ++i)
        {
            const float l = inL[i], r = inR[i];
            if (! (state_ == LOOP && ! loopExiting_))                   // a running loop freezes the recording
            {
                const uint32_t wi = (uint32_t) (wAbs_ & mask_);
                bl[wi] = l; br[wi] = r;
                ++wAbs_;
            }
            const double hi = (double) wAbs_ - 3.0;
            const double lo = (double) wAbs_ - (double) size_ + 8.0;

            double v = 1.0;
            switch (state_)
            {
                case GRAB:
                {
                    const double t = clampd (anchorR_ + (double) (p - anchorP_) * throwFrames, lo, hi);
                    p1_ += (t - p1_) * a;
                    double d = (p1_ - head_) * a;
                    d = clampd (d, -vmax, vmax);
                    head_ += d; v = d;
                    break;
                }
                case SPIN:
                    v = spinVel_; head_ += v; spinVel_ *= spinDecay;
                    if (std::fabs (spinVel_) < 0.04 || head_ <= lo) { head_ = clampd (head_, lo, hi); endSpin (s); }
                    break;
                case RETURN:
                    vRet_ += (catchSpd - vRet_) * aRet; v = vRet_; head_ += v;
                    if (head_ >= hi) { head_ = hi; state_ = LIVE; xfTarget_ = 0; v = 1.0; }
                    break;
                case LIVE:
                    v = 1.0;
                    if (xf_ > 0.f) head_ += 1.0; else head_ = hi;
                    break;
                case LOOP:
                    v = 1.0;
                    break;
            }
            if (state_ != LOOP) head_ = clampd (head_, lo, hi);
            vel_ = v;

            if (xf_ < xfTarget_) xf_ = std::fmin (xf_ + xfStep, xfTarget_); else if (xf_ > xfTarget_) xf_ = std::fmax (xf_ - xfStep, xfTarget_);
            if (state_ == LOOP && loopExiting_ && xf_ <= 0.f) { state_ = LIVE; loopExiting_ = false; head_ = p1_ = hi; }

            float oL = l, oR = r;
            if (xf_ > 0.f)
            {
                float pl, pr;
                if (state_ == LOOP) loopSample (bl, br, pl, pr);
                else
                {
                    const int64_t ii = (int64_t) std::floor (head_);
                    const float f = (float) (head_ - (double) ii);
                    pl = hermite (bl, ii, f); pr = hermite (br, ii, f);
                    float g = clampf ((float) std::fabs (v) * 5.f, 0.f, 1.f);      // a stopped record is silent
                    g = g * g * (3.f - 2.f * g);
                    pl *= g; pr *= g;
                }
                oL = l * (1.f - xf_) + pl * xf_;
                oR = r * (1.f - xf_) + pr * xf_;
            }
            else if (state_ == LIVE) { p1_ = head_; }

            const bool closed = s.faderClosed != (chopLeft_ > 0);
            if (chopLeft_ > 0) --chopLeft_;
            const float ct = closed ? 0.f : 1.f;
            if (cut_ < ct) cut_ = std::fmin (cut_ + cutStep, ct); else if (cut_ > ct) cut_ = std::fmax (cut_ - cutStep, ct);

            // transformer gate: the step comes from the beat position, so it stays on the grid
            {
                float tt = 1.f;
                if (s.tOn && ! s.bypass)
                {
                    const double sp = (beat0 + (double) i * bpf) / stepBeats, fl = std::floor (sp);
                    const int si = (int) (((int64_t) fl % 16 + 16) % 16);
                    tt = (((s.tMask >> si) & 1u) != 0 && (sp - fl) < duty) ? 1.f : 0.f;
                }
                if (tg_ < tt) tg_ = std::fmin (tg_ + cutStep, tt); else if (tg_ > tt) tg_ = std::fmax (tg_ - cutStep, tt);
                if (tg_ != 1.f) { oL *= tg_; oR *= tg_; }
            }
            if (cut_ != 1.f) { oL *= cut_; oR *= cut_; }
            if (gain != 1.f) { oL *= gain; oR *= gain; }
            outL[i] = oL; outR[i] = oR;
        }
        lastPlatter_ = p;
        internalBeats_ = beat0 + (double) n * bpf;
    }

private:
    bool engageLoop (const Settings& s)
    {
        const double bpm = clampd (s.bpm, 40.0, 240.0);
        int64_t L = (int64_t) std::llround (clampd (s.loopBeats, 0.0625, 4.0) * 60.0 / bpm * sr_);
        int64_t xf = (int64_t) (0.002 * sr_); if (xf < 16) xf = 16;
        const int64_t have = (wAbs_ < (int64_t) size_ - 16 ? wAbs_ : (int64_t) size_ - 16) - xf - 8;     // history we can loop
        if (L < 64 || L > have) { loopFail_ = true; return false; }     // not enough audio recorded yet: never a shortened (off-grid) loop
        if (xf > L / 2) xf = L / 2;
        loopFail_ = false; loopLen_ = L; loopStart_ = wAbs_ - L; loopPos_ = 0; loopXf_ = xf;
        loopBeatsAct_ = s.loopBeats; loopExiting_ = false; state_ = LOOP; xfTarget_ = 1; spinVel_ = 0;
        return true;
    }
    inline void loopSample (const float* bl, const float* br, float& pl, float& pr)
    {
        const uint64_t m = mask_;
        const int64_t idx = loopStart_ + loopPos_;
        pl = bl[(uint64_t) idx & m]; pr = br[(uint64_t) idx & m];
        const int64_t tail = loopLen_ - loopPos_;                  // frames left before the wrap (>= 1)
        if (tail <= loopXf_)                                       // crossfade into what came before the loop start: seamless wrap
        {
            const float g = (float) (loopXf_ - tail + 1) / (float) loopXf_;
            const uint64_t j = (uint64_t) (idx - loopLen_) & m;
            pl = pl * (1.f - g) + bl[j] * g; pr = pr * (1.f - g) + br[j] * g;
        }
        if (++loopPos_ >= loopLen_) loopPos_ = 0;
    }
    void release (const Settings& s)
    {
        if (s.returnMode == 1) { state_ = RETURN; vRet_ = 0; }
        else { state_ = LIVE; xfTarget_ = 0; }          // slip: back to live; the head keeps playing for the 5 ms crossfade
    }
    void endSpin (const Settings& s) { spinVel_ = 0; release (s); }

    inline float hermite (const float* b, int64_t i, float f) const
    {
        const uint64_t m = mask_;
        const float y0 = b[(uint64_t) (i - 1) & m], y1 = b[(uint64_t) i & m], y2 = b[(uint64_t) (i + 1) & m], y3 = b[(uint64_t) (i + 2) & m];
        const float c1 = 0.5f * (y2 - y0);
        const float c2 = y0 - 2.5f * y1 + 2.f * y2 - 0.5f * y3;
        const float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
        return ((c3 * f + c2) * f + c1) * f + y1;
    }

    float inPeak_ = 0.f;
    float* mem_ = nullptr;
    uint32_t size_ = 0, mask_ = 0;
    double sr_ = 44100.0;
    int64_t wAbs_ = 0;                  // frames written so far; newest sample is wAbs_ - 1
    double head_ = 0, p1_ = 0, anchorR_ = 0;
    float anchorP_ = 0.5f, lastPlatter_ = 0.5f, xf_ = 0, xfTarget_ = 0, cut_ = 1;
    double idle_ = 1e9, vel_ = 0, spinVel_ = 0, vRet_ = 0;
    int64_t chopLeft_ = 0;
    State state_ = LIVE;
    bool spinReq_ = false, chopReq_ = false;
    int64_t loopStart_ = 0, loopLen_ = 0, loopPos_ = 0, loopXf_ = 0;
    bool loopExiting_ = false, loopFail_ = false;
    double loopBeatsAct_ = -1, internalBeats_ = 0;
    float tg_ = 1.f;
};
} // namespace ds
