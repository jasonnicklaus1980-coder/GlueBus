// DJ Scratch - scratch the audio coming into an MPC track, submix or the master. A native MPC OS VST2 insert effect
// (Gen1, 32-bit ARM), built the same way as the SP1200 plugin: dependency-free VST2 core (src/vst2.h), one parameter
// table, a skin drawn by tools/make_skin.py, needs only libc/libm.
//
// The DSP is in src/scratch/Scratch.h. This file: parameters, presets (VST programs), host tempo, MIDI notes, the status
// readout, entry points.
#include "scratch/Scratch.h"
#include "vst2.h"
#include <atomic>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <new>

#define DS_EXPORT extern "C" __attribute__((visibility("default")))

namespace
{
using namespace ds;

enum ParamId
{
    P_PLATTER, P_HOLD, P_AUTO, P_RELEASE, P_THROW, P_INERTIA,
    P_FADER, P_CHOP, P_BACKSPIN,
    P_RETURN, P_CATCH, P_SPINSPEED, P_SPINTIME, P_CHOPMS, P_CUTMS, P_OUTPUT, P_BYPASS,
    P_LOOP, P_LOOPLEN, P_BPM, P_TFORM, P_TRATE, P_TDUTY, P_TPAT,
    P_INFO,
    P_COUNT
};
enum Kind { K_FLOAT, K_CHOICE, K_BOOL, K_LOG, K_TEXT };
enum Fmt { F_NUM, F_DB, F_SEC, F_MS, F_X, F_PLATTER, F_BPM, F_PCT };

const char* const kReturns[] { "Slip (jump)", "Catch up" };
// note values, in quarter-note beats (a quarter note = 1 beat)
const char* const kLoopNames[] { "1/32", "1/16T", "1/16", "1/8T", "1/8", "1/4T", "1/4", "1/2", "1 Bar" };
const double kLoopBeats[] { 0.125, 1.0 / 6.0, 0.25, 1.0 / 3.0, 0.5, 2.0 / 3.0, 1.0, 2.0, 4.0 };
const char* const kRateNames[] { "1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32" };
const double kRateBeats[] { 1.0, 0.5, 1.0 / 3.0, 0.25, 1.0 / 6.0, 0.125 };
const char* const kPatNames[] { "Straight", "Offbeat", "Gallop", "Syncopated" };
const uint32_t kPatMask[] { 0xFFFFu, 0xAAAAu, 0xDDDDu, 0x4949u };     // 16 steps; Gallop = X.XX, Syncopated = X..X..X. (3+3+2)

struct ParamDef
{
    const char* key; const char* name; const char* unit; Kind kind; float lo, hi, step, def;
    const char* const* choices; int n; Fmt fmt;
};
#define CH(a) a, (int) (sizeof (a) / sizeof (a[0]))
ParamDef kParams[P_COUNT];
void initParams()
{
    auto f = [] (int i, const char* key, const char* name, const char* unit, Kind k, float lo, float hi, float step, float def, Fmt fm)
    { kParams[i] = { key, name, unit, k, lo, hi, step, def, nullptr, 0, fm }; };
    auto c = [] (int i, const char* key, const char* name, const char* const* ch, int n, int def)
    { kParams[i] = { key, name, "", K_CHOICE, 0, (float) (n - 1), 1, (float) def, ch, n, F_NUM }; };
    f (P_PLATTER, "platter", "Platter", "", K_FLOAT, 0, 1, 0, 0.5f, F_PLATTER);
    f (P_HOLD, "hold", "Hold", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_AUTO, "auto", "Auto Grab", "", K_BOOL, 0, 1, 1, 1, F_NUM);
    f (P_RELEASE, "release", "Auto Release", "s", K_LOG, 0.1f, 4.f, 0, 0.4f, F_SEC);
    f (P_THROW, "throw", "Throw", "s", K_LOG, 0.25f, 4.f, 0, 1.f, F_SEC);
    f (P_INERTIA, "inertia", "Inertia", "ms", K_LOG, 3.f, 60.f, 0, 12.f, F_MS);
    f (P_FADER, "fader", "Fader Closed", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_CHOP, "chop", "Chop", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BACKSPIN, "backspin", "Backspin", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_RETURN, "return", "Return", CH (kReturns), 0);
    f (P_CATCH, "catch", "Catch-up Speed", "x", K_FLOAT, 1.5f, 8.f, 0.1f, 3.f, F_X);
    f (P_SPINSPEED, "spinspeed", "Spin Speed", "x", K_FLOAT, 2.f, 16.f, 0.5f, 8.f, F_X);
    f (P_SPINTIME, "spintime", "Spin Time", "s", K_LOG, 0.3f, 4.f, 0, 1.2f, F_SEC);
    f (P_CHOPMS, "chopms", "Chop Length", "ms", K_LOG, 10.f, 500.f, 0, 80.f, F_MS);
    f (P_CUTMS, "cutms", "Fader Time", "ms", K_LOG, 0.5f, 20.f, 0, 2.f, F_MS);
    f (P_OUTPUT, "output", "Output", "dB", K_FLOAT, -24, 12, 0.1f, 0, F_DB);
    f (P_BYPASS, "bypass", "Bypass", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_LOOP, "loop", "Loop", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_LOOPLEN, "looplen", "Loop Length", CH (kLoopNames), 4);
    f (P_BPM, "bpm", "Tempo", "BPM", K_FLOAT, 0, 240, 1, 0, F_BPM);
    f (P_TFORM, "tform", "Transformer", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_TRATE, "trate", "Gate Rate", CH (kRateNames), 3);
    f (P_TDUTY, "tduty", "Gate Open", "%", K_FLOAT, 10, 100, 1, 50, F_PCT);
    c (P_TPAT, "tpat", "Gate Pattern", CH (kPatNames), 0);
    kParams[P_INFO] = { "info", "Status", "", K_TEXT, 0, 1000, 0, 0, nullptr, 0, F_NUM };
}
inline bool isTrigger (int i) { return i == P_CHOP || i == P_BACKSPIN; }

float toPlain (const ParamDef& d, float norm)
{
    norm = clampf (norm, 0.f, 1.f);
    if (d.kind == K_BOOL) return norm >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return std::floor (norm * (float) (d.n - 1) + 0.5f);
    if (d.kind == K_LOG) return d.lo * std::pow (d.hi / d.lo, norm);
    float v = d.lo + norm * (d.hi - d.lo);
    if (d.step > 0.f) v = d.lo + std::floor ((v - d.lo) / d.step + 0.5f) * d.step;
    return clampf (v, d.lo, d.hi);
}
float toNorm (const ParamDef& d, float plain)
{
    if (d.kind == K_BOOL) return plain >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return d.n > 1 ? clampf (plain / (float) (d.n - 1), 0.f, 1.f) : 0.f;
    if (d.kind == K_LOG) return clampf (std::log (clampf (plain, d.lo, d.hi) / d.lo) / std::log (d.hi / d.lo), 0.f, 1.f);
    return clampf ((plain - d.lo) / (d.hi - d.lo), 0.f, 1.f);
}
void copyStr (void* dst, const char* src, size_t max = 24)
{
    if (dst == nullptr) return;
    std::strncpy ((char*) dst, src, max - 1);
    ((char*) dst)[max - 1] = 0;
}

// ---------------------------------------------------------------------------------------------- presets
struct Ov { int id; float v; };
struct Preset { const char* name; const Ov* ov; int n; };
#define PRESET(sym, ...) const Ov sym[] = { __VA_ARGS__ };
#define ENTRY(name, sym) { name, sym, (int) (sizeof (sym) / sizeof (sym[0])) }
PRESET (pClassic, { P_AUTO, 1 })
PRESET (pTight, { P_INERTIA, 5.f }, { P_THROW, 0.5f }, { P_RELEASE, 0.25f })
PRESET (pHeavy, { P_INERTIA, 35.f }, { P_THROW, 1.5f }, { P_RELEASE, 0.6f })
PRESET (pLong, { P_THROW, 3.f }, { P_RELEASE, 0.8f }, { P_INERTIA, 18.f })
PRESET (pSlip, { P_RETURN, 0 }, { P_RELEASE, 0.3f })
PRESET (pCatch, { P_RETURN, 1 }, { P_CATCH, 4.f }, { P_RELEASE, 0.35f })
PRESET (pManual, { P_AUTO, 0 })
PRESET (pTransform, { P_FADER, 1 }, { P_CHOPMS, 60.f }, { P_CUTMS, 1.f })
PRESET (pHardSpin, { P_SPINSPEED, 12.f }, { P_SPINTIME, 2.f })
PRESET (pSoftSpin, { P_SPINSPEED, 5.f }, { P_SPINTIME, 0.8f })
PRESET (pAutoT, { P_TFORM, 1 }, { P_TRATE, 3 }, { P_TPAT, 0 }, { P_TDUTY, 50 })
PRESET (pGallop, { P_TFORM, 1 }, { P_TRATE, 1 }, { P_TPAT, 2 }, { P_TDUTY, 70 })
PRESET (pSync, { P_TFORM, 1 }, { P_TRATE, 3 }, { P_TPAT, 3 }, { P_TDUTY, 60 })
PRESET (pTripCut, { P_TFORM, 1 }, { P_TRATE, 2 }, { P_TPAT, 1 }, { P_TDUTY, 80 })
PRESET (pLoop8, { P_LOOPLEN, 4 })
PRESET (pLoop16, { P_LOOPLEN, 2 })
PRESET (pLoop4, { P_LOOPLEN, 6 })
const Preset kPresets[] =
{
    ENTRY ("Classic Scratch", pClassic), ENTRY ("Tight Wrist", pTight), ENTRY ("Heavy Platter", pHeavy), ENTRY ("Long Throw", pLong),
    ENTRY ("Slip Mode", pSlip), ENTRY ("Catch Up", pCatch), ENTRY ("Manual Grab", pManual), ENTRY ("Hand Transformer", pTransform),
    ENTRY ("Hard Backspin", pHardSpin), ENTRY ("Soft Backspin", pSoftSpin),
    ENTRY ("Auto Transformer", pAutoT), ENTRY ("Gallop Gate", pGallop), ENTRY ("Syncopated Gate", pSync), ENTRY ("Triplet Cut", pTripCut),
    ENTRY ("Loop 1/8", pLoop8), ENTRY ("Loop 1/16", pLoop16), ENTRY ("Loop 1/4", pLoop4),
};
constexpr int kNumPresets = (int) (sizeof (kPresets) / sizeof (kPresets[0]));

// ---------------------------------------------------------------------------------------------- plugin
struct Text
{
    char buf[2][96] {}; std::atomic<int> live { 0 };
    const char* get() const { return buf[live.load()]; }
    bool publish (const char* s)
    {
        if (std::strcmp (get(), s) == 0) return false;
        const int idle = 1 - live.load(); std::snprintf (buf[idle], sizeof buf[idle], "%s", s); live.store (idle); return true;
    }
};

struct Plugin
{
    AEffect fx {};
    audioMasterCallback master = nullptr;
    std::atomic<float> v[P_COUNT], nv[P_COUNT];
    std::atomic<int> pending[P_COUNT];     // taps received on the trigger keys, consumed by the audio thread
    std::atomic<uint32_t> noteMask { 0 };  // MIDI notes held (pitch classes C..G# = loop lengths)
    std::atomic<int> noteLast { -1 };      // the loop length the latest held note selects
    std::atomic<int> tformDirty { 0 };     // a MIDI note flipped the transformer: tell the host
    int loopIdxActive = 4;
    double bpmUsed = 120.0; int tempoSrc = 2;   // 0 manual, 1 host, 2 default
    float sent[P_COUNT];
    int program = 0;
    float sr = 44100.f;
    Engine engine;
    Text info; int infoGen = 0;
    int displayCountdown = 0;

    Plugin()
    {
        for (int i = 0; i < P_COUNT; ++i) { setPlain (i, kParams[i].def); sent[i] = 1e9f; pending[i].store (0); }
        engine.prepare (sr);
    }
    void setPlain (int i, float plain) { v[i].store (plain); nv[i].store (toNorm (kParams[i], plain)); }
    void setNorm (int i, float norm)
    {
        const ParamDef& d = kParams[i];
        if (d.kind == K_TEXT) return;
        norm = clampf (norm, 0.f, 1.f);
        nv[i].store (norm); v[i].store (toPlain (d, norm));
        if (isTrigger (i) && norm >= 0.5f) pending[i].fetch_add (1);       // a tap
    }
    float get (int i) const { return v[i].load(); }
    void applyPreset (int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        program = i;
        for (int p = 0; p < P_COUNT; ++p)
            if (p != P_PLATTER && p != P_HOLD && p != P_BYPASS && p != P_LOOP && p != P_BPM && ! isTrigger (p) && kParams[p].kind != K_TEXT) setPlain (p, kParams[p].def);
        for (int k = 0; k < kPresets[i].n; ++k) setPlain (kPresets[i].ov[k].id, kPresets[i].ov[k].v);
    }
    void notifyHostAll()
    {
        if (master == nullptr) return;
        for (int i = 0; i < P_COUNT; ++i) if (kParams[i].kind != K_TEXT) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
        master (&fx, audioMasterUpdateDisplay, 0, 0, nullptr, 0.f);
    }
    Settings settings() const
    {
        Settings s;
        s.platter = get (P_PLATTER); s.hold = get (P_HOLD) > 0.5f; s.autoGrab = get (P_AUTO) > 0.5f; s.releaseSec = get (P_RELEASE);
        s.throwSec = get (P_THROW); s.inertiaMs = get (P_INERTIA); s.faderClosed = get (P_FADER) > 0.5f; s.chopMs = get (P_CHOPMS);
        s.cutMs = get (P_CUTMS); s.spinSpeed = get (P_SPINSPEED); s.spinSec = get (P_SPINTIME); s.returnMode = (int) get (P_RETURN);
        s.catchSpeed = get (P_CATCH); s.outDb = get (P_OUTPUT); s.bypass = get (P_BYPASS) > 0.5f;
        return s;
    }

    // ---------------------------------------------------------------- MIDI notes (if the host sends them to an insert)
    // C..G# hold a loop of the matching length (see kLoopNames), A = backspin, A# = chop, B = transformer on/off.
    void midiNote (int note, bool on)
    {
        const int pc = note % 12;
        if (on)
        {
            if (pc < 9) { noteMask.fetch_or (1u << pc); noteLast.store (pc); }
            else if (pc == 9) pending[P_BACKSPIN].fetch_add (1);
            else if (pc == 10) pending[P_CHOP].fetch_add (1);
            else { setPlain (P_TFORM, get (P_TFORM) > 0.5f ? 0.f : 1.f); tformDirty.store (1); }
        }
        else if (pc < 9)
        {
            const uint32_t m = noteMask.fetch_and (~(1u << pc)) & ~(1u << pc);
            if (noteLast.load() == pc) { int k = -1; for (int b = 8; b >= 0; --b) if (m & (1u << b)) { k = b; break; } noteLast.store (k); }
        }
    }
    void midiEvents (const VstEvents* ev)
    {
        if (ev == nullptr) return;
        int n = ev->numEvents; if (n > 256) n = 256;
        const VstEvent* const* arr = &ev->events[0];
        for (int i = 0; i < n; ++i)
        {
            const VstEvent* e = arr[i];
            if (e == nullptr || e->type != kVstMidiType) continue;
            const VstMidiEvent* m = reinterpret_cast<const VstMidiEvent*> (e);
            const int st = m->midiData[0] & 0xF0, d1 = m->midiData[1] & 0x7F, d2 = m->midiData[2] & 0x7F;
            if (st == 0x90 && d2 > 0) midiNote (d1, true);
            else if (st == 0x80 || st == 0x90) midiNote (d1, false);
            else if (st == 0xB0 && (d1 == 123 || d1 == 120)) { noteMask.store (0); noteLast.store (-1); }     // all notes off
        }
    }
    // tempo and transport from the host; the BPM control overrides it
    void readHostTime (Settings& s)
    {
        double hostTempo = 0; s.ppqValid = false; s.ppq = 0;
        if (master != nullptr)
        {
            const intptr_t r = master (&fx, audioMasterGetTime, 0, kVstTempoValid | kVstPpqPosValid, nullptr, 0.f);
            const VstTimeInfo* ti = reinterpret_cast<const VstTimeInfo*> (r);
            if (ti != nullptr)
            {
                if ((ti->flags & kVstTempoValid) != 0 && ti->tempo >= 20.0 && ti->tempo <= 400.0) hostTempo = ti->tempo;
                if ((ti->flags & kVstPpqPosValid) != 0 && (ti->flags & kVstTransportPlaying) != 0 && ti->ppqPos >= 0.0) { s.ppqValid = true; s.ppq = ti->ppqPos; }
            }
        }
        const double manual = get (P_BPM);
        if (manual >= 1.0) { bpmUsed = manual; tempoSrc = 0; s.ppqValid = false; }          // a typed tempo is not the host's grid
        else if (hostTempo > 0) { bpmUsed = hostTempo; tempoSrc = 1; }
        else { bpmUsed = 120.0; tempoSrc = 2; }
        s.bpm = bpmUsed;
    }

    // ---------------------------------------------------------------- audio thread -> host
    void send (int i, float plain, float thr)
    {
        setPlain (i, plain);
        if (std::fabs (plain - sent[i]) < thr) return;
        sent[i] = plain;
        if (master != nullptr) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
    }
    void updateDisplay()
    {
        char t[96], tail[64] = "";
        const float vel = engine.velocity();
        char tempo[32]; std::snprintf (tempo, sizeof tempo, "%.0f BPM%s", bpmUsed, tempoSrc == 1 ? " host" : (tempoSrc == 2 ? " (default)" : ""));
        if (get (P_TFORM) > 0.5f && get (P_BYPASS) < 0.5f)
            std::snprintf (tail, sizeof tail, "  |  GATE %s %s", kRateNames[clampi ((int) get (P_TRATE), 0, 5)], kPatNames[clampi ((int) get (P_TPAT), 0, 3)]);
        switch (engine.state())
        {
            case Engine::GRAB: std::snprintf (t, sizeof t, "SCRATCH  %+.1fx   %.2f s back%s", (double) vel, (double) engine.behindSec(), tail); break;
            case Engine::SPIN: std::snprintf (t, sizeof t, "BACKSPIN  %+.1fx%s", (double) vel, tail); break;
            case Engine::RETURN: std::snprintf (t, sizeof t, "CATCH UP  %.2f s to live%s", (double) engine.behindSec(), tail); break;
            case Engine::LOOP: std::snprintf (t, sizeof t, "LOOP %s  %.2f s  %s%s", kLoopNames[clampi (loopIdxActive, 0, 8)], (double) engine.loopSec(), tempo, tail); break;
            default:
                if (get (P_BYPASS) > 0.5f) std::snprintf (t, sizeof t, "BYPASS");
                else if (engine.loopFailed()) std::snprintf (t, sizeof t, "LOOP %s: play some audio first", kLoopNames[clampi (loopIdxActive, 0, 8)]);
                else
                {
                    const float pk = engine.inputPeak();
                    char in[24];
                    if (pk < 0.00003f) std::snprintf (in, sizeof in, "IN: no signal");
                    else std::snprintf (in, sizeof in, "IN %+.0f dB", (double) (20.f * std::log10 (pk)));
                    std::snprintf (t, sizeof t, "LIVE  %s  %s%s", in, tempo, tail);
                }
                break;
        }
        if (! info.publish (t)) return;
        infoGen = (infoGen + 1) % 1000;
        send (P_INFO, (float) infoGen, 0.5f);
    }
    void process (const float* inL, const float* inR, float* outL, float* outR, int n)
    {
        Settings s = settings();
        readHostTime (s);
        const int held = noteLast.load();
        const int loopIdx = held >= 0 ? held : clampi ((int) get (P_LOOPLEN), 0, 8);
        loopIdxActive = loopIdx;
        s.loopOn = get (P_LOOP) > 0.5f || held >= 0; s.loopBeats = kLoopBeats[loopIdx];
        s.tOn = get (P_TFORM) > 0.5f; s.tStepBeats = kRateBeats[clampi ((int) get (P_TRATE), 0, 5)];
        s.tDuty = get (P_TDUTY) * 0.01f; s.tMask = kPatMask[clampi ((int) get (P_TPAT), 0, 3)];
        if (tformDirty.exchange (0)) send (P_TFORM, get (P_TFORM), 0.f);
        // taps on the trigger keys: act on them, then let the key spring back
        if (pending[P_BACKSPIN].exchange (0) > 0) { engine.triggerBackspin(); send (P_BACKSPIN, 0.f, 0.f); }
        if (pending[P_CHOP].exchange (0) > 0) { engine.triggerChop(); send (P_CHOP, 0.f, 0.f); }
        engine.process (inL, inR, outL, outR, n, s);
        // record at rest: bring the platter control back to the middle so the next scratch has room both ways
        if (engine.idleLive() && std::fabs (s.platter - 0.5f) > 0.002f)
        {
            engine.notePlatter (0.5f);
            send (P_PLATTER, 0.5f, 0.f);
        }
        displayCountdown -= n;
        if (displayCountdown <= 0) { displayCountdown += (int) (sr / 15.f); updateDisplay(); }
    }
    void display (int idx, char* out, size_t max) const
    {
        const ParamDef& d = kParams[idx];
        const float p = v[idx].load();
        if (idx == P_INFO) { std::snprintf (out, max, "%s", info.get()); return; }
        if (d.kind == K_CHOICE) { std::snprintf (out, max, "%s", d.choices[clampi ((int) p, 0, d.n - 1)]); return; }
        if (d.kind == K_BOOL)
        {
            if (isTrigger (idx)) { std::snprintf (out, max, "Tap"); return; }
            std::snprintf (out, max, "%s", p >= 0.5f ? "On" : "Off"); return;
        }
        switch (d.fmt)
        {
            case F_DB: std::snprintf (out, max, "%+.1f dB", (double) p); return;
            case F_SEC: std::snprintf (out, max, "%.2f s", (double) p); return;
            case F_MS: std::snprintf (out, max, p < 10.f ? "%.1f ms" : "%.0f ms", (double) p); return;
            case F_X: std::snprintf (out, max, "%.1fx", (double) p); return;
            case F_PLATTER: std::snprintf (out, max, "%+.0f", (double) ((p - 0.5f) * 200.f)); return;
            case F_BPM: if (p < 1.f) std::snprintf (out, max, "Host"); else std::snprintf (out, max, "%.0f", (double) p); return;
            case F_PCT: std::snprintf (out, max, "%.0f %%", (double) p); return;
            default: std::snprintf (out, max, "%.2f", (double) p); return;
        }
    }
    static int clampi (int x, int lo, int hi) { return x < lo ? lo : (x > hi ? hi : x); }
};

// ---------------------------------------------------------------------------------------------- VST2 entry points
void processReplacing (AEffect* e, float** in, float** out, int32_t n) { static_cast<Plugin*> (e->object)->process (in[0], in[1], out[0], out[1], n); }
void processAccumulating (AEffect* e, float** in, float** out, int32_t n)
{
    float tl[256], tr[256];
    Plugin* p = static_cast<Plugin*> (e->object);
    for (int32_t pos = 0; pos < n; pos += 256)
    {
        const int32_t m = (n - pos) < 256 ? (n - pos) : 256;
        p->process (in[0] + pos, in[1] + pos, tl, tr, m);
        for (int32_t i = 0; i < m; ++i) { out[0][pos + i] += tl[i]; out[1][pos + i] += tr[i]; }
    }
}
void setParameter (AEffect* e, int32_t i, float norm) { if (i >= 0 && i < P_COUNT) static_cast<Plugin*> (e->object)->setNorm (i, norm); }
float getParameter (AEffect* e, int32_t i) { return (i >= 0 && i < P_COUNT) ? static_cast<Plugin*> (e->object)->nv[i].load() : 0.f; }
intptr_t dispatcher (AEffect* e, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    switch (op)
    {
        case effClose:            p->~Plugin(); std::free (p); return 0;
        case effSetProgram:       p->applyPreset ((int) val); p->notifyHostAll(); return 0;
        case effGetProgram:       return p->program;
        case effGetProgramName:   copyStr (ptr, kPresets[p->program].name); return 0;
        case effGetProgramNameIndexed: if (idx < 0 || idx >= kNumPresets) return 0; copyStr (ptr, kPresets[idx].name); return 1;
        case effGetParamName:     if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].name); return 0;
        case effGetParamLabel:    if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].unit, 8); return 0;
        case effGetParamDisplay:  if (idx >= 0 && idx < P_COUNT && ptr != nullptr) { char b[96]; p->display (idx, b, sizeof b); copyStr (ptr, b, 64); } return 0;
        case effCanBeAutomated:   return (idx >= 0 && idx < P_COUNT && kParams[idx].kind != K_TEXT) ? 1 : 0;
        case effSetSampleRate:    if (opt > 1000.f) { p->sr = opt; p->engine.prepare (opt); } return 0;
        case effMainsChanged:     if (val) p->engine.prepare (p->sr); return 0;
        case effSetBypass:        p->setPlain (P_BYPASS, val ? 1.f : 0.f); return 1;
        case effProcessEvents:    p->midiEvents (static_cast<const VstEvents*> (ptr)); return 1;
        case effGetEffectName:
        case effGetProductString: copyStr (ptr, "DJ Scratch", 32); return 1;
        case effGetVendorString:  copyStr (ptr, "ScratchLab", 32); return 1;
        case effGetVendorVersion: return 1100;
        case effGetPlugCategory:  return kPlugCategEffect;
        case effGetVstVersion:    return 2400;
        case effGetTailSize:      return 1;
        case effSetProcessPrecision: return val == 0 ? 1 : 0;
        case effCanDo:
            if (ptr != nullptr && (std::strcmp ((const char*) ptr, "bypass") == 0 || std::strcmp ((const char*) ptr, "receiveVstEvents") == 0
                                   || std::strcmp ((const char*) ptr, "receiveVstMidiEvent") == 0)) return 1;
            return 0;
        default: return 0;
    }
}
void initOnce() { static bool done = false; if (! done) { initParams(); done = true; } }
} // namespace

DS_EXPORT AEffect* VSTPluginMain (audioMasterCallback master)
{
    initOnce();
    void* mem = std::calloc (1, sizeof (Plugin));   // no operator new: keeps libstdc++ out of the link
    if (mem == nullptr) return nullptr;
    Plugin* p = new (mem) Plugin();
    p->master = master;
    p->applyPreset (0);
    AEffect& fx = p->fx;
    fx.magic = kEffectMagic;
    fx.dispatcher = dispatcher;
    fx.process = processAccumulating;
    fx.processReplacing = processReplacing;
    fx.setParameter = setParameter;
    fx.getParameter = getParameter;
    fx.numPrograms = kNumPresets;
    fx.numParams = P_COUNT;
    fx.numInputs = 2;
    fx.numOutputs = 2;
    fx.flags = effFlagsCanReplacing;
    fx.initialDelay = 0;
    fx.ioRatio = 1.f;
    fx.object = p;
    fx.uniqueID = ('D' << 24) | ('J' << 16) | ('S' << 8) | 'C';   // 'DJSC' = 0x444A5343
    fx.version = 1100;
    return &fx;
}
// stable parameter keys for tools/make_skin.py
DS_EXPORT const char* DS_ParamKey (int i) { initOnce(); return (i >= 0 && i < P_COUNT) ? kParams[i].key : ""; }
DS_EXPORT int DS_ParamCount() { return P_COUNT; }
DS_EXPORT const char* DS_PresetName (int i) { return (i >= 0 && i < kNumPresets) ? kPresets[i].name : ""; }
DS_EXPORT int DS_PresetCount() { return kNumPresets; }
