// DJ Scratch file I/O: load a WAV as the record (SAMPLE source), write the plugin's output to a WAV (REC), list a folder.
// libc only (stdio, dirent, malloc), no libstdc++. Never called from the audio thread: the plugin's I/O thread does all of it.
#pragma once
#include <dirent.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/types.h>

namespace dsio
{
// ---------------------------------------------------------------------------------------------- a loaded record
struct Sample
{
    float* l = nullptr; float* r = nullptr;     // r == l for mono files
    int64_t len = 0;                            // frames, at the host rate
    double sr = 0;                              // the host rate it was converted to
    double srcSr = 0; double srcSec = 0;        // the file
    bool truncated = false;                     // longer than the limit: only the start was loaded
    char name[64] = {};                         // file name without .wav
    char path[512] = {};
};
inline void freeSample (Sample* s)
{
    if (s == nullptr) return;
    if (s->r != s->l) free (s->r);
    free (s->l); free (s);
}

inline uint32_t rd32 (const uint8_t* p) { return (uint32_t) p[0] | ((uint32_t) p[1] << 8) | ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24); }
inline uint16_t rd16 (const uint8_t* p) { return (uint16_t) (p[0] | (p[1] << 8)); }

inline void baseName (const char* path, char* out, size_t max)
{
    const char* b = strrchr (path, '/'); b = b ? b + 1 : path;
    snprintf (out, max, "%s", b);
    const size_t n = strlen (out);
    if (n > 4 && strcasecmp (out + n - 4, ".wav") == 0) out[n - 4] = 0;
}

// Load a WAV (PCM 8/16/24/32-bit, float 32/64, WAVE_FORMAT_EXTENSIBLE; mono or stereo, extra channels ignored), keep at most
// maxSec seconds, and convert it to targetSr (4-point Hermite). Returns nullptr and a short reason in err on failure.
inline Sample* loadWav (const char* path, double targetSr, double maxSec, char* err, size_t errn)
{
    FILE* f = fopen (path, "rb");
    if (f == nullptr) { snprintf (err, errn, "can't open file"); return nullptr; }
    uint8_t h[12];
    if (fread (h, 1, 12, f) != 12 || memcmp (h, "RIFF", 4) != 0 || memcmp (h + 8, "WAVE", 4) != 0)
    { fclose (f); snprintf (err, errn, "not a WAV file"); return nullptr; }
    int fmtTag = 0, ch = 0, bits = 0; uint32_t rate = 0; long dataPos = -1; uint32_t dataLen = 0;
    for (;;)
    {
        uint8_t c[8];
        if (fread (c, 1, 8, f) != 8) break;
        const uint32_t sz = rd32 (c + 4);
        const long here = ftell (f);
        if (memcmp (c, "fmt ", 4) == 0 && sz >= 16)
        {
            uint8_t fm[40] = {}; const size_t want = sz < 40 ? sz : 40;
            if (fread (fm, 1, want, f) != want) break;
            fmtTag = rd16 (fm); ch = rd16 (fm + 2); rate = rd32 (fm + 4); bits = rd16 (fm + 14);
            if (fmtTag == 0xFFFE && sz >= 26) fmtTag = rd16 (fm + 24);           // extensible: the sub-format GUID starts with the tag
        }
        else if (memcmp (c, "data", 4) == 0) { dataPos = here; dataLen = sz; break; }
        if (fseek (f, here + (long) sz + (long) (sz & 1u), SEEK_SET) != 0) break;
    }
    const bool isFloat = fmtTag == 3, isPcm = fmtTag == 1;
    if (dataPos < 0 || ch < 1 || rate < 4000 || rate > 384000 || ! ((isPcm && (bits == 8 || bits == 16 || bits == 24 || bits == 32)) || (isFloat && (bits == 32 || bits == 64))))
    { fclose (f); snprintf (err, errn, "unsupported WAV format"); return nullptr; }
    const int bps = bits / 8, frameBytes = bps * ch;
    int64_t frames = (int64_t) (dataLen / (uint32_t) frameBytes);
    if (dataLen == 0 || dataLen == 0xFFFFFFFFu)                                  // unfinished header: use the file size
    {
        fseek (f, 0, SEEK_END); const long end = ftell (f);
        frames = (end - dataPos) / frameBytes;
    }
    const double srcSec = (double) frames / rate;
    bool truncated = false;
    const int64_t maxFrames = (int64_t) (maxSec * rate);
    if (frames > maxFrames) { frames = maxFrames; truncated = true; }
    if (frames < 16) { fclose (f); snprintf (err, errn, "file is empty"); return nullptr; }
    const bool stereo = ch >= 2;

    float* sl = (float*) malloc (sizeof (float) * (size_t) frames);
    float* sr2 = stereo ? (float*) malloc (sizeof (float) * (size_t) frames) : sl;
    uint8_t* buf = (uint8_t*) malloc ((size_t) frameBytes * 4096);
    if (sl == nullptr || sr2 == nullptr || buf == nullptr)
    { free (buf); if (sr2 != sl) free (sr2); free (sl); fclose (f); snprintf (err, errn, "out of memory"); return nullptr; }
    fseek (f, dataPos, SEEK_SET);
    int64_t got = 0;
    while (got < frames)
    {
        const int64_t want = (frames - got) < 4096 ? (frames - got) : 4096;
        const size_t rdn = fread (buf, (size_t) frameBytes, (size_t) want, f);
        if (rdn == 0) break;
        for (size_t k = 0; k < rdn; ++k)
            for (int c = 0; c < (stereo ? 2 : 1); ++c)
            {
                const uint8_t* q = buf + k * (size_t) frameBytes + (size_t) (c * bps);
                float x;
                if (isFloat) { if (bits == 32) { float t; memcpy (&t, q, 4); x = t; } else { double t; memcpy (&t, q, 8); x = (float) t; } }
                else if (bits == 8) x = ((float) q[0] - 128.f) / 128.f;
                else if (bits == 16) x = (float) (int16_t) rd16 (q) / 32768.f;
                else if (bits == 24) x = (float) ((int32_t) (((uint32_t) q[0] << 8) | ((uint32_t) q[1] << 16) | ((uint32_t) q[2] << 24)) >> 8) / 8388608.f;
                else x = (float) ((double) (int32_t) rd32 (q) / 2147483648.0);
                if (! (x == x)) x = 0.f;                                          // NaN in a float file
                (c == 0 ? sl : sr2)[got + (int64_t) k] = x;
            }
        got += (int64_t) rdn;
    }
    free (buf); fclose (f);
    if (got < 16) { if (sr2 != sl) free (sr2); free (sl); snprintf (err, errn, "file is empty"); return nullptr; }
    frames = got;

    Sample* s = (Sample*) calloc (1, sizeof (Sample));
    if (s == nullptr) { if (sr2 != sl) free (sr2); free (sl); snprintf (err, errn, "out of memory"); return nullptr; }
    s->srcSr = rate; s->srcSec = srcSec; s->truncated = truncated; s->sr = targetSr;
    snprintf (s->path, sizeof s->path, "%s", path); baseName (path, s->name, sizeof s->name);
    if (fabs ((double) rate - targetSr) < 0.5)
    {
        s->l = sl; s->r = sr2; s->len = frames;
        return s;
    }
    // sample-rate conversion to the host rate (4-point Hermite; fine for scratching, the platter interpolates anyway)
    const double step = (double) rate / targetSr;
    const int64_t outN = (int64_t) floor ((double) (frames - 1) / step) + 1;
    float* ol = (float*) malloc (sizeof (float) * (size_t) outN);
    float* orr = stereo ? (float*) malloc (sizeof (float) * (size_t) outN) : ol;
    if (ol == nullptr || orr == nullptr)
    { if (orr != ol) free (orr); free (ol); if (sr2 != sl) free (sr2); free (sl); free (s); snprintf (err, errn, "out of memory"); return nullptr; }
    for (int c = 0; c < (stereo ? 2 : 1); ++c)
    {
        const float* in = c == 0 ? sl : sr2; float* out = c == 0 ? ol : orr;
        for (int64_t j = 0; j < outN; ++j)
        {
            const double pos = (double) j * step; const int64_t i = (int64_t) pos; const float t = (float) (pos - (double) i);
            auto at = [&] (int64_t k) { return in[k < 0 ? 0 : (k >= frames ? frames - 1 : k)]; };
            const float y0 = at (i - 1), y1 = at (i), y2 = at (i + 1), y3 = at (i + 2);
            const float c1 = 0.5f * (y2 - y0), c2 = y0 - 2.5f * y1 + 2.f * y2 - 0.5f * y3, c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
            out[j] = ((c3 * t + c2) * t + c1) * t + y1;
        }
    }
    if (sr2 != sl) free (sr2);
    free (sl);
    s->l = ol; s->r = orr; s->len = outN;
    return s;
}

// ---------------------------------------------------------------------------------------------- WAV writer (24-bit stereo PCM)
struct WavWriter
{
    FILE* f = nullptr; uint32_t frames = 0; uint32_t rate = 44100;
    bool open (const char* path, uint32_t sr)
    {
        f = fopen (path, "wb"); frames = 0; rate = sr;
        if (f == nullptr) return false;
        writeHeader();
        return ferror (f) == 0;
    }
    void writeHeader()
    {
        const uint32_t data = frames * 6u, riff = 36u + data, fmtLen = 16, br = rate * 6u;
        const uint16_t pcm = 1, ch = 2, ba = 6, bits = 24;
        fwrite ("RIFF", 1, 4, f); fwrite (&riff, 4, 1, f); fwrite ("WAVEfmt ", 1, 8, f); fwrite (&fmtLen, 4, 1, f);
        fwrite (&pcm, 2, 1, f); fwrite (&ch, 2, 1, f); fwrite (&rate, 4, 1, f); fwrite (&br, 4, 1, f); fwrite (&ba, 2, 1, f); fwrite (&bits, 2, 1, f);
        fwrite ("data", 1, 4, f); fwrite (&data, 4, 1, f);
    }
    // interleaved L R float frames
    bool write (const float* lr, uint32_t n)
    {
        if (f == nullptr) return false;
        if ((uint64_t) frames + n > 0x7FFFFFFFull / 6u) return false;               // stay far under the 4 GB WAV limit
        uint8_t b[6 * 512];
        uint32_t done = 0;
        while (done < n)
        {
            const uint32_t m = (n - done) < 512 ? (n - done) : 512;
            for (uint32_t k = 0; k < m * 2; ++k)
            {
                float x = lr[done * 2 + k]; x = x > 1.f ? 1.f : (x < -1.f ? -1.f : (x == x ? x : 0.f));
                const int32_t v = (int32_t) lrintf (x * 8388607.f);
                b[k * 3] = (uint8_t) (v & 0xFF); b[k * 3 + 1] = (uint8_t) ((v >> 8) & 0xFF); b[k * 3 + 2] = (uint8_t) ((v >> 16) & 0xFF);
            }
            if (fwrite (b, 6, m, f) != m) return false;
            done += m;
        }
        frames += n;
        return true;
    }
    bool close()
    {
        if (f == nullptr) return false;
        bool ok = fseek (f, 0, SEEK_SET) == 0;
        if (ok) writeHeader();
        ok = ok && fflush (f) == 0 && ferror (f) == 0;
        ok = (fclose (f) == 0) && ok; f = nullptr;
        return ok;
    }
};

// After a take (AFTER REC): normalize a 24-bit stereo WAV written by WavWriter to -0.3 dBFS (optional) and give it a short
// fade in / fade out so the cut edges don't click. Works in place, in small chunks.
inline bool finishWav24 (const char* path, bool normalize, double fadeInMs, double fadeOutMs)
{
    FILE* f = fopen (path, "r+b");
    if (f == nullptr) return false;
    uint8_t h[44];
    if (fread (h, 1, 44, f) != 44 || memcmp (h, "RIFF", 4) != 0 || rd16 (h + 22) != 2 || rd16 (h + 34) != 24) { fclose (f); return false; }
    const uint32_t rate = rd32 (h + 24), frames = rd32 (h + 40) / 6u;
    if (frames == 0) { fclose (f); return true; }
    auto get24 = [] (const uint8_t* q) { return (int32_t) (((uint32_t) q[0] << 8) | ((uint32_t) q[1] << 16) | ((uint32_t) q[2] << 24)) >> 8; };
    uint8_t b[6 * 1024];
    double gain = 1.0;
    if (normalize)
    {
        int32_t peak = 0;
        fseek (f, 44, SEEK_SET);
        for (uint32_t k = 0; k < frames; )
        {
            const uint32_t m = (frames - k) < 1024 ? (frames - k) : 1024;
            if (fread (b, 6, m, f) != m) { fclose (f); return false; }
            for (uint32_t j = 0; j < m * 2; ++j) { int32_t v = get24 (b + j * 3); if (v < 0) v = -v; if (v > peak) peak = v; }
            k += m;
        }
        if (peak > 0) { gain = 0.9661 * 8388607.0 / (double) peak; if (gain > 1000.0) gain = 1000.0; }       // -0.3 dBFS, at most +60 dB
    }
    const uint32_t fin = (uint32_t) (fadeInMs * 0.001 * rate), fout = (uint32_t) (fadeOutMs * 0.001 * rate);
    for (uint32_t k = 0; k < frames; )
    {
        const uint32_t m = (frames - k) < 1024 ? (frames - k) : 1024;
        const long pos = 44L + (long) k * 6L;
        fseek (f, pos, SEEK_SET);
        if (fread (b, 6, m, f) != m) { fclose (f); return false; }
        for (uint32_t j = 0; j < m; ++j)
        {
            const uint32_t fr = k + j;
            double g = gain;
            if (fin > 0 && fr < fin) g *= (double) fr / (double) fin;
            if (fout > 0 && frames - 1 - fr < fout) g *= (double) (frames - 1 - fr) / (double) fout;
            for (int c = 0; c < 2; ++c)
            {
                uint8_t* q = b + j * 6 + c * 3;
                double x = (double) get24 (q) * g;
                if (x > 8388607.0) x = 8388607.0;
                if (x < -8388608.0) x = -8388608.0;
                const int32_t v = (int32_t) lrint (x);
                q[0] = (uint8_t) (v & 0xFF); q[1] = (uint8_t) ((v >> 8) & 0xFF); q[2] = (uint8_t) ((v >> 16) & 0xFF);
            }
        }
        fseek (f, pos, SEEK_SET);
        if (fwrite (b, 6, m, f) != m) { fclose (f); return false; }
        k += m;
    }
    const bool ok = fflush (f) == 0 && ferror (f) == 0;
    return (fclose (f) == 0) && ok;
}

// ---------------------------------------------------------------------------------------------- folders
inline bool isDir (const char* p) { struct stat st; return stat (p, &st) == 0 && S_ISDIR (st.st_mode); }
inline bool makeDirs (const char* path)                  // mkdir -p
{
    char b[512]; snprintf (b, sizeof b, "%s", path);
    for (char* q = b + 1; *q; ++q)
        if (*q == '/') { *q = 0; if (! isDir (b) && mkdir (b, 0777) != 0 && errno != EEXIST) return false; *q = '/'; }
    return isDir (b) || mkdir (b, 0777) == 0 || errno == EEXIST;
}
inline bool hasWavExt (const char* n) { const size_t k = strlen (n); return k > 4 && strcasecmp (n + k - 4, ".wav") == 0; }

// The .wav files in dir (not hidden, not macOS "._" files), sorted by name; returns how many were written into names.
inline int listWavs (const char* dir, char (*names)[128], int max)
{
    DIR* d = opendir (dir);
    if (d == nullptr) return 0;
    int n = 0;
    while (n < max)
    {
        struct dirent* e = readdir (d);
        if (e == nullptr) break;
        if (e->d_name[0] == '.' || ! hasWavExt (e->d_name)) continue;
        char full[640]; snprintf (full, sizeof full, "%s/%s", dir, e->d_name);
        struct stat st; if (stat (full, &st) != 0 || ! S_ISREG (st.st_mode)) continue;
        snprintf (names[n], 128, "%s", e->d_name); ++n;
    }
    closedir (d);
    qsort (names, (size_t) n, sizeof names[0], [] (const void* a, const void* b) { return strcasecmp ((const char*) a, (const char*) b); });
    return n;
}

// The next free DJScratch-NNN.wav number in dir.
inline int nextTakeNumber (const char* dir)
{
    int best = 0;
    DIR* d = opendir (dir);
    if (d == nullptr) return 1;
    while (struct dirent* e = readdir (d))
    {
        const char* q = e->d_name;
        if (strncmp (q, "DJScratch-", 10) != 0) continue;
        q += 10; int k = 0, digits = 0;
        while (*q >= '0' && *q <= '9' && digits < 7) { k = k * 10 + (*q - '0'); ++q; ++digits; }
        if (digits > 0 && strcasecmp (q, ".wav") == 0 && k > best) best = k;
    }
    closedir (d);
    return best + 1;
}
} // namespace dsio
