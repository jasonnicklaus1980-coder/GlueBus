# DJ Scratch (MPC)

Scratch the sound coming into an MPC track, submix or the master. A native **MPC OS VST2 insert effect** for Gen1
devices (MPC X, Live / Live II, One, Key 61, Force), built on the same toolchain, installer and skin pipeline as the SP1200 plugin.

    incoming audio > ring buffer (8+ s, always recording) > read head (the "needle") or loop > crossfade with the live signal > transformer gate > fader > output

- **Transparent when idle**: bit-exact pass-through, zero latency.
- **Platter**: drag on it or turn Q-Link 1; the head follows like a record under your hand (two-pole smoothing = INERTIA,
  4-point Hermite interpolation, a stopped record is silent).
- **Slip or catch-up return**, **backspin**, **fader + chop** (hand transform scratches), 17 presets.
- **Loop by note value** (1/32 .. 1 bar, triplets too) at the host tempo: repeats the last audio, change the value to roll, crossfaded wrap.
- **Transformer**: tempo-synced gate (rate, open %, 4 patterns), locked to the host beat position while the transport plays.
- **MIDI notes** (if the host sends them to an insert): C..G# hold loops, A backspin, A# chop, B transformer.
- Three screen pages (SCRATCH, GROOVE, SETUP) with a rotating record, tap keys, readouts and Q-Link maps. See `docs/skin-preview-*.png`.

How to use it: **`mpc/INSTALL.md`**.

## Build + install
    make abi32                        # 32-bit VST2 struct layout check (what the ARM MPC sees)
    make test                         # engine_test (ASan/UBSan) + host_test (VST2 interface and a scratch gesture through setParameter)
    python3 tools/make_skin.py docs   # regenerate the skin and previews (needs Pillow and `make native`)
    ./scripts/package.sh              # cross-compiles for ARM, verifies the ELF, makes dist/DJScratch-1.1.0-mpc-armv7.zip
    ./scripts/verify_arm.sh [file.so] # checks a .so against the SP1200 reference (ELF32 ARM, hard-float, libc/libm only)
./scripts/deploy.sh <mpc-ip>      # tar-over-ssh, runs install.sh
`package.sh` needs `arm-linux-gnueabihf-g++` (`apt install g++-arm-linux-gnueabihf`) or Docker (it uses `make docker`).
`make host_test` can also write a demo: `./build/native/host_test build/native/djscratch.so demo.wav`.

## Layout
    src/scratch/Scratch.h   the engine (ring buffer, platter model, states LIVE / GRAB / SPIN / RETURN, fader)
    src/djscratch.cpp       VST2 entry points, parameter table, presets, status readout
    src/vst2.h              minimal VST2 ABI (no Steinberg SDK)
    tools/make_skin.py      TUI.json, Q-Links and PNGs for the MPC screen
    mpc/                    installer, uninstaller, plugin-list entry, skin, INSTALL.md
    test/                   engine_test.cpp, host_test.cpp

## Status: what is tested and what is not
Tested here, on x86: the DSP (engine_test, 51 checks, under AddressSanitizer and UBSan) and the plugin through a VST2 host
harness (host_test, 114 checks, including loop, gate, host tempo and MIDI notes), and the installer in a fake MPC root.
**Not tested on a device**: the ARM build (no ARM compiler where this was written), CPU load, how the MPC's touch drag maps to the
PLATTER value (set THROW to taste), whether the MPC reports tempo and beat position to an insert effect (the plugin falls back to 120 BPM or the Tempo control),
whether it sends MIDI notes to an insert at all, and whether MPC updates the keys / platter control when the plugin changes them itself
(tap keys spring back, the platter re-centres, the status line): the same host notification the SP1200 uses for its readouts.
The skin follows the SP1200 skin's proven rules, but the platter's big drag area is new.
