// Engine tests (no host needed). Built with ASan + UBSan, so any ring-buffer overrun fails loudly.
// Input is a rising ramp x[n] = n * 1e-6 (so "which sample is this?" is readable from the output value) or a sine.
#include "scratch/Scratch.h"
#include <cstdio>
#include <vector>

using namespace ds;
static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { ++checks; if (! (cond)) { ++fails; std::printf ("  FAIL line %d: %s  ", __LINE__, #cond); std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)

static const double SR = 44100.0;
static const int BLK = 128;

struct Rig
{
    Engine e; Settings s; long t = 0; std::vector<float> in, out; bool ppqSync = false;
    Rig() { e.prepare (SR); in.resize (BLK); out.resize (BLK); }
    // run `frames` frames, input = ramp; returns the last output sample. The optional callback sees every output sample.
    template <class F> void run (long frames, F f)
    {
        while (frames > 0)
        {
            const int n = frames < BLK ? (int) frames : BLK;
            if (ppqSync) { s.ppqValid = true; s.ppq = (double) t / SR * s.bpm / 60.0; }
            for (int i = 0; i < n; ++i) in[i] = (float) ((t + i) * 1e-6);
            e.process (in.data(), in.data(), out.data(), out.data() + 0, n, s);   // L and R share one buffer: harmless, same data
            for (int i = 0; i < n; ++i) f (t + i, in[i], out[i]);
            t += n; frames -= n;
        }
    }
    void run (long frames) { run (frames, [] (long, float, float) {}); }
};

static void testPassthrough()
{
    std::printf ("passthrough\n");
    Rig r; r.s.autoGrab = true;
    int bad = 0;
    r.run (SR * 2, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (bad == 0, "%d samples differ from the input while idle", bad);
    CHECK (r.e.state() == Engine::LIVE, "state");
}

static void testSilenceWhenHeld()
{
    std::printf ("held record is silent\n");
    Rig r; r.s.hold = true;
    r.run (SR * 0.5);
    float peak = 0;
    r.run (SR * 0.5, [&] (long, float, float out) { peak = std::fmax (peak, std::fabs (out)); });
    CHECK (r.e.state() == Engine::GRAB, "state %d", (int) r.e.state());
    CHECK (peak < 1e-5f, "peak %g while stopped (the ramp input is ~0.02-0.09)", (double) peak);
}

static void testBackAndForth()
{
    std::printf ("moving the platter back plays the past backwards, forward plays it forwards\n");
    Rig r; r.s.autoGrab = true; r.s.throwSec = 1.0f; r.s.inertiaMs = 6.f;
    r.run (SR * 2);                              // fill history
    // move the platter back 0.1 (= 0.1 s of audio) over ~100 ms, in 10 steps like a hand would
    long tStart = r.t;
    float p = 0.5f;
    std::vector<float> o;
    for (int step = 0; step < 10; ++step)
    {
        p -= 0.01f; r.s.platter = p;
        r.run (BLK * 4, [&] (long, float, float out) { o.push_back (out); });
    }
    // while moving backwards the ramp output must be decreasing (reading earlier samples)
    int dec = 0, inc = 0;
    for (size_t i = 1; i < o.size(); ++i) { if (o[i] < o[i - 1] - 1e-9f) ++dec; else if (o[i] > o[i - 1] + 1e-9f) ++inc; }
    CHECK (dec > inc * 5, "decreasing %d vs increasing %d", dec, inc);
    // head ends about 0.1 s behind where it was at tStart: compare with ramp
    const float expect = (float) ((tStart) * 1e-6) - 0.1f * 0.0441f;    // (sample index) * 1e-6, 0.1 s = 4410 frames
    (void) expect;
    CHECK (r.e.state() == Engine::GRAB, "state");
    CHECK (r.e.behindSec() > 0.05f && r.e.behindSec() < 0.35f, "behind %g s", (double) r.e.behindSec());
    // now forward 0.05 back toward live: output must increase
    o.clear();
    for (int step = 0; step < 5; ++step) { p += 0.01f; r.s.platter = p; r.run (BLK * 4, [&] (long, float, float out) { o.push_back (out); }); }
    dec = inc = 0;
    for (size_t i = 1; i < o.size(); ++i) { if (o[i] < o[i - 1] - 1e-9f) ++dec; else if (o[i] > o[i - 1] + 1e-9f) ++inc; }
    CHECK (inc > dec * 5, "increasing %d vs decreasing %d", inc, dec);
}

static void testSlipReturn()
{
    std::printf ("slip: lets go -> back to bit-exact live\n");
    Rig r; r.s.returnMode = 0; r.s.releaseSec = 0.2f;
    r.run (SR);
    r.s.platter = 0.45f; r.run (SR * 0.1);
    CHECK (r.e.state() == Engine::GRAB, "state %d", (int) r.e.state());
    r.run (SR * 0.5);                            // still -> after releaseSec it lets go
    int bad = 0; float lastDiff = 0;
    r.run (SR * 0.2, [&] (long, float in, float out) { if (in != out) { ++bad; lastDiff = out - in; } });
    CHECK (r.e.state() == Engine::LIVE, "state %d", (int) r.e.state());
    CHECK (bad == 0, "%d samples differ after returning (last diff %g)", bad, (double) lastDiff);
    CHECK (std::fabs (r.s.platter - 0.45f) < 1e-6f, "engine must not change the settings struct");
}

static void testCatchUp()
{
    std::printf ("catch up: output races forward then lands on live\n");
    Rig r; r.s.returnMode = 1; r.s.catchSpeed = 3.f; r.s.releaseSec = 0.15f;
    r.run (SR);
    r.s.platter = 0.30f; r.run (SR * 0.15);      // ~0.2 s back
    const float back0 = r.e.behindSec();
    CHECK (back0 > 0.1f, "behind %g", (double) back0);
    bool sawReturn = false;
    r.run (SR * 0.9, [&] (long, float, float) { if (r.e.state() == Engine::RETURN) sawReturn = true; });   // let go
    CHECK (sawReturn, "never entered RETURN");
    r.run (SR * 0.3);
    int bad = 0;
    r.run (SR * 0.1, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (r.e.state() == Engine::LIVE, "state %d", (int) r.e.state());
    CHECK (bad == 0, "%d samples differ once caught up", bad);
}

static void testBackspin()
{
    std::printf ("backspin\n");
    Rig r; r.s.spinSpeed = 8.f; r.s.spinSec = 1.0f; r.s.returnMode = 0;
    r.run (SR * 3);
    r.e.triggerBackspin();
    std::vector<float> o; bool sawSpin = false; float minVel = 0;
    r.run (SR * 1.5, [&] (long, float, float out) { o.push_back (out); if (r.e.state() == Engine::SPIN) { sawSpin = true; minVel = std::fmin (minVel, r.e.velocity()); } });
    CHECK (sawSpin, "never spun");
    CHECK (minVel < -4.f, "start velocity only %g", (double) minVel);
    int dec = 0, inc = 0;
    for (size_t i = 1; i < 4000 && i < o.size(); ++i) { if (o[i] < o[i - 1]) ++dec; else if (o[i] > o[i - 1]) ++inc; }
    CHECK (dec > inc * 5, "first 90 ms should play backwards: dec %d inc %d", dec, inc);
    r.run (SR * 0.5);
    int bad = 0;
    r.run (SR * 0.1, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (r.e.state() == Engine::LIVE && bad == 0, "state %d, %d differ", (int) r.e.state(), bad);
}

static void testChopAndFader()
{
    std::printf ("chop / fader\n");
    Rig r; r.s.chopMs = 50.f; r.s.cutMs = 1.f;
    r.run (SR * 0.5);
    r.e.triggerChop();
    float minAbs = 1e9f; long muted = 0;
    r.run (SR * 0.2, [&] (long, float, float out) { if (std::fabs (out) < 1e-9f) ++muted; minAbs = std::fmin (minAbs, std::fabs (out)); });
    const double ms = muted / SR * 1000.0;
    CHECK (ms > 40 && ms < 56, "muted for %.1f ms, expected ~50 minus fades", ms);
    int bad = 0;
    r.run (SR * 0.1, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (bad == 0, "not back to pass-through after the chop (%d)", bad);
    // closed fader + chop = a short open blip (transform)
    r.s.faderClosed = true; r.run (SR * 0.1);
    r.e.triggerChop(); long open = 0;
    r.run (SR * 0.2, [&] (long, float, float out) { if (std::fabs (out) > 1e-4f) ++open; });
    CHECK (open / SR * 1000.0 > 35, "open for %.1f ms", open / SR * 1000.0);
}

static void testBoundsAndFinite()
{
    std::printf ("extreme gestures stay finite and inside the ring (ASan would flag overruns)\n");
    Rig r; r.s.inertiaMs = 3.f; r.s.throwSec = 4.f; r.s.returnMode = 1;
    uint32_t rng = 12345; bool finite = true; float peak = 0;
    for (int blk = 0; blk < 4000; ++blk)
    {
        rng = rng * 1664525u + 1013904223u;
        if ((rng >> 24) < 60) r.s.platter = (float) ((rng >> 8) & 0xffff) / 65535.f;
        if ((rng >> 20) % 97 == 0) r.e.triggerBackspin();
        if ((rng >> 20) % 89 == 0) r.e.triggerChop();
        if ((rng >> 20) % 211 == 0) r.s.hold = ! r.s.hold;
        if ((rng >> 20) % 301 == 0) r.s.returnMode = 1 - r.s.returnMode;
        if ((rng >> 20) % 173 == 0) { r.s.loopOn = ! r.s.loopOn; r.s.loopBeats = (double) (1 + (rng >> 4) % 16) * 0.125; r.s.bpm = 40.0 + (double) ((rng >> 9) % 200); }
        if ((rng >> 20) % 131 == 0) { r.s.tOn = ! r.s.tOn; r.s.tMask = (rng >> 3) & 0xFFFF; r.s.tStepBeats = 0.125 * (double) (1 + (rng >> 11) % 8); }
        if ((rng >> 20) % 499 == 0) r.s.bypass = ! r.s.bypass;
        r.run (BLK, [&] (long, float, float out) { if (! std::isfinite (out)) finite = false; peak = std::fmax (peak, std::fabs (out)); });
    }
    CHECK (finite, "non-finite output");
    CHECK (peak < 1.5f, "peak %g", (double) peak);
}


static void testLoop()
{
    std::printf("loop by note value\n");
    Rig r; r.s.bpm = 120; r.s.loopBeats = 0.25;               // 1/16 note at 120 BPM = 0.125 s
    const long L = (long) std::llround (0.25 * 60.0 / 120.0 * SR);
    r.run (SR * 2);
    r.s.loopOn = true;
    std::vector<float> o; r.run (SR * 1, [&] (long, float, float out) { o.push_back (out); });
    CHECK (r.e.state() == Engine::LOOP, "state %d", (int) r.e.state());
    CHECK (std::fabs (r.e.loopSec() - 0.125f) < 0.001f, "loop %.4f s", (double) r.e.loopSec());
    // after the 5 ms fade-in: periodic with period L, and every value comes from the last L frames before the press
    const float lo = (float) ((2 * SR - L - 200) * 1e-6), hi = (float) ((2 * SR) * 1e-6);
    int notPeriodic = 0, outOfRange = 0; float maxJump = 0;
    for (size_t i = 600; i + L < o.size(); ++i) { if (std::fabs (o[i] - o[i + L]) > 1e-7f) ++notPeriodic; }
    for (size_t i = 600; i < o.size(); ++i) { if (o[i] < lo || o[i] > hi) ++outOfRange; if (i > 600) maxJump = std::fmax (maxJump, std::fabs (o[i] - o[i - 1])); }
    CHECK (notPeriodic == 0, "%d samples differ from one loop earlier", notPeriodic);
    CHECK (outOfRange == 0, "%d samples outside the captured window", outOfRange);
    // wrap is crossfaded (the ramp's loop wrap is a big step otherwise: L * 1e-6)
    CHECK (maxJump < 0.5f * (float) (L * 1e-6), "wrap jump %.5f vs raw step %.5f", (double) maxJump, (double) (L * 1e-6));
    // release: back to bit-exact live
    r.s.loopOn = false; r.run (SR * 0.1);
    int bad = 0; r.run (SR * 0.2, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (r.e.state() == Engine::LIVE && bad == 0, "state %d, %d samples differ after release", (int) r.e.state(), bad);
    // changing the note value while looping re-captures a different length of the same audio
    r.s.loopOn = true; r.s.loopBeats = 0.5; r.run (SR * 0.2);
    CHECK (std::fabs (r.e.loopSec() - 0.25f) < 0.001f, "1/8 note loop %.4f s", (double) r.e.loopSec());
    r.s.loopBeats = 1.0 / 3.0; r.run (SR * 0.2);
    CHECK (std::fabs (r.e.loopSec() - 0.1667f) < 0.002f, "1/8 triplet loop %.4f s", (double) r.e.loopSec());
    r.s.loopOn = false; r.run (SR * 0.3);
    // tempo scales the length
    r.s.bpm = 60; r.s.loopBeats = 1.0; r.s.loopOn = true; r.run (SR * 0.2);
    CHECK (std::fabs (r.e.loopSec() - 1.0f) < 0.002f, "1/4 note at 60 BPM = %.4f s", (double) r.e.loopSec());
    r.s.loopOn = false; r.run (SR * 0.3);
    // not enough audio yet: refuses, stays live and transparent
    Rig q; q.s.bpm = 120; q.s.loopBeats = 4.0; q.run (SR * 0.05); q.s.loopOn = true;
    int bad2 = 0; q.run (SR * 0.1, [&] (long, float in, float out) { if (in != out) ++bad2; });
    CHECK (q.e.state() == Engine::LIVE && q.e.loopFailed() && bad2 == 0, "short history: state %d failed %d differ %d", (int) q.e.state(), (int) q.e.loopFailed(), bad2);
    // a loop can be taken out of a scratch, and a scratch cannot start inside a loop
    Rig u; u.s.bpm = 120; u.s.loopBeats = 0.5; u.run (SR);
    u.s.platter = 0.4f; u.run (SR * 0.1); u.s.loopOn = true; u.run (SR * 0.1);
    CHECK (u.e.state() == Engine::LOOP, "loop from scratch: state %d", (int) u.e.state());
    u.s.platter = 0.2f; u.e.triggerBackspin(); u.run (SR * 0.2);
    CHECK (u.e.state() == Engine::LOOP, "platter/backspin ignored while looping: state %d", (int) u.e.state());
    // recording is frozen during a loop: after release the history continues from where the loop started
    u.s.loopOn = false; u.run (SR * 0.5);
    CHECK (u.e.state() != Engine::LOOP, "state %d", (int) u.e.state());
}

static void testTransformer()
{
    std::printf("transformer gate\n");
    // straight 1/16 at 120 BPM, 50 % duty, free-running: steps of 125 ms, open for the first half of each
    Rig r; r.s.bpm = 120; r.s.tOn = true; r.s.tStepBeats = 0.25; r.s.tDuty = 0.5f; r.s.tMask = 0xFFFF; r.s.cutMs = 0.5f;
    r.run (SR * 0.5);
    std::vector<float> o; r.run (SR * 2, [&] (long, float, float out) { o.push_back (out); });
    long open = 0; for (float x : o) if (std::fabs (x) > 1e-9f) ++open;
    CHECK (std::fabs ((double) open / (double) o.size() - 0.5) < 0.04, "open %.1f %% (expected ~50)", 100.0 * (double) open / (double) o.size());
    // gate edges are 62.5 ms apart (to within the 0.5 ms fade)
    std::vector<long> edges; bool was = false;
    for (size_t i = 0; i < o.size(); ++i) { const bool on = std::fabs (o[i]) > 1e-9f; if (on != was) { edges.push_back ((long) i); was = on; } }
    int badGap = 0; for (size_t k = 2; k + 1 < edges.size(); ++k) if (std::labs ((edges[k] - edges[k - 1]) - (long) (0.0625 * SR)) > 80) ++badGap;
    CHECK (edges.size() > 25 && badGap == 0, "%zu edges, %d irregular", edges.size(), badGap);
    // offbeat pattern with duty 100 %: odd steps only, half the time, period of two steps
    Rig p; p.s.bpm = 120; p.s.tOn = true; p.s.tStepBeats = 0.25; p.s.tDuty = 1.f; p.s.tMask = 0xAAAA; p.s.cutMs = 0.5f;
    p.run (SR * 0.5); o.clear(); p.run (SR * 2, [&] (long, float, float out) { o.push_back (out); });
    open = 0; for (float x : o) if (std::fabs (x) > 1e-9f) ++open;
    CHECK (std::fabs ((double) open / (double) o.size() - 0.5) < 0.03, "offbeat open %.1f %%", 100.0 * (double) open / (double) o.size());
    // locked to host position: gate follows ppq, whatever happened before
    Rig h; h.s.bpm = 120; h.s.tOn = true; h.s.tStepBeats = 0.5; h.s.tDuty = 0.5f; h.s.tMask = 0xFFFF; h.s.cutMs = 0.5f; h.ppqSync = true;
    h.run (SR * 0.37);   // arbitrary start
    long agree = 0, total = 0;
    h.run (SR * 2, [&] (long t, float, float out) {
        const double beat = (double) t / SR * 2.0; const double fr = beat / 0.5 - std::floor (beat / 0.5);
        if (fr > 0.02 && fr < 0.48 && t > 100) { ++total; if (std::fabs (out) > 1e-9f) ++agree; }
        if (fr > 0.52 && fr < 0.98 && t > 100) { ++total; if (std::fabs (out) < 1e-9f) ++agree; }
    });
    CHECK (total > 50000 && agree == total, "ppq lock: %ld of %ld samples as expected", agree, total);
    // off: exact pass-through; bypass beats the gate
    Rig q; q.s.tOn = false; int bad = 0; q.run (SR, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (bad == 0, "gate off is transparent (%d)", bad);
    Rig b; b.s.tOn = true; b.s.bypass = true; b.s.tMask = 0; bad = 0; b.run (SR, [&] (long, float in, float out) { if (in != out) ++bad; });
    CHECK (bad == 0, "bypass beats the gate (%d)", bad);
    // gate + loop together
    Rig g; g.s.bpm = 120; g.s.loopBeats = 0.5; g.s.tOn = true; g.s.tStepBeats = 0.125; g.s.tDuty = 0.5f; g.run (SR * 2); g.s.loopOn = true;
    float pk = 0; bool fin = true; g.run (SR * 2, [&] (long, float, float out) { pk = std::fmax (pk, std::fabs (out)); if (! std::isfinite (out)) fin = false; });
    CHECK (fin && pk > 0.05f && g.e.state() == Engine::LOOP, "loop + gate: peak %.3f state %d", (double) pk, (int) g.e.state());
}

static void testSampleRates()
{
    std::printf ("other sample rates\n");
    for (double sr : { 22050.0, 48000.0, 96000.0 })
    {
        Engine e; CHECK (e.prepare (sr), "prepare %g", sr);
        Settings s; s.hold = true; std::vector<float> a (256, 0.25f), o (256);
        for (int i = 0; i < 2000; ++i) e.process (a.data(), a.data(), o.data(), o.data(), 256, s);
        CHECK (e.state() == Engine::GRAB, "state at %g", sr);
    }
}

int main()
{
    testPassthrough(); testSilenceWhenHeld(); testBackAndForth(); testSlipReturn(); testCatchUp(); testBackspin(); testChopAndFader();
    testLoop(); testTransformer(); testBoundsAndFinite(); testSampleRates();
    std::printf ("\n%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
