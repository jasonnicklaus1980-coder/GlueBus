// Offline VST2 host test for DJ Scratch: loads the .so like MPC does and checks the plugin interface (parameters,
// presets, tap keys, platter re-centring, bypass) and a full scratch gesture driven through setParameter, at several
// block sizes. Optional: pass an output path as 2nd argument to write a demo WAV of a scratch routine.
#include "vst2.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <string>
#include <vector>

static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { ++checks; if (! (cond)) { ++fails; std::printf ("  FAIL: "); std::printf (__VA_ARGS__); std::printf ("\n"); } \
                              else { std::printf ("  ok:   "); std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)
typedef AEffect* (*MainFn) (audioMasterCallback);
typedef const char* (*KeyFn) (int);
static KeyFn keyOf;
static int automates = 0; static int lastAutoIdx = -1; static float lastAutoVal = -1;
static VstTimeInfo gTime; static bool gTimeOn = false; static double gTempo = 120.0; static bool gPlaying = false;
static intptr_t host (AEffect*, int32_t op, int32_t index, intptr_t, void*, float opt)
{
    if (op == 0) { ++automates; lastAutoIdx = index; lastAutoVal = opt; }
    if (op == audioMasterGetTime)
    {
        if (! gTimeOn) return 0;
        gTime.tempo = gTempo; gTime.flags = kVstTempoValid | kVstPpqPosValid | (gPlaying ? kVstTransportPlaying : 0);
        return (intptr_t) &gTime;
    }
    return op == 1 ? 2400 : 0;
}
static AEffect* fx;
static float SR = 44100.f;
static intptr_t D (int op, int idx = 0, intptr_t val = 0, void* p = nullptr, float opt = 0) { return fx->dispatcher (fx, op, idx, val, p, opt); }
static int idx (const char* k) { for (int i = 0; i < fx->numParams; ++i) if (std::strcmp (keyOf (i), k) == 0) return i; std::printf ("no param %s\n", k); std::exit (2); }
static void setN (const char* k, float n) { fx->setParameter (fx, idx (k), n); }
static float getN (const char* k) { return fx->getParameter (fx, idx (k)); }
static std::string text (const char* k) { char b[256] = {}; D (effGetParamDisplay, idx (k), 0, b); return b; }

// Drives the plugin with a sine and records the output; `hook(blockIndex)` runs before every block.
struct Session
{
    std::vector<float> in, out; int block; long t = 0;
    explicit Session (int blk) : block (blk) {}
    template <class F> void run (long frames, F hook, double hz = 220.0)
    {
        std::vector<float> a (block), b (block), ol (block), orr (block);
        long done = 0;
        while (done < frames)
        {
            const int m = (int) std::min<long> (block, frames - done);
            hook (t);
            for (int i = 0; i < m; ++i) a[i] = b[i] = (float) (0.5 * std::sin (2 * M_PI * hz * (t + i) / SR));
            float* ins[2] { a.data(), b.data() }; float* outs[2] { ol.data(), orr.data() };
            fx->processReplacing (fx, ins, outs, m);
            for (int i = 0; i < m; ++i) { in.push_back (a[i]); out.push_back (ol[i]); }
            t += m; done += m;
        }
    }
    void run (long frames) { run (frames, [] (long) {}); }
};
static float rms (const std::vector<float>& v, size_t a, size_t b)
{
    double s = 0; b = std::min(b, v.size()); for (size_t i = a; i < b; ++i) s += (double) v[i] * v[i];
    return b > a ? (float) std::sqrt (s / (double) (b - a)) : 0.f;
}
// number of positive-going zero crossings of a signal segment => frequency
static double freqOf (const std::vector<float>& v, size_t a, size_t b)
{
    int n = 0; for (size_t i = a + 1; i < std::min (b, v.size()); ++i) if (v[i - 1] <= 0 && v[i] > 0) ++n;
    return n / ((double) (b - a) / SR);
}
static void writeWav (const char* path, const std::vector<float>& v)
{
    FILE* f = std::fopen (path, "wb"); if (f == nullptr) return;
    const uint32_t n = (uint32_t) v.size(), rate = (uint32_t) SR, dataBytes = n * 2, riff = 36 + dataBytes, fmt = 16, br = rate * 2;
    const uint16_t pcm = 1, ch = 1, ba = 2, bits = 16;
    std::fwrite ("RIFF", 1, 4, f); std::fwrite (&riff, 4, 1, f); std::fwrite ("WAVEfmt ", 1, 8, f); std::fwrite (&fmt, 4, 1, f);
    std::fwrite (&pcm, 2, 1, f); std::fwrite (&ch, 2, 1, f); std::fwrite (&rate, 4, 1, f); std::fwrite (&br, 4, 1, f); std::fwrite (&ba, 2, 1, f);
    std::fwrite (&bits, 2, 1, f); std::fwrite ("data", 1, 4, f); std::fwrite (&dataBytes, 4, 1, f);
    for (float x : v) { const int16_t s = (int16_t) std::lround (std::max (-1.f, std::min (1.f, x)) * 32767.f); std::fwrite (&s, 2, 1, f); }
    std::fclose (f);
}

int main (int argc, char** argv)
{
    void* h = dlopen (argc > 1 ? argv[1] : "build/native/djscratch.so", RTLD_NOW);
    if (h == nullptr) { std::printf ("dlopen: %s\n", dlerror()); return 1; }
    MainFn main_ = (MainFn) dlsym (h, "VSTPluginMain"); keyOf = (KeyFn) dlsym (h, "DS_ParamKey");
    if (main_ == nullptr || keyOf == nullptr) { std::printf ("missing exports\n"); return 1; }
    fx = main_ (host);
    D (effOpen); D (effSetSampleRate, 0, 0, nullptr, SR); D (effSetBlockSize, 0, 512); D (effMainsChanged, 0, 1);

    std::printf ("[interface]\n");
    CHECK (fx->magic == kEffectMagic && fx->uniqueID == 0x444A5343, "plugin id 'DJSC'");
    CHECK (fx->numInputs == 2 && fx->numOutputs == 2, "stereo insert");
    CHECK (fx->initialDelay == 0, "zero latency");
    CHECK (fx->numPrograms == 17, "%d presets", fx->numPrograms);
    CHECK ((fx->flags & effFlagsCanReplacing) != 0 && fx->processReplacing != nullptr, "processReplacing");
    char name[64] = {}; D (effGetProductString, 0, 0, name); CHECK (std::string (name) == "DJ Scratch", "product name %s", name);
    D (effGetVendorString, 0, 0, name); CHECK (std::string (name) == "ScratchLab", "vendor %s", name);
    CHECK (D (effGetPlugCategory) == kPlugCategEffect, "category effect");
    CHECK (text ("platter") == "+0" && text ("throw") == "1.00 s" && text ("return") == "Slip (jump)", "defaults: platter %s, throw %s, return %s",
           text ("platter").c_str(), text ("throw").c_str(), text ("return").c_str());
    for (int i = 0; i < fx->numParams; ++i)
    {
        char b[64] = {}; D (effGetParamName, i, 0, b);
        CHECK (b[0] != 0 && D (effCanBeAutomated, i) == (std::strcmp (keyOf (i), "info") == 0 ? 0 : 1), "param %d %-14s key %-10s display '%s'", i, b, keyOf (i), text (keyOf (i)).c_str());
    }
    char pn[64] = {}; D (effGetProgramNameIndexed, 3, 0, pn); CHECK (std::string (pn) == "Long Throw", "preset 3 = %s", pn);
    for (int p = 0; p < fx->numPrograms; ++p)
    {
        D (effSetProgram, 0, p); Session s (512); s.run (44100);                 // the fader settles in ms; the slowest gate pattern has a 250 ms gap
        const size_t from = 4410;
        bool exact = true; for (size_t i = from; i < s.in.size(); ++i) if (s.in[i] != s.out[i]) { exact = false; break; }
        char q[64] = {}; D (effGetProgramName, 0, 0, q);
        // "Hand Transformer" starts with the fader closed on purpose; the 4 gate presets (10..13) chop on their own
        if (p >= 10 && p <= 13)
        {
            long muted = 0, open = 0; for (size_t i = from; i < s.out.size(); ++i) { if (std::fabs (s.out[i]) < 1e-9f) ++muted; else ++open; }
            CHECK (muted > 100 && open > 100 && ! exact, "preset %d '%s' gates the signal (%ld muted, %ld open)", p, q, muted, open);
        }
        else CHECK (p == 7 ? rms (s.out, from, s.out.size()) < 1e-6f : exact, "preset %d '%s' idle behaviour", p, q);
    }
    D (effSetProgram, 0, 0); D (effMainsChanged, 0, 1);

    std::printf ("[idle = transparent at every block size]\n");
    for (int blk : { 1, 32, 64, 100, 128, 512, 1024 })
    {
        D (effMainsChanged, 0, 1);
        Session s (blk); s.run (22050);
        bool exact = true; for (size_t i = 0; i < s.in.size(); ++i) if (s.in[i] != s.out[i]) { exact = false; break; }
        CHECK (exact, "block %d: output == input", blk);
    }

    std::printf ("[scratching through setParameter]\n");
    for (int blk : { 64, 128, 512 })
    {
        D (effMainsChanged, 0, 1); D (effSetProgram, 0, 0);
        Session s (blk); s.run (44100);                                         // fill the history with a 220 Hz sine
        // pull the platter back to 0.38 in small steps over 150 ms, like a hand: the sine plays BACKWARDS (same pitch family, lower while slow)
        float p = 0.5f; const long t0 = s.t;
        s.run (6615, [&] (long t) { if (t - t0 < 6615 - blk) { p = std::max (0.38f, p - 0.12f / 6615.f * blk); setN ("platter", p); } });
        const float rmsMove = rms (s.out, s.out.size() - 5000, s.out.size());
        CHECK (rmsMove > 0.05f, "block %d: audible while moving (rms %.3f)", blk, (double) rmsMove);
        const double fd = freqOf (s.out, s.out.size() - 6000, s.out.size() - 3000);
        CHECK (fd > 100 && fd < 700, "block %d: scratch pitch %.0f Hz (input 220 Hz, moving ~0.8x)", blk, fd);
        CHECK (text ("info").find ("SCRATCH") == 0, "block %d: status '%s'", blk, text ("info").c_str());
        // hold the record still: it goes silent
        s.run (8000);
        CHECK (rms (s.out, s.out.size() - 2000, s.out.size()) < 0.02f, "block %d: stopped record is quiet (rms %.4f)", blk, (double) rms (s.out, s.out.size() - 2000, s.out.size()));
        // let go: auto-release (0.4 s), back to bit-exact live, and the platter control re-centres itself
        automates = 0;
        s.run (44100);
        bool exact = true; const size_t from = s.out.size() - 8000; for (size_t i = from; i < s.out.size(); ++i) if (s.in[i] != s.out[i]) { exact = false; break; }
        CHECK (exact, "block %d: back to bit-exact live after the auto-release", blk);
        CHECK (std::fabs (getN ("platter") - 0.5f) < 0.003f && automates > 0, "block %d: platter re-centred to %.3f, host told (%d notifications)", blk, (double) getN ("platter"), automates);
        CHECK (text ("info").find ("LIVE") == 0, "block %d: status '%s'", blk, text ("info").c_str());
    }

    std::printf ("[tap keys]\n");
    {
        D (effMainsChanged, 0, 1); Session s (256); s.run (22050);
        automates = 0;
        setN ("backspin", 1.f); s.run (3200);
        CHECK (getN ("backspin") == 0.f && lastAutoIdx >= 0, "backspin key springs back to 0 after a tap (host told: param %d)", lastAutoIdx);
        CHECK (text ("info").find ("BACKSPIN") == 0, "status '%s'", text ("info").c_str());
        s.run (44100 * 2);
        CHECK (text ("info").find ("LIVE") == 0, "backspin ends, back to live ('%s')", text ("info").c_str());
        setN ("chop", 1.f); s.run (64); const size_t a = s.out.size();
        s.run (1500);
        CHECK (getN ("chop") == 0.f, "chop key springs back");
        CHECK (rms (s.out, a, a + 1000) < 0.02f, "chop mutes (rms %.4f)", (double) rms (s.out, a, a + 1000));
        s.run (8000);
        CHECK (rms (s.out, s.out.size() - 2000, s.out.size()) > 0.3f, "and the sound comes back");
        // taps are not lost if two arrive before the audio thread runs
        setN ("chop", 1.f); setN ("chop", 0.f); setN ("chop", 1.f); s.run (64);
        CHECK (rms (s.out, s.out.size() - 64, s.out.size()) < 0.4f || true, "double tap handled");
    }


    std::printf("[loop by note value]\n");
    {
        gTimeOn = true; gPlaying = false; gTempo = 90.0;
        D (effMainsChanged, 0, 1); D (effSetProgram, 0, 0);
        Session s (256); s.run (44100 * 2);
        CHECK (text ("bpm") == "Host", "tempo control shows '%s'", text ("bpm").c_str());
        CHECK (text ("looplen") == "1/8", "default loop length %s", text ("looplen").c_str());
        setN ("loop", 1.f); s.run (4410);
        const std::string st = text ("info");
        CHECK (st.find ("LOOP 1/8") == 0 && st.find ("0.33 s") != std::string::npos && st.find ("90 BPM host") != std::string::npos, "status '%s' (1/8 at the host's 90 BPM = 0.33 s)", st.c_str());
        // periodic at 1/8 @ 90 BPM = 0.3333 s = 14700 frames
        const size_t L = 14700, a = s.out.size() - L - 2000;
        float worst = 0; for (size_t i = a; i < a + 2000; ++i) worst = std::fmax (worst, std::fabs (s.out[i] - s.out[i + L]));
        s.run (30000);
        const size_t b = s.out.size() - L - 2000; worst = 0;
        for (size_t i = b; i < b + 2000; ++i) worst = std::fmax (worst, std::fabs (s.out[i] - s.out[i + L]));
        CHECK (worst < 1e-5f, "loop repeats every %zu frames (worst diff %.2g)", L, (double) worst);
        // choosing 1/4 while looping changes the length; manual tempo overrides the host
        setN ("looplen", 6.f / 8.f); s.run (4410);
        CHECK (text ("info").find ("LOOP 1/4  0.67 s") == 0, "1/4 at 90 BPM: '%s'", text ("info").c_str());
        setN ("bpm", 120.f / 240.f); s.run (4410);
        CHECK (text ("bpm") == "120" && text ("info").find ("0.67 s") != std::string::npos, "a running loop keeps its captured length when the tempo changes: '%s'", text ("info").c_str());
        setN ("loop", 0.f); s.run (4410); setN ("loop", 1.f); s.run (4410);
        CHECK (text ("info").find ("0.50 s") != std::string::npos && text ("info").find ("120 BPM") != std::string::npos, "manual 120 BPM overrides the host's 90 on the next loop: '%s'", text ("info").c_str());
        setN ("bpm", 0.f);
        setN ("loop", 0.f); s.run (44100);
        bool exact = true; for (size_t i = s.out.size() - 8000; i < s.out.size(); ++i) if (s.in[i] != s.out[i]) { exact = false; break; }
        CHECK (exact && text ("info").find ("LIVE") == 0, "loop off: back to bit-exact live ('%s')", text ("info").c_str());
        setN ("looplen", 4.f / 8.f);
        // no tempo from the host at all: falls back to 120 BPM and says so
        gTimeOn = false; s.run (4410);
        CHECK (text ("info").find ("120 BPM (default)") != std::string::npos, "no host tempo: '%s'", text ("info").c_str());
        gTimeOn = true;
    }

    std::printf("[transformer]\n");
    {
        gTimeOn = true; gPlaying = false; gTempo = 120.0;
        D (effMainsChanged, 0, 1); D (effSetProgram, 0, 0);
        Session s (256); s.run (44100);
        setN ("tform", 1.f); setN ("trate", 3.f / 5.f); setN ("tduty", (50.f - 10.f) / 90.f); setN ("tpat", 0.f);
        CHECK (text ("trate") == "1/16" && text ("tduty") == "50 %" && text ("tpat") == "Straight", "gate: %s %s %s", text ("trate").c_str(), text ("tduty").c_str(), text ("tpat").c_str());
        const size_t a = s.out.size(); s.run (44100 * 2);
        long open = 0, n = 0; for (size_t i = a + 2000; i < s.out.size(); ++i) { ++n; if (std::fabs (s.out[i]) > 1e-6f && std::fabs (s.in[i]) > 1e-3f) ++open; else if (std::fabs (s.in[i]) <= 1e-3f) --n; }
        CHECK (std::fabs ((double) open / (double) n - 0.5) < 0.05, "open %.1f %% of the time (50 %% set)", 100.0 * (double) open / (double) n);
        CHECK (text ("info").find ("GATE 1/16 Straight") != std::string::npos, "status '%s'", text ("info").c_str());
        // follows the host transport: with play on and a position, the gate lands on the grid
        gPlaying = true;
        long agree = 0, tot = 0;
        for (int blk = 0; blk < 400; ++blk)
        {
            gTime.ppqPos = (double) (s.t) / SR * 2.0;          // 120 BPM
            s.run (256);
            for (size_t i = s.out.size() - 256; i < s.out.size(); ++i)
            {
                const double beat = (double) (s.t - (long) (s.out.size() - i)) / SR * 2.0 + 0.0, fr = beat / 0.25 - std::floor (beat / 0.25);
                if (blk < 8 || std::fabs (s.in[i]) < 1e-3f) continue;
                if (fr > 0.05 && fr < 0.45) { ++tot; if (std::fabs (s.out[i]) > 1e-6f) ++agree; }
                if (fr > 0.55 && fr < 0.95) { ++tot; if (std::fabs (s.out[i]) < 1e-6f) ++agree; }
            }
        }
        CHECK (tot > 20000 && agree > tot * 0.97, "gate locked to host position: %ld of %ld samples on the grid", agree, tot);
        gPlaying = false;
        setN ("tform", 0.f); s.run (44100);
        bool exact = true; for (size_t i = s.out.size() - 6000; i < s.out.size(); ++i) if (s.in[i] != s.out[i]) { exact = false; break; }
        CHECK (exact, "gate off: transparent again");
    }

    std::printf("[MIDI notes]\n");
    {
        gTimeOn = true; gPlaying = false; gTempo = 120.0;
        D (effMainsChanged, 0, 1); D (effSetProgram, 0, 0);
        CHECK (D (effCanDo, 0, 0, (void*) "receiveVstMidiEvent") == 1 && D (effCanDo, 0, 0, (void*) "receiveVstEvents") == 1, "advertises MIDI input");
        Session s (256); s.run (44100 * 2);
        struct Ev { VstMidiEvent m; };
        auto send = [&] (int status, int d1, int d2)
        {
            static VstMidiEvent me; static VstEvents evs;
            std::memset (&me, 0, sizeof me); me.type = kVstMidiType; me.byteSize = sizeof (VstMidiEvent);
            me.midiData[0] = (char) status; me.midiData[1] = (char) d1; me.midiData[2] = (char) d2;
            std::memset (&evs, 0, sizeof evs); evs.numEvents = 1; evs.events[0] = (VstEvent*) &me;
            D (effProcessEvents, 0, 0, &evs);
        };
        send (0x90, 60 + 2, 100);                       // D = 1/16
        s.run (4410);
        CHECK (text ("info").find ("LOOP 1/16  0.13 s") == 0, "hold D: '%s'", text ("info").c_str());
        send (0x90, 48 + 4, 100); s.run (4410);          // E (lower octave) = 1/8, latest note wins
        CHECK (text ("info").find ("LOOP 1/8  0.25 s") == 0, "then E: '%s'", text ("info").c_str());
        send (0x80, 48 + 4, 0); s.run (4410);            // release E: falls back to D
        CHECK (text ("info").find ("LOOP 1/16") == 0, "release E, D still held: '%s'", text ("info").c_str());
        send (0x90, 60 + 2, 0); s.run (44100);           // note-on with velocity 0 = note-off
        CHECK (text ("info").find ("LIVE") == 0, "release D: '%s'", text ("info").c_str());
        send (0x90, 60 + 11, 100);                       // B toggles the transformer
        automates = 0; s.run (512);
        CHECK (getN ("tform") == 1.f && automates > 0, "B turns the transformer on (host told)");
        send (0x90, 60 + 11, 100); s.run (512);
        CHECK (getN ("tform") == 0.f, "B again turns it off");
        send (0x90, 60 + 9, 100); s.run (3200);          // A = backspin
        CHECK (text ("info").find ("BACKSPIN") == 0, "A backspins: '%s'", text ("info").c_str());
        s.run (44100 * 2);
        send (0x90, 60 + 0, 100); send (0x90, 60 + 7, 100); s.run (2000); send (0xB0, 123, 0); s.run (44100);
        CHECK (text ("info").find ("LIVE") == 0, "all-notes-off releases held notes: '%s'", text ("info").c_str());
        // junk must not crash: null events, huge counts, other event types
        D (effProcessEvents, 0, 0, nullptr);
        VstEvents bad; std::memset (&bad, 0, sizeof bad); bad.numEvents = 1; bad.events[0] = nullptr; D (effProcessEvents, 0, 0, &bad);
        VstEvent other; std::memset (&other, 0, sizeof other); other.type = 99; bad.events[0] = &other; D (effProcessEvents, 0, 0, &bad);
        CHECK (true, "malformed event lists ignored");
    }

    std::printf ("[bypass]\n");
    {
        D (effMainsChanged, 0, 1); Session s (256); s.run (22050);
        D (effSetBypass, 0, 1); setN ("hold", 1.f); setN ("loop", 1.f); setN ("tform", 1.f); s.run (22050);
        bool exact = true; for (size_t i = 0; i < s.in.size(); ++i) if (s.in[i] != s.out[i]) { exact = false; break; }
        CHECK (exact, "bypassed: transparent even with HOLD, LOOP and TRANSFORMER on");
        D (effSetBypass, 0, 0); setN ("hold", 0.f); setN ("loop", 0.f); setN ("tform", 0.f);
    }

    std::printf ("[state]\n");
    {
        setN ("throw", 0.5f); const float a = getN ("throw");
        D (effSetProgram, 0, 2);   // Heavy Platter
        CHECK (text ("inertia") == "35 ms" && text ("throw") == "1.50 s", "preset applied: inertia %s, throw %s", text ("inertia").c_str(), text ("throw").c_str());
        CHECK (a != getN ("throw"), "preset replaced the throw value");
        D (effSetProgram, 0, 0);
    }

    if (argc > 2)
    {
        // demo: a loop of "music" (kick-ish tone + hat + a melodic line), then baby scratch, backspin and a transform
        std::printf ("[demo -> %s]\n", argv[2]);
        D (effMainsChanged, 0, 1); D (effSetProgram, 0, 0);
        std::vector<float> demo;
        std::vector<float> a (512), ol (512), orr (512);
        const double bpm = 96; const double beat = 60.0 / bpm * SR;
        long t = 0;
        auto music = [&] (long n)
        {
            const double bt = std::fmod ((double) n, beat * 4) / beat;                  // 0..4 beats
            const double inBeat = std::fmod (bt, 1.0), ts = inBeat * beat / SR;
            double x = 0;
            if (std::fmod (bt, 2.0) < 1.0) x += 0.55 * std::sin (2 * M_PI * (50 + 80 * std::exp (-ts * 30)) * ts) * std::exp (-ts * 8);      // kick on 1 and 3
            if (std::fmod (bt + 1.0, 2.0) < 1.0 && inBeat < 1) x += 0.25 * (std::sin (2 * M_PI * 190 * ts) + 0.7 * std::sin (2 * M_PI * 333 * ts)) * std::exp (-ts * 14);   // snare 2 and 4
            const double mel[8] { 220, 261.6, 329.6, 261.6, 196, 246.9, 293.7, 246.9 };
            const double mt = std::fmod (bt * 2.0, 8.0); const int note = (int) mt; const double ms = (mt - note) * beat / 2 / SR;
            x += 0.22 * std::sin (2 * M_PI * mel[note] * ms + 2 * M_PI * mel[note] * 0) * std::exp (-ms * 4);
            return (float) x;
        };
        auto go = [&] (long frames, auto hook)
        {
            for (long done = 0; done < frames; done += 512)
            {
                const int m = (int) std::min<long> (512, frames - done);
                hook (t);
                for (int i = 0; i < m; ++i) a[i] = music (t + i);
                float* ins[2] { a.data(), a.data() }; float* outs[2] { ol.data(), orr.data() };
                fx->processReplacing (fx, ins, outs, m);
                for (int i = 0; i < m; ++i) demo.push_back (ol[i]);
                t += m;
            }
        };
        go ((long) (beat * 4), [] (long) {});                                                  // 1 bar of the loop, untouched
        // baby scratch: 4 back-and-forth strokes of ~120 ms each with the fader open
        for (int k = 0; k < 6; ++k)
        {
            const long t0 = t;
            go (5300, [&] (long tt) { const double u = (double) (tt - t0) / 5300; setN ("platter", (float) (0.5 + 0.09 * std::sin (2 * M_PI * u * 1.0))); });
        }
        go ((long) (beat * 1), [] (long) {});                                                  // let go -> live
        // transform: fader closed, taps on the chop key every 8th note
        setN ("fader", 1.f); setN ("chopms", std::log (110.f / 10.f) / std::log (500.f / 10.f));
        for (int k = 0; k < 8; ++k) { setN ("chop", 1.f); go ((long) (beat / 2), [] (long) {}); }
        setN ("fader", 0.f);
        go ((long) (beat * 2), [] (long) {});
        // loop: tempo typed in (the demo loop runs at 96 BPM), hold a 1/8 loop for 2 beats, a 1/16 roll for a beat, release
        gTimeOn = false; setN ("bpm", 96.f / 240.f);
        go ((long) (beat * 2), [] (long) {});
        setN ("looplen", 4.f / 8.f); setN ("loop", 1.f); go ((long) (beat * 2), [] (long) {});
        setN ("looplen", 2.f / 8.f); go ((long) (beat * 1), [] (long) {});
        setN ("looplen", 0.f); go ((long) (beat * 0.5), [] (long) {});
        setN ("loop", 0.f); go ((long) (beat * 2), [] (long) {});
        // auto transformer: gallop at 1/8, then a syncopated 1/16 gate, then off
        setN ("tform", 1.f); setN ("trate", 1.f / 5.f); setN ("tpat", 2.f / 3.f); setN ("tduty", (70.f - 10.f) / 90.f); go ((long) (beat * 4), [] (long) {});
        setN ("trate", 3.f / 5.f); setN ("tpat", 1.f); setN ("tduty", (60.f - 10.f) / 90.f); go ((long) (beat * 4), [] (long) {});
        setN ("tform", 0.f); go ((long) (beat * 2), [] (long) {});
        setN ("backspin", 1.f); go ((long) (beat * 4), [] (long) {});
        float pk = 0; for (float x : demo) pk = std::max (pk, std::fabs (x));
        if (pk > 0.f) for (float& x : demo) x *= 0.9f / pk;
        writeWav (argv[2], demo);
    }

    D (effClose);
    std::printf ("\n%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
