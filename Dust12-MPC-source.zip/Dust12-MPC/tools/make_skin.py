#!/usr/bin/env python3
"""Generate the Dust 12 MPC screen skin: original dark "worn panel" theme, one page, 16 Q-Links.

Output: mpc/skin/Dust 12 - VST - Dust 12/{version.xml, Plugin Skins/{TUI.json, Q-Links*.json, *.png}}
Format follows the MPC OS plugin-skin layout used by the JV-880 / GlueBus packages (Akai's TUI.json schema).
Knobs bind to "Parameter N" = VST parameter index (see src/dust12.cpp). Requires Pillow.
Usage: python3 tools/make_skin.py [preview.png]
"""
import json, math, os, random, shutil, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIN_DIR = os.path.join(ROOT, "mpc", "skin", "Dust 12 - VST - Dust 12")
OUT = os.path.join(SKIN_DIR, "Plugin Skins")
W, H = 1280, 628
FRAMES, NUMFRAMES, SS = 128, 127, 4     # filmstrip frames; value written to TUI.json (JV-880 convention); supersampling

FONT_DIRS = ["/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu", "/Library/Fonts", "C:/Windows/Fonts"]
def font(size, name="DejaVuSans-Bold.ttf"):
    for d in FONT_DIRS:
        p = os.path.join(d, name)
        if os.path.exists(p): return ImageFont.truetype(p, size)
    return ImageFont.load_default()

# ---------- palette (original dark worn-panel theme) ----------
PANEL   = (58, 60, 56)
HEADER  = (22, 22, 24)
INK     = (40, 38, 34)          # used on the light segment/button caps
INK_DIM = (112, 106, 96)
IVORY   = (238, 232, 216)
LIGHT   = (226, 220, 204)       # text / lines on the dark panel
LDIM    = (150, 146, 132)
ACCENT  = (214, 120, 40)
RINGS = {"orange": (212, 112, 38), "teal": (36, 132, 132), "grey": (128, 128, 128), "amber": (206, 158, 40),
         "violet": (100, 92, 168), "red": (184, 62, 50), "ink": (150, 148, 140)}
NAME_COL, VALUE_COL, FOCUS_COL = "ffe2dccc", "fff0a030", "ffd47828"
PANEL_HEX = "ff3a3c38"

# ---------- parameter indices (must match src/dust12.cpp) ----------
P = dict(inp=0, aaf=1, rate=2, bits=3, quant=4, dither=5, recon=6, noise=7, filt=8, warm=9, clip=10, mono=11, mix=12,
         out=13, wobble=14, level=15, bypass=16)

L, M, S = "L", "M", "S"
KSPEC = {L: dict(box=(150, 150), knob=96, name_h=20, val_h=26),
         M: dict(box=(130, 128), knob=76, name_h=20, val_h=24),
         S: dict(box=(120, 118), knob=64, name_h=18, val_h=22)}

# ---------- page layout: knobs (param, label, size, ring, x, y); toggles; segments; sections ----------
MAIN = dict(
    name="DD|Dust 12", tab="Dust 12", subtitle="CONVERTER",
    sections=[(24, 78, 420, 610, "INPUT"), (440, 78, 860, 610, "SAMPLER"), (880, 78, 1256, 610, "OUTPUT")],
    knobs=[("inp", "INPUT", L, "orange", 44, 100), ("aaf", "AA FILTER", M, "grey", 214, 110),
           ("rate", "SAMPLE RATE", L, "orange", 460, 100), ("bits", "BIT DEPTH", M, "orange", 630, 110),
           ("wobble", "WOBBLE", S, "amber", 460, 290), ("dither", "DITHER", S, "amber", 590, 290), ("noise", "NOISE", S, "amber", 720, 290),
           ("filt", "OUT FILTER", M, "teal", 900, 110), ("warm", "WARMTH", M, "red", 1070, 110),
           ("mix", "MIX", S, "ink", 900, 290), ("out", "OUTPUT", S, "ink", 1030, 290)],
    toggles=[("mono", "MONO", 900, 470), ("bypass", "BYPASS", 1070, 470)],
    segments=[("clip", "CONVERTER CLIP", ["HARD", "SOFT"], 44, 466, 100),
              ("quant", "QUANTIZE", ["TRUNC", "ROUND"], 456, 466, 88),
              ("recon", "RECONSTRUCT", ["STAIR", "SMOOTH"], 652, 466, 88)],
    meter=(44, 290),
    notes=[(462, 420, "26.04 kHz detent = SP-1200 clock"), (46, 420, "meter: converter level, red = clipping")])
PAGES = [MAIN]

# ---------- drawing helpers ----------
def rgba(c, a=255): return (c[0], c[1], c[2], a)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def text_c(d, cx, cy, s, f, fill):
    b = d.textbbox((0, 0), s, font=f); d.text((cx - (b[2] - b[0]) / 2 - b[0], cy - (b[3] - b[1]) / 2 - b[1]), s, font=f, fill=fill)
def spaced(s, n=1): return (" " * n).join(s)
ANG0, ANG1 = -135.0, 135.0
def ang_xy(cx, cy, r, deg):
    a = math.radians(deg - 90); return cx + r * math.cos(a), cy + r * math.sin(a)

def knob_frame(size, ring, t):
    s = size * SS; im = Image.new("RGBA", (s, s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    c = s / 2; R = s * 0.47
    sh = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ImageDraw.Draw(sh).ellipse([c - R + s * .02, c - R + s * .05, c + R + s * .02, c + R + s * .05], fill=(0, 0, 0, 110))
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(s * 0.03)))
    d.ellipse([c - R, c - R, c + R, c + R], fill=rgba(ring))                                 # coloured index ring
    r1 = R * 0.84; d.ellipse([c - r1, c - r1, c + r1, c + r1], fill=rgba((24, 24, 26)))      # black body
    r2 = R * 0.70                                                                            # domed cap
    cap = Image.new("RGBA", (s, s), (0, 0, 0, 0)); cd = ImageDraw.Draw(cap)
    for yy in range(int(c - r2), int(c + r2) + 1):
        k = (yy - (c - r2)) / (2 * r2); col = mix((78, 78, 82), (18, 18, 20), k)
        dx = math.sqrt(max(0.0, r2 * r2 - (yy - c) ** 2)); cd.line([c - dx, yy, c + dx, yy], fill=rgba(col))
    im.alpha_composite(cap)
    deg = ANG0 + (ANG1 - ANG0) * t
    x0, y0 = ang_xy(c, c, R * 0.12, deg); x1, y1 = ang_xy(c, c, R * 0.80, deg)
    d.line([x0, y0, x1, y1], fill=rgba(IVORY), width=int(SS * max(2.5, size / 24)))
    xd, yd = ang_xy(c, c, R * 0.92, deg); rd = R * 0.06                                       # dot on the ring
    d.ellipse([xd - rd, yd - rd, xd + rd, yd + rd], fill=rgba(IVORY))
    return im.resize((size, size), Image.LANCZOS)

def knob_strip(size, ring):
    strip = Image.new("RGBA", (size, size * FRAMES), (0, 0, 0, 0))
    for f in range(FRAMES): strip.paste(knob_frame(size, RINGS[ring], f / (FRAMES - 1)), (0, f * size))
    return strip

# LED ladder converter-level meter (-48..+6 dBFS = parameter 15, filmstrip frame f = f/127 of the range)
MW, MH, NLED = 360, 118, 24
LV_LO, LV_HI = -48.0, 6.0
MARKS = [-48, -36, -24, -18, -12, -6, 0]
def lv_pos(db): return (db - LV_LO) / (LV_HI - LV_LO)
def meter_frame(t):
    s = SS; im = Image.new("RGBA", (MW * s, MH * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, MW * s - 1, MH * s - 1], radius=8 * s, fill=rgba((20, 20, 22)))
    x0, x1, y0, y1 = 20 * s, (MW - 20) * s, 46 * s, 84 * s
    step = (x1 - x0) / NLED; lit = t * NLED
    red_from = int(lv_pos(0.0) * NLED); amb_from = int(lv_pos(-12.0) * NLED)
    for i in range(NLED):
        kind = 2 if i >= red_from else (1 if i >= amb_from else 0); on = i < lit
        col = [((84, 204, 96), (26, 52, 30)), ((240, 176, 44), (60, 48, 26)), ((236, 70, 50), (64, 30, 26))][kind][0 if on else 1]
        d.rounded_rectangle([x0 + i * step + s, y0, x0 + (i + 1) * step - 2 * s, y1], radius=2 * s, fill=rgba(col))
    f = font(12 * s)
    for db in MARKS:
        x = x0 + (x1 - x0) * lv_pos(db); text_c(d, x, 28 * s, str(db), f, rgba((190, 184, 168)))
        d.line([x, 38 * s, x, 43 * s], fill=rgba((190, 184, 168)), width=s)
    text_c(d, MW * s / 2, 102 * s, "CONVERTER LEVEL  dBFS", font(11 * s), rgba((150, 144, 130)))
    return im.resize((MW, MH), Image.LANCZOS)
def meter_strip():
    strip = Image.new("RGBA", (MW, MH * FRAMES), (0, 0, 0, 0))
    for f in range(FRAMES): strip.paste(meter_frame(f / (FRAMES - 1)), (0, f * MH))
    return strip

def pushbutton(on, w=64, h=34):
    s = SS; im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, w * s - 1, h * s - 1], radius=5 * s, fill=rgba((36, 36, 38)))
    cap = (206, 200, 186) if on else (230, 224, 210)
    off = 2 * s if on else 0
    d.rounded_rectangle([3 * s, 3 * s + off, (w - 3) * s, (h - 5) * s + off], radius=4 * s, fill=rgba(cap))
    cx, cy, r = w * s / 2, h * s / 2 + off / 2, 5 * s
    if on:
        g = Image.new("RGBA", im.size, (0, 0, 0, 0))
        ImageDraw.Draw(g).ellipse([cx - 3 * r, cy - 3 * r, cx + 3 * r, cy + 3 * r], fill=(255, 150, 60, 150))
        im.alpha_composite(g.filter(ImageFilter.GaussianBlur(3 * s))); d = ImageDraw.Draw(im)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=rgba((255, 128, 40) if on else (120, 70, 50)))
    return im.resize((w, h), Image.LANCZOS)

def seg(label, on, w, h=34):
    s = SS; im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    fill, txt = ((34, 34, 36), IVORY) if on else ((232, 226, 212), INK_DIM)
    d.rounded_rectangle([0, 0, w * s - 1, h * s - 1], radius=5 * s, fill=rgba(fill), outline=rgba((60, 58, 54)), width=s)
    if on: d.ellipse([8 * s, h * s / 2 - 3 * s, 14 * s, h * s / 2 + 3 * s], fill=rgba((255, 128, 40)))
    text_c(d, w * s / 2 + (4 * s if on else 0), h * s / 2, label, font(13 * s), rgba(txt))
    return im.resize((w, h), Image.LANCZOS)

def section(d, x0, y0, x1, y1, title):
    d.rounded_rectangle([x0, y0, x1, y1], radius=8, outline=(128, 126, 114), width=2)
    f = font(13); tw = d.textlength(spaced(title), font=f)
    d.rectangle([x0 + 14, y0 - 9, x0 + 26 + tw, y0 + 9], fill=PANEL)
    d.text((x0 + 20, y0 - 8), spaced(title), font=f, fill=LIGHT)

def knob_scale(d, cx, cy, r, n=11):
    for i in range(n):
        a = ANG0 + (ANG1 - ANG0) * i / (n - 1)
        x0, y0 = ang_xy(cx, cy, r, a); x1, y1 = ang_xy(cx, cy, r + (8 if i in (0, n - 1) else 5), a)
        d.line([x0, y0, x1, y1], fill=LIGHT, width=2)

def background(page):
    random.seed(11)
    im = Image.new("RGB", (W, H), PANEL); px = im.load()
    for y in range(H):
        for x in range(W):
            n = random.randint(-3, 3); px[x, y] = (PANEL[0] + n, PANEL[1] + n, PANEL[2] + n)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, W, 58], fill=HEADER); d.rectangle([0, 58, W, 61], fill=ACCENT)
    d.text((30, 10), spaced("DUST 12", 1), font=font(32), fill=IVORY)
    d.text((300, 22), spaced("12-BIT  SAMPLER  CONVERTER"), font=font(14), fill=(150, 146, 136))
    tw = d.textlength(spaced(page["subtitle"]), font=font(16)); d.text((W - 30 - tw, 20), spaced(page["subtitle"]), font=font(16), fill=IVORY)
    for sx, sy in [(8, 66), (W - 20, 66), (8, H - 16), (W - 20, H - 16)]:
        d.ellipse([sx, sy, sx + 11, sy + 11], fill=(160, 156, 146), outline=(90, 88, 82)); d.line([sx + 2, sy + 5, sx + 9, sy + 5], fill=(80, 78, 72), width=2)
    for sec in page["sections"]: section(d, *sec)
    for key, lab, size, ring, x, y in page["knobs"]:
        k = KSPEC[size]; cx = x + k["box"][0] / 2; cy = y + 4 + k["knob"] / 2
        knob_scale(d, cx, cy, k["knob"] / 2 + 4)
    for x, y, t in page["notes"]: d.text((x, y), t, font=font(12), fill=LDIM)
    return im

# ---------- TUI.json ----------
NOREMAP = {"version": 1, "map": []}
def bounds(b, focus="No", show="Show", visible="Always"):
    return {"version": 2, "acceptsHWFocus": focus, "showWhenDataModelInvalid": show, "whenVisible": visible,
            "boundsType": "Absolute", "bounds": " ".join(str(int(v)) for v in b), "additionalInvalidatingHandles": []}
def comp(name, typ, data, b, remap=None):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": typ, "data": data},
            "handle remapping": remap or NOREMAP, "bounds": b}
def bind(p): return {"version": 1, "map": [{"key": "Data", "value": f"Parameter {P[p]}"}]}
def action(on, handler, extra=""):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": "" if handler == "Show Overlay" else "Data",
            "additionalData": extra, "handle remapping": NOREMAP}
def bgdata(col="0"): return {"version": 1, "focussed": {"version": 1, "colour": col, "image": ""}, "unfocussed": {"version": 1, "colour": col, "image": ""}}
def definition(actions, parts, bgcol="0", ignore=False):
    return {"version": 4, "actions": actions, "backgroundData": bgdata(bgcol), "ignoreMousePresses": ignore,
            "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True, "componentsData": parts}
def label(kind, h, colour, b, case="Original", name=None):
    return comp(name or kind, "Label", {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": "Titillium Web", "style": "SemiBold", "height": float(h)},
                "colour": colour, "justification": "horizontallyCentred verticallyCentred", "case": case}, "type": kind, "handleName": "Data"}, bounds(b))
def focus(b):
    return comp("Focus", "Focus", {"version": 1, "backgroundColour": "00000000", "outlineColour": FOCUS_COL, "backgroundInset": 2.0, "outlineThickness": 2.0},
                bounds(b, visible="WhenFocussed"))

def build():
    if os.path.isdir(SKIN_DIR): shutil.rmtree(SKIN_DIR)
    os.makedirs(OUT)
    defs, made, tabs = [], set(), []

    def ensure_knob(size, ring):
        typ = f"ddKnob{size}_{ring}"
        if typ in made: return typ
        made.add(typ); fn = f"dd_knob_{size}_{ring}.png"
        k = KSPEC[size]; bw, bh = k["box"]; ks = k["knob"]
        knob_strip(ks, ring).save(os.path.join(OUT, fn), optimize=True)
        defs.append({"key": typ, "value": definition(
            [action("Mouse Down", "Q-Link"), action("Double Click", "Show Overlay", "knob overlay"), action("Enter Pressed", "Show Overlay", "knob overlay")],
            [focus((0, 0, bw, bh)),
             comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": fn, "numFrames": NUMFRAMES, "invert": False,
                   "dragOrientation": "Vertical", "handleName": "Data"}, bounds(((bw - ks) / 2, 4, ks, ks))),
             label("Name", 16, NAME_COL, (0, ks + 8, bw, k["name_h"])),
             label("Value", 20, VALUE_COL, (0, ks + 8 + k["name_h"], bw, k["val_h"]), case="Upper Case")])})
        return typ

    # shared parts: toggle, meter
    pushbutton(True).save(os.path.join(OUT, "dd_btn_on.png")); pushbutton(False).save(os.path.join(OUT, "dd_btn_off.png"))
    defs.append({"key": "ddToggle", "value": definition([action("Mouse Down", "Q-Link"), action("Enter Pressed", "Toggle Switch")], [
        focus((0, 0, 120, 70)),
        comp("Button", "Button", {"version": 2, "onImage": "dd_btn_on.png", "offImage": "dd_btn_off.png", "buttonId": 1,
             "numButtonsInGroup": 1, "handleName": "Data", "gestureBehaviour": "Instant"}, bounds((28, 4, 64, 34))),
        label("Name", 15, NAME_COL, (0, 42, 120, 22))])})
    meter_strip().save(os.path.join(OUT, "dd_meter.png"), optimize=True)
    defs.append({"key": "ddMeter", "value": definition([], [
        comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": "dd_meter.png", "numFrames": NUMFRAMES, "invert": False,
             "dragOrientation": "Vertical", "handleName": "Data"}, bounds((0, 0, MW, MH)))], ignore=True)})

    for ti, page in enumerate(PAGES):
        bgfile = f"dd_bg_{ti}.png"
        background(page).save(os.path.join(OUT, bgfile), optimize=True)
        comps = [comp("Background", "Image", {"version": 2, "imageType": "Regular", "colour": "0", "image": bgfile}, bounds((0, 0, W, H)))]
        for key, lab, size, ring, x, y in page["knobs"]:
            bw, bh = KSPEC[size]["box"]
            comps.append(comp(lab, ensure_knob(size, ring), {"version": 1, "handleName": "Data"}, bounds((x, y, bw, bh), focus="Yes", show="Hide"), bind(key)))
        for key, lab, x, y in page["toggles"]:
            comps.append(comp(lab, "ddToggle", {"version": 1, "handleName": "Data"}, bounds((x, y, 120, 70), focus="Yes", show="Hide"), bind(key)))
        for key, lab, opts, x, y, sw in page["segments"]:
            c = label("Name", 15, NAME_COL, (x, y + 4, len(opts) * (sw + 4), 20), name=lab); c["handle remapping"] = bind(key); comps.append(c)
            for i, o in enumerate(opts):
                typ, on, off = f"ddSeg_{key}_{i}", f"dd_seg_{key}_{i}_on.png", f"dd_seg_{key}_{i}_off.png"
                seg(o, True, sw).save(os.path.join(OUT, on)); seg(o, False, sw).save(os.path.join(OUT, off))
                defs.append({"key": typ, "value": definition([action("Mouse Down", "Q-Link")], [
                    comp("Button", "Button", {"version": 2, "onImage": on, "offImage": off, "buttonId": i, "numButtonsInGroup": len(opts),
                         "handleName": "Data", "gestureBehaviour": "Instant"}, bounds((0, 0, sw, 34)))])})
                comps.append(comp(f"{lab} {o}", typ, {"version": 1, "handleName": "Data"},
                                  bounds((x + i * (sw + 4), y + 30, sw, 34), focus="Yes" if i == 0 else "No", show="Hide"), bind(key)))
        if page["meter"]:
            mx, my = page["meter"]
            comps.append(comp("Level", "ddMeter", {"version": 1, "handleName": "Data"}, bounds((mx, my, MW, MH)), bind("level")))
        defs.append({"key": page["name"], "value": definition([], comps, PANEL_HEX)})
        tabs.append({"version": 3, "tabName": page["tab"], "fnKeyIndex": ti, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
                     "componentName": page["name"], "initialSize": f"0 0 {W} {H}", "scale": 1.0})

    tui = {"pageData": {"version": 1,
        "componentDefinitions": {"version": 2, "importFiles": ["/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json",
                                                                "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
                                 "localComponentDefinitions": defs},
        "info": {"version": 1, "type": "CompleteDescription"}, "tabs": tabs}}
    json.dump(tui, open(os.path.join(OUT, "TUI.json"), "w"), indent=4)

    ql = ["inp", "aaf", "rate", "bits", "wobble", "dither", "noise", "filt", "warm", "mix", "out", "clip", "quant", "recon", "mono", "bypass"]
    qmap = lambda keys: {f"Q-Link {i + 1}": P[k] for i, k in enumerate(keys)}
    q = {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
         "Screen Mode Q-Links": {"version": 4, "map": [{"Tab": 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": qmap(ql)}]},
         "Program Mode Q-Links": qmap(ql)}
    for fn in ("Q-Links.json", "Q-Links - 8by1.json"): json.dump(q, open(os.path.join(OUT, fn), "w"), indent=4)
    open(os.path.join(SKIN_DIR, "version.xml"), "w").write(
        "<?xml version='1.0' encoding='utf-8'?>\n<plugincontent version=\"1.0\">\n\t<identifier>dust12.vst.dust12</identifier>\n"
        "\t<version>1.0.0.0</version>\n</plugincontent>\n")
    print("skin written to", SKIN_DIR)

# ---------- preview (both pages stacked, typical values) ----------
PREVIEW_VALUES = dict(inp=.4, aaf=1, rate=.75, bits=.67, wobble=.2, dither=.3, noise=.35, filt=.8, warm=.2, mix=1, out=.5)
PREVIEW_ON = {"mono"}
def preview_page(ti, page):
    im = Image.open(os.path.join(OUT, f"dd_bg_{ti}.png")).convert("RGBA"); d = ImageDraw.Draw(im)
    fn_, fv = font(14), font(16)
    for key, lab, size, ring, x, y in page["knobs"]:
        k = KSPEC[size]; bw = k["box"][0]; ks = k["knob"]
        strip = Image.open(os.path.join(OUT, f"dd_knob_{size}_{ring}.png")); fr = round(PREVIEW_VALUES.get(key, .5) * (FRAMES - 1))
        im.alpha_composite(strip.crop((0, fr * ks, ks, (fr + 1) * ks)), (int(x + (bw - ks) / 2), y + 4))
        text_c(d, x + bw / 2, y + ks + 8 + k["name_h"] / 2, lab, fn_, LIGHT)
        text_c(d, x + bw / 2, y + ks + 8 + k["name_h"] + k["val_h"] / 2, "value", fv, (240, 160, 48))
    for key, lab, x, y in page["toggles"]:
        im.alpha_composite(Image.open(os.path.join(OUT, "dd_btn_on.png" if key in PREVIEW_ON else "dd_btn_off.png")), (x + 28, y + 4))
        text_c(d, x + 60, y + 53, lab, fn_, LIGHT)
    for key, lab, opts, x, y, sw in page["segments"]:
        text_c(d, x + len(opts) * (sw + 4) / 2, y + 14, lab, fn_, LIGHT)
        for i in range(len(opts)):
            im.alpha_composite(Image.open(os.path.join(OUT, f"dd_seg_{key}_{i}_{'on' if i == 0 else 'off'}.png")), (x + i * (sw + 4), y + 30))
    if page["meter"]:
        m = Image.open(os.path.join(OUT, "dd_meter.png")); fr = 100
        im.alpha_composite(m.crop((0, fr * MH, MW, (fr + 1) * MH)), page["meter"])
    return im
def preview(path):
    imgs = [preview_page(i, p) for i, p in enumerate(PAGES)]
    out = Image.new("RGB", (W, H * len(imgs) + 12 * (len(imgs) - 1)), (0, 0, 0))
    for i, im in enumerate(imgs): out.paste(im.convert("RGB"), (0, i * (H + 12)))
    out.save(path)

if __name__ == "__main__":
    build()
    if len(sys.argv) > 1: preview(sys.argv[1])
