// Offline VST2 host test for Dust 12: loads the .so, exercises dispatcher, parameters, presets and audio.
#include "vst2.h"
#include <dlfcn.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static int fails = 0;
#define CHECK(cond, ...) do { if (!(cond)) { ++fails; std::printf("FAIL: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

enum { P_IN, P_AAF, P_RATE, P_BITS, P_QUANT, P_DITHER, P_RECON, P_NOISE, P_FILT, P_WARM, P_CLIP, P_MONO, P_MIX, P_OUT,
       P_WOBBLE, P_LEVEL, P_BYPASS, P_COUNT };

static int automateCalls = 0, displayCalls = 0, meterCalls = 0;
static intptr_t host(AEffect*, int32_t op, int32_t idx, intptr_t, void*, float) {
    if (op == 0) { ++automateCalls; if (idx == P_LEVEL) ++meterCalls; }
    if (op == 42) ++displayCalls;
    return 2400;
}
static AEffect* fx;
static intptr_t D(int op, int idx = 0, intptr_t val = 0, void* p = nullptr, float opt = 0) { return fx->dispatcher(fx, op, idx, val, p, opt); }
static void setNorm(int i, float n) { fx->setParameter(fx, i, n); }
static float getNorm(int i) { return fx->getParameter(fx, i); }
static void setPlainLin(int i, float lo, float hi, float v) { setNorm(i, (v - lo) / (hi - lo)); }
static void setLog(int i, float lo, float hi, float v) { setNorm(i, std::log(v / lo) / std::log(hi / lo)); }
static void setChoice(int i, int v) { setNorm(i, (float) v); }   // 2-option choices: norm 0 or 1
static std::vector<float> zeros;

static const float SR = 44100.f;
static const int N = 44100;
static void makeSine(std::vector<float>& l, std::vector<float>& r, float peak, float hz, int n = N) {
    l.resize(n); r.resize(n);
    for (int i = 0; i < n; ++i) l[i] = r[i] = (float) (peak * std::sin(6.283185307179586 * hz * i / SR));   // double phase: no test-signal phase noise
}
static void proc(std::vector<float>& il, std::vector<float>& ir, std::vector<float>& ol, std::vector<float>& orr, int block = 512) {
    ol.assign(il.size(), 0); orr.assign(il.size(), 0);
    for (size_t pos = 0; pos < il.size(); pos += block) {
        int m = (int) std::fmin((double) block, (double)(il.size() - pos));
        float* in[2] = { &il[pos], &ir[pos] }; float* out[2] = { &ol[pos], &orr[pos] };
        fx->processReplacing(fx, in, out, m);
    }
}
static float db(float x) { return 20.f * std::log10(x + 1e-12f); }
static float peakOf(const std::vector<float>& v, int from) { float m = 0; for (size_t i = from; i < v.size(); ++i) m = std::fmax(m, std::fabs(v[i])); return m; }
static float rmsOf(const std::vector<float>& v, int from) { double s = 0; for (size_t i = from; i < v.size(); ++i) s += (double) v[i] * v[i]; return (float) std::sqrt(s / (v.size() - from)); }
static float tone(const std::vector<float>& v, float hz, int from) {   // amplitude of one frequency (Goertzel-style DFT bin)
    double re = 0, im = 0; int cnt = 0;
    for (size_t i = from; i < v.size(); ++i, ++cnt) { double a = 6.283185307 * hz * i / SR; re += v[i] * std::cos(a); im += v[i] * std::sin(a); }
    return (float) (2.0 * std::sqrt(re * re + im * im) / cnt);
}
static void neutral() {   // transparent-ish settings: nothing but the converter
    D(effSetProgram, 0, 0);
    setNorm(P_WARM, 0.f); setNorm(P_NOISE, 0.f); setNorm(P_FILT, 1.f); setNorm(P_AAF, 1.f);
    D(effMainsChanged, 0, 1);
}

int main(int argc, char** argv) {
    void* h = dlopen(argc > 1 ? argv[1] : "build/native/dust12.so", RTLD_NOW);
    if (!h) { std::printf("dlopen: %s\n", dlerror()); return 2; }
    auto entry = (AEffect* (*)(audioMasterCallback)) dlsym(h, "VSTPluginMain");
    if (!entry) { std::printf("no VSTPluginMain\n"); return 2; }
    fx = entry(host);
    CHECK(fx && fx->magic == kEffectMagic, "magic");
    CHECK(fx->numInputs == 2 && fx->numOutputs == 2, "io");
    CHECK(fx->flags & effFlagsCanReplacing, "replacing flag");
    CHECK(fx->uniqueID == 0x44753132, "uid %08x", fx->uniqueID);
    CHECK(fx->numParams == P_COUNT && fx->numPrograms == 12, "counts %d/%d", fx->numParams, fx->numPrograms);
    CHECK(D(effGetPlugCategory) == kPlugCategEffect, "category");
    D(effOpen); D(effSetSampleRate, 0, 0, nullptr, SR); D(effSetBlockSize, 0, 512); D(effMainsChanged, 0, 1);

    std::printf("Parameters:\n");
    for (int i = 0; i < fx->numParams; ++i) {
        char n[64] = {}, d[64] = {}, u[64] = {};
        D(effGetParamName, i, 0, n); D(effGetParamDisplay, i, 0, d); D(effGetParamLabel, i, 0, u);
        std::printf("  %2d %-12s %-10s %s\n", i, n, d, u);
        CHECK(std::strlen(n) > 0, "param %d name", i);
        if (i != P_LEVEL) { setNorm(i, 0.37f); float a = getNorm(i); setNorm(i, a); CHECK(std::fabs(getNorm(i) - a) < 1e-6f, "param %d roundtrip", i); }
    }
    D(effSetProgram, 0, 0);
    { char d[64] = {}; D(effGetParamDisplay, P_RATE, 0, d); CHECK(!std::strcmp(d, "26.04 kHz"), "default rate shows '%s'", d);
      D(effGetParamDisplay, P_BITS, 0, d); CHECK(!std::strcmp(d, "12"), "default bits '%s'", d);
      D(effGetParamDisplay, P_FILT, 0, d); CHECK(!std::strcmp(d, "12.0 kHz"), "default filter '%s'", d);
      D(effGetParamDisplay, P_AAF, 0, d); CHECK(!std::strcmp(d, "Off"), "AA filter default '%s'", d); }
    std::printf("Programs:\n");
    for (int i = 0; i < fx->numPrograms; ++i) { char n[64] = {}; D(effGetProgramNameIndexed, i, 0, n); std::printf("  %2d %s\n", i, n); CHECK(n[0], "preset name"); }
    automateCalls = displayCalls = 0; D(effSetProgram, 0, 4);
    CHECK(automateCalls == P_COUNT - 1 && displayCalls == 1, "preset change notifies host (%d automate, %d display)", automateCalls, displayCalls);
    CHECK(D(effGetProgram) == 4, "program 4");

    // rate detent: anything within 3 % of 26.04 kHz snaps to exactly 26.04 kHz
    { setLog(P_RATE, 4000.f, 48000.f, 25500.f); char d[64] = {}; D(effGetParamDisplay, P_RATE, 0, d);
      CHECK(!std::strcmp(d, "26.04 kHz"), "detent: 25.5 kHz shows '%s'", d);
      setLog(P_RATE, 4000.f, 48000.f, 20000.f); D(effGetParamDisplay, P_RATE, 0, d); CHECK(std::strcmp(d, "26.04 kHz") != 0, "20 kHz must not snap"); }

    std::vector<float> l, r, ol, orr;

    // 1) bit depth: round-mode SNR of a -6 dBFS sine tracks 6.02 dB/bit (rate high enough to bypass the hold)
    for (int bits : { 8, 12, 16 }) {
        neutral(); setLog(P_RATE, 4000.f, 48000.f, 48000.f); setPlainLin(P_BITS, 4.f, 16.f, (float) bits); setChoice(P_QUANT, 1); D(effMainsChanged, 0, 1);
        makeSine(l, r, 0.5f, 997.f); proc(l, r, ol, orr);
        double sc = 0, ss = 0, cc = 0, so = 0, co = 0; int cnt = 0;   // fit out ~ a*sin + b*cos, residual = converter error
        for (int i = N / 2; i < N; ++i, ++cnt) { double a = 6.283185307 * 997.0 * i / SR, s_ = std::sin(a), c_ = std::cos(a); so += ol[i] * s_; co += ol[i] * c_; ss += s_ * s_; cc += c_ * c_; sc += s_ * c_; }
        double det = ss * cc - sc * sc, A = (so * cc - co * sc) / det, B = (co * ss - so * sc) / det, e2 = 0;
        for (int i = N / 2; i < N; ++i) { double a = 6.283185307 * 997.0 * i / SR, d = ol[i] - (A * std::sin(a) + B * std::cos(a)); e2 += d * d; }
        float snr = db(std::sqrt((A * A + B * B) / 2)) - db((float) std::sqrt(e2 / cnt)), expect = 6.02f * bits + 1.76f - 6.02f;
        std::printf("bits %2d: SNR %.1f dB (expect ~%.1f)\n", bits, snr, expect);
        if (bits < 16) CHECK(std::fabs(snr - expect) < 3.f, "%d-bit SNR %.1f vs %.1f", bits, snr, expect);
    }
    // truncate vs round differ
    { neutral(); setLog(P_RATE, 4000.f, 48000.f, 48000.f); setPlainLin(P_BITS, 4.f, 16.f, 6.f); D(effMainsChanged, 0, 1);
      makeSine(l, r, 0.5f, 997.f); proc(l, r, ol, orr); std::vector<float> a = ol;
      setChoice(P_QUANT, 1); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
      double diff = 0; for (int i = 0; i < N; ++i) diff += std::fabs(a[i] - ol[i]); CHECK(diff > 1.0, "truncate and round must differ (%.3f)", diff); }

    // 2) sample-and-hold: 10 kHz at 26.04 kHz images at 16.04 kHz; with the hold bypassed there is no image
    { neutral(); setPlainLin(P_BITS, 4.f, 16.f, 16.f); setChoice(P_QUANT, 1); D(effMainsChanged, 0, 1);
      makeSine(l, r, 0.5f, 10000.f); proc(l, r, ol, orr);
      float fund = tone(ol, 10000.f, N / 2), img = tone(ol, 16040.f, N / 2);
      std::printf("hold 26.04k: fundamental %.1f dB, 16.04k image %.1f dB\n", db(fund / 0.5f), db(img / 0.5f));
      CHECK(db(fund / 0.5f) > -5.f && db(fund / 0.5f) < -1.f, "hold droop %.1f dB", db(fund / 0.5f));
      CHECK(db(img / fund) > -25.f, "alias image missing: %.1f dB below fundamental", db(img / fund));
      setLog(P_RATE, 4000.f, 48000.f, 48000.f); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
      float img2 = tone(ol, 16040.f, N / 2), fund2 = tone(ol, 10000.f, N / 2);
      CHECK(db(img2 / fund2) < -60.f, "bypassed hold still has an image: %.1f dB", db(img2 / fund2)); }
    // smooth reconstruction has less image energy than stair-step
    { neutral(); setPlainLin(P_BITS, 4.f, 16.f, 16.f); setChoice(P_QUANT, 1); D(effMainsChanged, 0, 1);
      makeSine(l, r, 0.5f, 10000.f); proc(l, r, ol, orr); float stair = tone(ol, 16040.f, N / 2);
      setChoice(P_RECON, 1); D(effMainsChanged, 0, 1); proc(l, r, ol, orr); float smooth = tone(ol, 16040.f, N / 2);
      CHECK(smooth < stair, "smooth image %.4f should be below stair-step %.4f", smooth, stair); }
    // pre-converter filter removes the aliasing
    { neutral(); setPlainLin(P_BITS, 4.f, 16.f, 16.f); setChoice(P_QUANT, 1); D(effMainsChanged, 0, 1);
      makeSine(l, r, 0.5f, 10000.f); proc(l, r, ol, orr); float noAA = tone(ol, 16040.f, N / 2);
      setLog(P_AAF, 2000.f, 20000.f, 3000.f); D(effMainsChanged, 0, 1); proc(l, r, ol, orr); float withAA = tone(ol, 16040.f, N / 2);
      std::printf("alias image: %.1f dB without AA filter, %.1f dB with (3 kHz, 2-pole)\n", db(noAA), db(withAA));
      CHECK(db(noAA) - db(withAA) > 15.f, "AA filter should cut the folded image by >15 dB (%.1f)", db(noAA) - db(withAA)); }

    // 3) hot input clips at the converter, meter reports it
    { neutral(); D(effMainsChanged, 0, 1); setPlainLin(P_IN, -12.f, 18.f, 12.f); setNorm(P_IN, (12.f + 12.f) / 30.f);
      setLog(P_RATE, 4000.f, 48000.f, 48000.f); setPlainLin(P_BITS, 4.f, 16.f, 16.f); D(effMainsChanged, 0, 1);
      makeSine(l, r, 0.5f, 997.f); proc(l, r, ol, orr);
      float pk = peakOf(ol, N / 2); std::printf("hot input: out peak %.3f, meter norm %.2f\n", pk, getNorm(P_LEVEL));
      CHECK(pk <= 1.02f && pk > 0.99f, "hard clip peak %.4f", pk);   // tiny overshoot = the 5 Hz DC blocker
      CHECK(getNorm(P_LEVEL) > 0.95f, "meter should show +6 dB, got %.2f", getNorm(P_LEVEL));
      setChoice(P_CLIP, 1); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
      CHECK(peakOf(ol, N / 2) < pk, "soft clip should peak lower than hard clip"); }

    // 4) bypass and mix 0 pass audio through untouched
    { neutral(); makeSine(l, r, 0.5f, 997.f);
      fx->setParameter(fx, P_BYPASS, 1.f); proc(l, r, ol, orr);
      double d = 0; for (int i = 0; i < N; ++i) d += std::fabs(ol[i] - l[i]); CHECK(d == 0.0, "bypass not bit-exact (%g)", d);
      fx->setParameter(fx, P_BYPASS, 0.f); setNorm(P_MIX, 0.f); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
      d = 0; for (int i = N / 2; i < N; ++i) d = std::fmax(d, std::fabs(ol[i] - l[i])); CHECK(d < 1e-5, "mix 0 differs from dry (%g)", d); }

    // 5) mono fold
    { neutral(); makeSine(l, r, 0.5f, 997.f); std::fill(r.begin(), r.end(), 0.f); setNorm(P_MONO, 1.f); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
      double d = 0; for (int i = 0; i < N; ++i) d = std::fmax(d, std::fabs(ol[i] - orr[i])); CHECK(d < 1e-6, "mono outputs differ (%g)", d); }

    // 6) noise floor: silence in, -60 dB rms out
    { neutral(); setPlainLin(P_NOISE, -96.f, -40.f, -60.f); D(effMainsChanged, 0, 1);
      l.assign(N, 0.f); r.assign(N, 0.f); proc(l, r, ol, orr); float lvl = db(rmsOf(ol, N / 2));
      std::printf("noise: %.1f dB rms (set -60)\n", lvl); CHECK(std::fabs(lvl + 60.f) < 3.f, "noise level %.1f", lvl); }

    // 7) output filter: 4-pole at 3 kHz takes >= 24 dB off a 15 kHz tone
    { neutral(); setLog(P_FILT, 1000.f, 20000.f, 3000.f); setPlainLin(P_BITS, 4.f, 16.f, 16.f); setLog(P_RATE, 4000.f, 48000.f, 48000.f);
      setChoice(P_QUANT, 1); D(effMainsChanged, 0, 1); makeSine(l, r, 0.5f, 15000.f); proc(l, r, ol, orr);
      float att = db(0.5f) - db(tone(ol, 15000.f, N / 2)); std::printf("filter 3k @15k: -%.1f dB\n", att); CHECK(att > 24.f, "attenuation %.1f", att); }

    // 8) block-size independence (state continuity), including wobble/dither/noise
    { D(effSetProgram, 0, 2); setNorm(P_DITHER, 0.5f); D(effMainsChanged, 0, 1);
      makeSine(l, r, 0.4f, 440.f); proc(l, r, ol, orr, 512); std::vector<float> a = ol;
      D(effMainsChanged, 0, 1); proc(l, r, ol, orr, 37);
      double d = 0; for (int i = 0; i < N; ++i) d = std::fmax(d, std::fabs(a[i] - ol[i])); CHECK(d < 1e-4, "block-size dependent output (%g)", d); }

    // 9) wobble changes the sound
    { neutral(); setPlainLin(P_BITS, 4.f, 16.f, 16.f); D(effMainsChanged, 0, 1); makeSine(l, r, 0.4f, 3000.f); proc(l, r, ol, orr); std::vector<float> a = ol;
      setNorm(P_WOBBLE, 1.f); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
      double d = 0; for (int i = 0; i < N; ++i) d += std::fabs(a[i] - ol[i]); CHECK(d > 1.0, "wobble had no effect (%.3f)", d); }

    // 10) live meter notifications, throttled
    { neutral(); D(effMainsChanged, 0, 1); meterCalls = 0; makeSine(l, r, 0.5f, 997.f, N); proc(l, r, ol, orr);
      std::printf("meter host updates over 1 s: %d\n", meterCalls); CHECK(meterCalls >= 1 && meterCalls <= 20, "meter calls %d", meterCalls); }

    // 11) every preset, then random fuzz: output must stay finite and bounded
    for (int p = 0; p < fx->numPrograms; ++p) {
        D(effSetProgram, 0, p); D(effMainsChanged, 0, 1); makeSine(l, r, 0.7f, 220.f, 8192); proc(l, r, ol, orr);
        bool ok = true; for (float x : ol) if (!std::isfinite(x) || std::fabs(x) > 6.f) ok = false;
        CHECK(ok, "preset %d produced non-finite/huge output", p);
        CHECK(peakOf(ol, 2048) > 0.01f, "preset %d is silent", p);
    }
    srand(7);
    for (int t = 0; t < 300; ++t) {
        for (int i = 0; i < P_COUNT; ++i) if (i != P_LEVEL && i != P_BYPASS) setNorm(i, (float) rand() / RAND_MAX);
        if (t % 50 == 0) D(effMainsChanged, 0, 1);
        int len = 1 + rand() % 700; std::vector<float> a(len), b(len);
        for (int i = 0; i < len; ++i) { a[i] = ((float) rand() / RAND_MAX * 2.f - 1.f) * 1.5f; b[i] = ((float) rand() / RAND_MAX * 2.f - 1.f) * 1.5f; }
        proc(a, b, ol, orr, 1 + rand() % 256);
        bool ok = true; for (int i = 0; i < len; ++i) if (!std::isfinite(ol[i]) || !std::isfinite(orr[i]) || std::fabs(ol[i]) > 30.f) ok = false;
        CHECK(ok, "fuzz %d non-finite/huge", t);
    }
    // silence after signal must decay to exact zero-ish (no denormal ringing)
    { neutral(); makeSine(l, r, 0.9f, 500.f); proc(l, r, ol, orr); l.assign(N * 2, 0.f); r.assign(N * 2, 0.f); proc(l, r, ol, orr);
      CHECK(peakOf(ol, N * 2 - 1000) < 1e-4f, "tail did not decay: %g", peakOf(ol, N * 2 - 1000)); }

    D(effClose);
    std::printf("\n%s (%d failure%s)\n", fails ? "FAILED" : "ALL TESTS PASSED", fails, fails == 1 ? "" : "s");
    return fails ? 1 : 0;
}
