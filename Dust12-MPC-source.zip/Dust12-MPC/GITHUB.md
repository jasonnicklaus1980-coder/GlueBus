# Build in the cloud (no computer needed)

1. Create a **new** GitHub repo just for Dust 12 (the workflow unpacks the first `*.zip` it finds, so don't mix it into the GlueBus repo).
2. Upload `Dust12-MPC-source.zip` **and** the `.github/workflows/build.yml` file from it (or upload the unzipped project folder).
3. The **build** workflow runs on push: host tests, ARM cross-compile, ELF checks, then it publishes a release with
   `Dust12-1.0.0-mpc-armv7.zip`.
4. On the MPC (SSH as root, e.g. Terminus): download or upload the zip to `/tmp`, then
   `cd /tmp && unzip -o Dust12-1.0.0-mpc-armv7.zip && sh Dust12-1.0.0/install.sh`
