# Dust 12 (MPC)

SP-1200-style **12-bit sampler converter** as a native **MPC OS VST2 effect** (insert), packaged like GlueBus.

Put it on a drum bus, a sample track or the master and it runs the audio through an emulated old-sampler
converter path: the aliasing, the stair-steps, the 12-bit grit, the hot-input clipping and the filtered output.

- Target: Gen1 MPC OS (Force, Live/Live II, One, X, Key 61) - 32-bit ARM hard-float, glibc <= 2.34
- Install: `/sdcard/vst/dust12.so`, registered in `MPC.settings` (`pluginList-arm`), then restart MPC
- No JUCE, no GUI libraries, not even libstdc++: only libc + libm
- 17 parameters, 12 factory presets exposed as VST programs

## Signal path
input gain > (optional) AA filter > mono fold > **converter clip** (hard or soft) > **sample-and-hold at the clock rate**
> **N-bit quantiser** (truncate or round, optional TPDF dither) > stair-step or smooth reconstruction > DC blocker
> analog noise > warmth (soft saturation) > **4-pole low-pass** > mix > output

| Control | What it does |
|---|---|
| Input | Drive into the converter (-12..+18 dB). Above 0 dBFS the converter clips. |
| AA Filter | Optional 2-pole low-pass *before* the converter. Off = aliasing folds straight back (the classic sound). |
| Sample Rate | Clock rate, 4-48 kHz, detent at **26.04 kHz** (SP-1200). At or above the host rate the hold is bypassed. |
| Bit Depth | 4-16 bit, default 12. |
| Quantize / Dither | Truncate or round; TPDF dither up to +-1 LSB. |
| Reconstruct | Stair-step (zero-order hold) or smooth (linear, one clock period of latency). |
| Noise | Converter/analog noise floor, -96 (off) to -40 dB rms. |
| Wobble | Random clock jitter (a creative addition, not an SP-1200 spec). |
| Out Filter | 4-pole (24 dB/oct) low-pass after the converter. |
| Warmth | Output-stage soft saturation. |
| Converter Clip | Hard clip or soft clip at full scale. |
| Mono, Mix, Output, Bypass | Mono fold, dry/wet, output trim, bypass. |

The screen skin has one page with all 16 Q-Links and a live converter-level meter (red = clipping).

## Build + install
    make test                          # native x86 build + offline VST2 host test (no MPC needed)
    ./scripts/package.sh               # cross-compiles for ARM (or Docker linux/arm/v7), verifies the ELF, builds dist/
    ./scripts/deploy.sh <mpc-ip>       # tar-over-ssh, runs install.sh (stops MPC, copies, backs up, registers, restarts)
See `mpc/INSTALL.md` and `GITHUB.md` (build in the cloud from a phone).

## What is and isn't verified
- Verified offline (x86): bit-depth SNR matches theory (8/12/16-bit within 0.2 dB), the 26.04 kHz hold produces the expected
  alias image and the AA filter cuts it, clipping, noise level, filter slope, bypass, mix, mono, block-size independence,
  and 300 random-parameter fuzz runs stay finite.
- **Not run on a real MPC yet.** The ARM build is produced by the GitHub Actions workflow, and the skin follows the
  GlueBus/JV-880 `TUI.json` format but hasn't been seen on your screen.
- This is an original emulation of the SP-1200's publicly documented character, not a measurement of hardware and not
  a copy of any commercial plugin. It will sound in the same family, not identical.
