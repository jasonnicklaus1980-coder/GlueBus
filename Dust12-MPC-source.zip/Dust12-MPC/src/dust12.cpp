// Dust 12 - SP-1200-style 12-bit sampler converter as a dependency-free VST2 effect for Akai MPC OS
// (Gen1, 32-bit ARM). Needs only libc/libm (linked with the C driver: no libstdc++). No GUI: MPC draws the
// skin in /sdcard/Synths.
//
// Original emulation of the *publicly documented* character of the E-mu SP-1200 signal path, not a copy of
// any hardware or software product:
//   input gain -> (optional) pre-converter filter -> converter clip -> 26.04 kHz sample-and-hold -> 12-bit
//   quantiser -> stair-step (zero-order-hold) output -> analog noise -> output stage -> 4-pole low-pass.
// With the filter before the converter left off, content above half the clock rate folds back as aliasing.
#include "vst2.h"
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>

#define DD_EXPORT extern "C" __attribute__((visibility("default")))

namespace
{
enum ParamId
{
    P_IN, P_AAF, P_RATE, P_BITS, P_QUANT, P_DITHER, P_RECON, P_NOISE, P_FILT, P_WARM,
    P_CLIP, P_MONO, P_MIX, P_OUT, P_WOBBLE, P_LEVEL, P_BYPASS,
    P_COUNT
};
enum Kind { K_FLOAT, K_CHOICE, K_BOOL, K_LOG };
enum Fmt  { F_NUM, F_KHZ, F_AAF, F_FILT, F_NOISE };

const char* const kQuantNames[] { "Truncate", "Round" };
const char* const kReconNames[] { "Stair-step", "Smooth" };
const char* const kClipNames[]  { "Hard", "Soft" };

constexpr float kRateSP  = 26040.f;               // SP-1200 sample rate; the rate knob has a detent here
constexpr float kFilterOff = 20000.f;             // top end of the filter knobs = filter off
constexpr float kNoiseOff = -96.f;
constexpr float kLevelLo = -48.f, kLevelHi = 6.f; // converter-level meter range (dBFS)

struct ParamDef
{
    const char* name; const char* unit; Kind kind;
    float lo, hi, step, def;
    const char* const* choices; int n; Fmt fmt; const char* numFmt;
};

#define CH(names) names, (int) (sizeof (names) / sizeof (names[0]))
const ParamDef kParams[P_COUNT] =
{
    { "Input",      "dB", K_FLOAT,  -12.f, 18.f, 0.1f, 0.f,    nullptr, 0, F_NUM, "%.1f" },
    { "AA Filter",  "",   K_LOG,   2000.f, kFilterOff, 0.f, kFilterOff, nullptr, 0, F_AAF, "" },
    { "Sample Rate","",   K_LOG,   4000.f, 48000.f, 0.f, kRateSP, nullptr, 0, F_KHZ, "" },
    { "Bit Depth",  "bit",K_FLOAT,    4.f, 16.f, 1.f,  12.f,   nullptr, 0, F_NUM, "%.0f" },
    { "Quantize",   "",   K_CHOICE,   0.f,  1.f, 1.f,  0.f,    CH (kQuantNames), F_NUM, "" },
    { "Dither",     "%",  K_FLOAT,    0.f,100.f, 1.f,  0.f,    nullptr, 0, F_NUM, "%.0f" },
    { "Recon",      "",   K_CHOICE,   0.f,  1.f, 1.f,  0.f,    CH (kReconNames), F_NUM, "" },
    { "Noise",      "dB", K_FLOAT,  kNoiseOff, -40.f, 1.f, -78.f, nullptr, 0, F_NOISE, "%.0f" },
    { "Out Filter", "",   K_LOG,   1000.f, kFilterOff, 0.f, 12000.f, nullptr, 0, F_FILT, "" },
    { "Warmth",     "%",  K_FLOAT,    0.f,100.f, 1.f,  20.f,   nullptr, 0, F_NUM, "%.0f" },
    { "Clip",       "",   K_CHOICE,   0.f,  1.f, 1.f,  0.f,    CH (kClipNames), F_NUM, "" },
    { "Mono",       "",   K_BOOL,     0.f,  1.f, 1.f,  0.f,    nullptr, 0, F_NUM, "" },
    { "Mix",        "%",  K_FLOAT,    0.f,100.f, 1.f, 100.f,   nullptr, 0, F_NUM, "%.0f" },
    { "Output",     "dB", K_FLOAT,  -12.f, 12.f, 0.1f, 0.f,    nullptr, 0, F_NUM, "%.1f" },
    { "Wobble",     "%",  K_FLOAT,    0.f,100.f, 1.f,  0.f,    nullptr, 0, F_NUM, "%.0f" },
    { "Level",      "dB", K_FLOAT, kLevelLo, kLevelHi, 0.01f, kLevelLo, nullptr, 0, F_NUM, "%.1f" },   // read-only
    { "Bypass",     "",   K_BOOL,     0.f,  1.f, 1.f,  0.f,    nullptr, 0, F_NUM, "" },
};

// ---- 12 factory presets: defaults + overrides ----
struct Ov { int id; float v; };
struct Preset { const char* name; const Ov* ov; int n; };
#define PRESET(sym, ...) const Ov sym[] = { __VA_ARGS__ };
#define ENTRY(name, sym) { name, sym, (int) (sizeof (sym) / sizeof (sym[0])) }

PRESET (pInit,    { P_IN, 0.f })
PRESET (pBoomBap, { P_IN, 6.f }, { P_WARM, 45.f }, { P_FILT, 10000.f }, { P_NOISE, -72.f })
PRESET (pDusty,   { P_IN, 3.f }, { P_NOISE, -64.f }, { P_WOBBLE, 25.f }, { P_FILT, 8500.f }, { P_WARM, 35.f })
PRESET (pClean,   { P_QUANT, 1 }, { P_DITHER, 60.f }, { P_RECON, 1 }, { P_NOISE, kNoiseOff }, { P_WARM, 0.f }, { P_FILT, 16000.f })
PRESET (pDrums,   { P_IN, 10.f }, { P_WARM, 50.f }, { P_FILT, 11000.f })
PRESET (pKeys,    { P_RATE, 16000.f }, { P_BITS, 10.f }, { P_RECON, 1 }, { P_FILT, 6500.f }, { P_WARM, 25.f },
                  { P_NOISE, -70.f }, { P_WOBBLE, 15.f })
PRESET (pBass,    { P_IN, 5.f }, { P_RATE, 13020.f }, { P_FILT, 3800.f }, { P_WARM, 60.f })
PRESET (pAlias,   { P_RATE, 14000.f }, { P_FILT, kFilterOff }, { P_NOISE, -84.f }, { P_WARM, 0.f })
PRESET (pCrush,   { P_BITS, 8.f }, { P_RATE, 11000.f }, { P_FILT, 5000.f }, { P_NOISE, -60.f })
PRESET (pMono,    { P_MONO, 1 }, { P_IN, 4.f }, { P_WARM, 40.f }, { P_FILT, 9500.f })
PRESET (pGlue,    { P_MIX, 55.f }, { P_WARM, 30.f }, { P_FILT, 13000.f }, { P_IN, 2.f })
PRESET (pTape,    { P_CLIP, 1 }, { P_IN, 9.f }, { P_QUANT, 1 }, { P_DITHER, 30.f }, { P_RECON, 1 }, { P_WARM, 35.f },
                  { P_FILT, 11000.f }, { P_WOBBLE, 10.f })

const Preset kPresets[] =
{
    ENTRY ("SP Init", pInit),          ENTRY ("Boom Bap Crunch", pBoomBap), ENTRY ("Dusty Break", pDusty),
    ENTRY ("Clean 12", pClean),        ENTRY ("Hot Drums", pDrums),         ENTRY ("Lo-Fi Keys", pKeys),
    ENTRY ("Bass Grit", pBass),        ENTRY ("Alias Air", pAlias),         ENTRY ("Crushed 8", pCrush),
    ENTRY ("Mono Punch", pMono),       ENTRY ("Subtle Glue", pGlue),        ENTRY ("Soft Clip Tape", pTape),
};
constexpr int kNumPresets = (int) (sizeof (kPresets) / sizeof (kPresets[0]));

inline float clampf (float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
inline float flush (float x) { return std::fabs (x) < 1e-20f ? 0.f : x; }
inline float toDb (float lin) { return 6.0206f * std::log2 (lin + 1e-9f); }
inline float fromDb (float db) { return std::exp2 (db * 0.16609640f); }
inline float softSat (float x)   // tanh-like rational approximation, exact +-1 beyond |x|=3
{
    if (x >= 3.f) return 1.f;
    if (x <= -3.f) return -1.f;
    const float x2 = x * x;
    return x * (27.f + x2) / (27.f + 9.f * x2);
}

float toPlain (const ParamDef& d, float norm)
{
    norm = clampf (norm, 0.f, 1.f);
    if (d.kind == K_BOOL) return norm >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return std::floor (norm * (float) (d.n - 1) + 0.5f);
    if (d.kind == K_LOG) return d.lo * std::pow (d.hi / d.lo, norm);
    float v = d.lo + norm * (d.hi - d.lo);
    if (d.step > 0.f) v = d.lo + std::floor ((v - d.lo) / d.step + 0.5f) * d.step;
    return clampf (v, d.lo, d.hi);
}
float toNorm (const ParamDef& d, float plain)
{
    if (d.kind == K_BOOL) return plain >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return d.n > 1 ? clampf (plain / (float) (d.n - 1), 0.f, 1.f) : 0.f;
    if (d.kind == K_LOG) return clampf (std::log (clampf (plain, d.lo, d.hi) / d.lo) / std::log (d.hi / d.lo), 0.f, 1.f);
    return clampf ((plain - d.lo) / (d.hi - d.lo), 0.f, 1.f);
}
inline float snapRate (float hz) { return std::fabs (hz / kRateSP - 1.f) < 0.03f ? kRateSP : hz; }   // detent at 26.04 kHz

void copyStr (void* dst, const char* src, size_t max = 24)
{
    if (dst == nullptr) return;
    std::strncpy ((char*) dst, src, max - 1);
    ((char*) dst)[max - 1] = 0;
}
void fmtHz (char* out, size_t max, float hz)
{
    if (hz < 1000.f) std::snprintf (out, max, "%.0f Hz", (double) hz);
    else             std::snprintf (out, max, "%.1f kHz", (double) (hz * 0.001f));
}

// ---- RBJ low-pass biquad, transposed direct form II, stereo ----
struct Biquad
{
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
    float z1[2] {}, z2[2] {};
    bool active = false;

    inline float run (int c, float x)
    {
        const float y = b0 * x + z1[c];
        z1[c] = flush (b1 * x - a1 * y + z2[c]);
        z2[c] = flush (b2 * x - a2 * y);
        return y;
    }
    void clear() { z1[0] = z1[1] = z2[0] = z2[1] = 0.f; }
    void lowpass (double fs, double f, double q)
    {
        f = f < 10.0 ? 10.0 : (f > 0.45 * fs ? 0.45 * fs : f);
        const double w = 2.0 * 3.14159265358979 * f / fs, cw = std::cos (w), sw = std::sin (w), al = sw / (2 * q);
        const double a0 = 1 + al;
        b0 = (float) (((1 - cw) / 2) / a0); b1 = (float) ((1 - cw) / a0); b2 = b0;
        a1 = (float) ((-2 * cw) / a0);      a2 = (float) ((1 - al) / a0);
    }
};

struct Plugin
{
    AEffect fx {};
    audioMasterCallback master = nullptr;

    std::atomic<float> v[P_COUNT];     // plain (un-normalised) parameter values
    std::atomic<float> meter { kLevelLo };
    int program = 0;
    float sr = 44100.f;

    // DSP state (audio thread only)
    enum { F_AA, F_O1, F_O2, NF };
    Biquad filt[NF];
    float keyAa = -1.f, keyOf = -1.f, keySr = -1.f;
    float sIn = 1.f, sOut = 1.f, sMix = 1.f;
    bool snap = true;
    float phase = 0.f, prevIn[2] {}, prevTick[2] {}, curTick[2] {};
    float dcX[2] {}, dcY[2] {};
    float wob = 0.f, wobTarget = 0.f; int wobCount = 0;
    uint32_t rng = 0x12345678u;
    float peakHold = 0.f;
    int meterCountdown = 0; float meterSent = -1000.f;

    Plugin() { for (int i = 0; i < P_COUNT; ++i) v[i].store (kParams[i].def); }

    inline float rnd()   // xorshift32 -> [0, 1)
    {
        rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
        return (float) (rng >> 8) * (1.f / 16777216.f);
    }

    void applyPreset (int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        program = i;
        for (int p = 0; p < P_COUNT; ++p) if (p != P_LEVEL && p != P_BYPASS) v[p].store (kParams[p].def);
        for (int k = 0; k < kPresets[i].n; ++k) v[kPresets[i].ov[k].id].store (kPresets[i].ov[k].v);
    }

    // Tell the host every parameter changed (after a preset load), then ask it to refresh its display.
    void notifyHostAll()
    {
        if (master == nullptr) return;
        for (int i = 0; i < P_COUNT; ++i)
        {
            if (i == P_LEVEL) continue;
            master (&fx, 0 /* audioMasterAutomate */, i, 0, nullptr, toNorm (kParams[i], v[i].load()));
        }
        master (&fx, 42 /* audioMasterUpdateDisplay */, 0, 0, nullptr, 0.f);
    }

    // Push the converter-level meter to the host ~15x per second, only when it moved.
    void sendMeter (int n)
    {
        if (master == nullptr) return;
        meterCountdown -= n;
        if (meterCountdown > 0) return;
        meterCountdown = (int) (sr / 15.f);
        const float m = meter.load();
        if (std::fabs (m - meterSent) < 0.5f) return;
        meterSent = m;
        master (&fx, 0 /* audioMasterAutomate */, P_LEVEL, 0, nullptr, toNorm (kParams[P_LEVEL], m));
    }

    void reset()
    {
        for (auto& f : filt) f.clear();
        for (int c = 0; c < 2; ++c) { prevIn[c] = prevTick[c] = curTick[c] = 0.f; dcX[c] = dcY[c] = 0.f; }
        phase = 0.f; wob = wobTarget = 0.f; wobCount = 0; peakHold = 0.f; rng = 0x12345678u;   // repeatable noise per start
        meter.store (kLevelLo); snap = true; keyAa = keyOf = keySr = -1.f;
        meterSent = -1000.f; meterCountdown = 0;
    }

    void display (int idx, char* out, size_t max) const
    {
        const ParamDef& d = kParams[idx];
        const float p = v[idx].load();
        if (idx == P_LEVEL) { std::snprintf (out, max, "%.1f", (double) meter.load()); return; }
        if (d.kind == K_CHOICE) { std::snprintf (out, max, "%s", d.choices[(int) clampf (p, 0.f, (float) (d.n - 1))]); return; }
        if (d.kind == K_BOOL)   { std::snprintf (out, max, "%s", p >= 0.5f ? "On" : "Off"); return; }
        switch (d.fmt)
        {
            case F_KHZ:   std::snprintf (out, max, "%.2f kHz", (double) (p * 0.001f)); return;
            case F_AAF:
            case F_FILT:  if (p >= kFilterOff * 0.98f) std::snprintf (out, max, "Off"); else fmtHz (out, max, p); return;
            case F_NOISE: if (p <= kNoiseOff + 0.5f) std::snprintf (out, max, "Off"); else std::snprintf (out, max, "%.0f dB", (double) p); return;
            default:      std::snprintf (out, max, d.numFmt, (double) p); return;
        }
    }

    void designFilters()
    {
        const float aa = v[P_AAF].load(), of = v[P_FILT].load();
        if (aa == keyAa && of == keyOf && sr == keySr) return;
        keyAa = aa; keyOf = of; keySr = sr;
        const double fs = sr;
        const bool aaOn = aa < kFilterOff * 0.98f, ofOn = of < kFilterOff * 0.98f;
        if (aaOn && ! filt[F_AA].active) filt[F_AA].clear();
        filt[F_AA].active = aaOn;
        if (aaOn) filt[F_AA].lowpass (fs, aa, 0.7071);
        if (ofOn && ! filt[F_O1].active) { filt[F_O1].clear(); filt[F_O2].clear(); }
        filt[F_O1].active = filt[F_O2].active = ofOn;
        if (ofOn) { filt[F_O1].lowpass (fs, of, 0.5412); filt[F_O2].lowpass (fs, of, 1.3066); }   // 24 dB/oct Butterworth
    }

    void process (const float* inL, const float* inR, float* outL, float* outR, int n)
    {
        if (v[P_BYPASS].load() > 0.5f)
        {
            if (outL != inL) std::memcpy (outL, inL, sizeof (float) * (size_t) n);
            if (outR != inR) std::memcpy (outR, inR, sizeof (float) * (size_t) n);
            meter.store (kLevelLo); peakHold = 0.f; snap = true;
            sendMeter (n);
            return;
        }
        designFilters();

        // ---- settings ----
        const float tIn  = fromDb (v[P_IN].load());
        const float tOut = fromDb (v[P_OUT].load());
        const float tMix = v[P_MIX].load() * 0.01f;
        if (snap) { sIn = tIn; sOut = tOut; sMix = tMix; snap = false; }
        const float sm = 1.f - std::exp (-1.f / (0.02f * sr));

        const bool  aaOn = filt[F_AA].active, ofOn = filt[F_O1].active;
        const float rate = snapRate (v[P_RATE].load());
        const bool  hold = rate < sr * 0.999f;
        const float baseStep = hold ? rate / sr : 1.f;
        const bool  smooth = v[P_RECON].load() > 0.5f;
        const int   bits = (int) (clampf (v[P_BITS].load(), 4.f, 16.f) + 0.5f);
        const float S = (float) (1 << (bits - 1));                // codes per unit amplitude
        const bool  rounding = v[P_QUANT].load() > 0.5f;
        const float dither = v[P_DITHER].load() * 0.01f / S;      // TPDF, +-1 LSB at 100 %
        const float noiseDb = v[P_NOISE].load();
        const bool  noiseOn = noiseDb > kNoiseOff + 0.5f;
        const float noiseAmp = noiseOn ? fromDb (noiseDb) * 1.732f : 0.f;   // uniform noise, rms = noiseDb
        const float warm = v[P_WARM].load() * 0.01f, warmK = 1.f + 2.f * warm;
        const bool  softClip = v[P_CLIP].load() > 0.5f;
        const bool  mono = v[P_MONO].load() > 0.5f;
        const float wobAmt = v[P_WOBBLE].load() * 0.01f;
        const float wobC = 1.f - std::exp (-1.f / (0.003f * sr));
        const int   wobEvery = (int) (0.004f * sr);
        const float dcR = 1.f - 6.2831853f * 5.f / sr;

        float blockPeak = 0.f;
        for (int i = 0; i < n; ++i)
        {
            sIn += (tIn - sIn) * sm; sOut += (tOut - sOut) * sm; sMix += (tMix - sMix) * sm;
            const float dry[2] { inL[i], inR[i] };
            float x[2] { dry[0] * sIn, dry[1] * sIn };

            if (aaOn) { x[0] = filt[F_AA].run (0, x[0]); x[1] = filt[F_AA].run (1, x[1]); }
            if (mono) x[0] = x[1] = 0.5f * (x[0] + x[1]);

            const float pk = std::fmax (std::fabs (x[0]), std::fabs (x[1]));
            if (pk > blockPeak) blockPeak = pk;
            for (int c = 0; c < 2; ++c)   // the converter clips: hard (like the real thing) or soft
                x[c] = softClip ? softSat (x[c]) : clampf (x[c], -1.f, 1.f);

            float y[2];
            auto quant = [&] (float s)
            {
                if (dither > 0.f) s += (rnd() - rnd()) * dither;
                float q = std::floor (rounding ? s * S + 0.5f : s * S);
                return clampf (q, -S, S - 1.f) / S;
            };
            if (hold)
            {
                if (wobAmt > 0.f)
                {
                    if (--wobCount <= 0) { wobTarget = rnd() * 2.f - 1.f; wobCount = wobEvery; }
                    wob += (wobTarget - wob) * wobC;
                }
                float step = baseStep * (1.f + 0.06f * wobAmt * wob);
                step = clampf (step, 0.05f, 1.f);
                phase += step;
                if (phase >= 1.f)          // a clock tick fell inside this sample interval
                {
                    phase -= 1.f;
                    const float t = clampf (1.f - phase / step, 0.f, 1.f);   // where in the interval it fell
                    for (int c = 0; c < 2; ++c)
                    {
                        prevTick[c] = curTick[c];
                        curTick[c] = quant (prevIn[c] + (x[c] - prevIn[c]) * t);   // sample-and-hold, no filter
                    }
                }
                for (int c = 0; c < 2; ++c)
                    y[c] = smooth ? prevTick[c] + (curTick[c] - prevTick[c]) * phase : curTick[c];
            }
            else { y[0] = quant (x[0]); y[1] = quant (x[1]); }
            prevIn[0] = x[0]; prevIn[1] = x[1];

            for (int c = 0; c < 2; ++c)
            {
                float s = y[c];
                const float d = s - dcX[c] + dcR * dcY[c];   // remove the DC that truncation leaves behind
                dcX[c] = s; dcY[c] = flush (d); s = d;
                if (noiseOn) s += (rnd() * 2.f - 1.f) * noiseAmp;
                if (warm > 0.001f) s = softSat (warmK * s) / warmK;   // output-stage soft saturation
                if (ofOn) { s = filt[F_O1].run (c, s); s = filt[F_O2].run (c, s); }
                y[c] = s;
            }
            outL[i] = (dry[0] + sMix * (y[0] - dry[0])) * sOut;
            outR[i] = (dry[1] + sMix * (y[1] - dry[1])) * sOut;
        }
        peakHold = std::fmax (blockPeak, peakHold * std::exp (-(float) n / (0.3f * sr)));
        meter.store (clampf (toDb (peakHold), kLevelLo, kLevelHi));
        sendMeter (n);
    }
};

// ---- VST2 entry points ----
void processReplacing (AEffect* e, float** in, float** out, int32_t n)
{
    static_cast<Plugin*> (e->object)->process (in[0], in[1], out[0], out[1], n);
}

void processAccumulating (AEffect* e, float** in, float** out, int32_t n)   // legacy VST2 process()
{
    float tl[256], tr[256];
    Plugin* p = static_cast<Plugin*> (e->object);
    for (int32_t pos = 0; pos < n; pos += 256)
    {
        const int32_t m = (n - pos) < 256 ? (n - pos) : 256;
        p->process (in[0] + pos, in[1] + pos, tl, tr, m);
        for (int32_t i = 0; i < m; ++i) { out[0][pos + i] += tl[i]; out[1][pos + i] += tr[i]; }
    }
}

void setParameter (AEffect* e, int32_t i, float norm)
{
    if (i < 0 || i >= P_COUNT || i == P_LEVEL) return;
    float plain = toPlain (kParams[i], norm);
    if (i == P_RATE) plain = snapRate (plain);
    static_cast<Plugin*> (e->object)->v[i].store (plain);
}

float getParameter (AEffect* e, int32_t i)
{
    if (i < 0 || i >= P_COUNT) return 0.f;
    Plugin* p = static_cast<Plugin*> (e->object);
    if (i == P_LEVEL) return toNorm (kParams[i], p->meter.load());
    return toNorm (kParams[i], p->v[i].load());
}

intptr_t dispatcher (AEffect* e, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    switch (op)
    {
        case effClose:            p->~Plugin(); std::free (p); return 0;      // AEffect is embedded in Plugin
        case effSetProgram:       p->applyPreset ((int) val); p->notifyHostAll(); return 0;
        case effGetProgram:       return p->program;
        case effGetProgramName:   copyStr (ptr, kPresets[p->program].name); return 0;
        case effGetProgramNameIndexed:
            if (idx < 0 || idx >= kNumPresets) return 0;
            copyStr (ptr, kPresets[idx].name); return 1;
        case effGetParamName:     if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].name); return 0;
        case effGetParamLabel:    if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].unit); return 0;
        case effGetParamDisplay:
            if (idx >= 0 && idx < P_COUNT && ptr != nullptr) { char b[32]; p->display (idx, b, sizeof b); copyStr (ptr, b); }
            return 0;
        case effCanBeAutomated:   return (idx >= 0 && idx < P_COUNT && idx != P_LEVEL) ? 1 : 0;
        case effSetSampleRate:    if (opt > 1000.f) { p->sr = opt; p->snap = true; p->keySr = -1.f; } return 0;
        case effMainsChanged:     p->reset(); return 0;
        case effSetBypass:        p->v[P_BYPASS].store (val ? 1.f : 0.f); return 1;
        case effGetEffectName:
        case effGetProductString: copyStr (ptr, "Dust 12", 32); return 1;
        case effGetVendorString:  copyStr (ptr, "Dust 12", 32); return 1;
        case effGetVendorVersion: return 1000;
        case effGetPlugCategory:  return kPlugCategEffect;
        case effGetVstVersion:    return 2400;
        case effGetTailSize:      return 1;
        case effSetProcessPrecision: return val == 0 ? 1 : 0;      // 32-bit float only
        case effCanDo:
            if (ptr != nullptr && std::strcmp ((const char*) ptr, "bypass") == 0) return 1;
            return 0;
        default: return 0;
    }
}
} // namespace

DD_EXPORT AEffect* VSTPluginMain (audioMasterCallback master)
{
    void* mem = std::calloc (1, sizeof (Plugin));   // no operator new: keeps libstdc++ out of the link
    if (mem == nullptr) return nullptr;
    Plugin* p = new (mem) Plugin();
    p->master = master;
    p->applyPreset (0);
    AEffect& fx = p->fx;
    fx.magic = kEffectMagic;
    fx.dispatcher = dispatcher;
    fx.process = processAccumulating;
    fx.processReplacing = processReplacing;
    fx.setParameter = setParameter;
    fx.getParameter = getParameter;
    fx.numPrograms = kNumPresets;
    fx.numParams = P_COUNT;
    fx.numInputs = 2;
    fx.numOutputs = 2;
    fx.flags = effFlagsCanReplacing;
    fx.ioRatio = 1.f;
    fx.object = p;
    fx.uniqueID = ('D' << 24) | ('u' << 16) | ('1' << 8) | '2';   // 'Du12' = 0x44753132
    fx.version = 1000;
    return &fx;
}
