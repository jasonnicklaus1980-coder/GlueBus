# Dust 12 1.0.0

SP-1200-style 12-bit sampler converter as a native MPC OS VST2 plugin (effect).

## Requirements
- A first-generation MPC OS standalone device (32-bit ARM: Force, MPC Live / Live II, One, X, Key 61).
- **Root shell access** (SSH). Installing plugins this way is unofficial: back up first, use at your own risk.

## Install (scripted)
1. Copy the folder to the device: `scp -r Dust12-1.0.0 root@<device-ip>:/tmp/`  (or use `scripts/deploy.sh <device-ip>`)
2. Run it: `ssh root@<device-ip> sh /tmp/Dust12-1.0.0/install.sh`

The installer checks the device, copies `dust12.so` to `/sdcard/vst/` and the skin to
`/sdcard/Synths/Dust 12 - VST - Dust 12/`, **stops MPC** (save your project first), backs up `MPC.settings`,
adds the plugin to MPC's plugin list and starts MPC again. Re-running upgrades in place. Add `-y` to skip the prompt.

Then add **Dust 12** as an insert from the plugin browser (it lists under Effects). Q-Links 1-16:
Input, AA Filter, Sample Rate, Bit Depth, Wobble, Dither, Noise, Out Filter, Warmth, Mix, Output,
Converter Clip, Quantize, Reconstruct, Mono, Bypass. The 12 factory presets are the plugin's programs.

## Uninstall
`ssh root@<device-ip> sh /tmp/Dust12-1.0.0/uninstall.sh` removes the plugin, its skin and the plugin-list entry.

## Install by hand
1. Copy `payload/vst/dust12.so` to `/sdcard/vst/dust12.so` and
   `payload/Synths/Dust 12 - VST - Dust 12/` to `/sdcard/Synths/Dust 12 - VST - Dust 12/`.
2. `systemctl stop acvs`
3. Back up `MPC.settings` (`/media/az01-internal/Settings/*/MPC.settings`).
4. Inside `<VALUE name="pluginList-arm"><KNOWNPLUGINS>` add the line from `plugin.xml`
   (create the `pluginList-arm` value just before `</PROPERTIES>` if it doesn't exist).
5. `systemctl start acvs`. If MPC shows default settings, restore your backup (the XML was malformed).

## Troubleshooting
- Not in the list: it appears only after MPC restarts; check `grep dust12 /media/az01-internal/Settings/*/MPC.settings`.
- MPC crashes on load: run `uninstall.sh`, or restore the `MPC.settings.bak-dust12-*` backup and delete `/sdcard/vst/dust12.so`.
- Plain parameter list instead of the skin: check `/sdcard/Synths` is in MPC's SynthContentLocations, and that the skin
  folder name matches exactly. A skin-only change needs no restart: remove and re-insert the plugin.
- If the skin doesn't appear for the name "Dust 12" (space + digits), tell me: the fallback is a rename to "Dust12" in
  `plugin.xml`, `src/dust12.cpp`, `tools/make_skin.py` and the scripts.
