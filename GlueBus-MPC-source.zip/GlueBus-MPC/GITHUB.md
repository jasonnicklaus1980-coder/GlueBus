# Build GlueBus on GitHub (no computer needed)

GitHub Actions compiles the ARM plugin, runs the tests and publishes `GlueBus-1.1.0-mpc-armv7.zip` as a Release.

## From a phone
1. On github.com: **+ > New repository** (e.g. `gluebus`), Public or Private, create it.
2. **Add file > Upload files**, upload `GlueBus-MPC-source.zip` as-is, commit.
3. **Add file > Create new file**, name it exactly `.github/workflows/build.yml`,
   paste the contents of `.github/workflows/build.yml` from the zip, commit.
   (The workflow unpacks the source zip itself.)
4. Open the **Actions** tab; the "build" run takes ~2 minutes. Green = done.
5. Open **Releases** (repo front page, right side) and download `GlueBus-1.1.0-mpc-armv7.zip`.

## From a computer
    unzip GlueBus-MPC-source.zip && cd GlueBus-MPC
    git init && git add . && git commit -m "GlueBus" && git branch -M main
    git remote add origin https://github.com/<you>/gluebus.git && git push -u origin main

Every push builds again and makes a new release; the newest is always at
`https://github.com/<you>/gluebus/releases/latest/download/GlueBus-1.1.0-mpc-armv7.zip`.

## Install with Terminus
1. Connect to the MPC as root, upload the zip to `/tmp` (SFTP panel).
   If the MPC has internet and a wget with HTTPS, you can fetch it directly instead:
   `cd /tmp && wget https://github.com/<you>/gluebus/releases/latest/download/GlueBus-1.1.0-mpc-armv7.zip`
   (only works for a public repo).
2. `cd /tmp && unzip -o GlueBus-1.1.0-mpc-armv7.zip && sh GlueBus-1.1.0/install.sh`
3. Save your project first; answer `y`. MPC restarts with GlueBus in the plugin browser.

If the Actions run fails, open it and read the failing step; the glibc check stops the build rather than
shipping a plugin the MPC can't load.
