# GlueBus 1.1.0

Console-style channel strip (filters, 4-band EQ, gate/expander, bus compressor) as a native MPC OS VST2 plugin (effect). Loaded by MPC's built-in plugin host.

## Requirements
- A first-generation MPC OS standalone device (32-bit ARM: Force, MPC Live / Live II, One, X, Key 61).
- **Root shell access** (SSH). Installing plugins this way is unofficial: back up first, use at your own risk.

## Install (scripted)
1. From your computer: `scp -r GlueBus-1.1.0 root@<device-ip>:/tmp/`  (or use `scripts/deploy.sh <device-ip>`)
2. Run it: `ssh root@<device-ip> sh /tmp/GlueBus-1.1.0/install.sh`

The installer checks the device, copies `gluebus.so` to `/sdcard/vst/` and the skin to
`/sdcard/Synths/GlueBus - VST - GlueBus/`, **stops MPC** (save your project first),
backs up `MPC.settings`, adds the plugin to MPC's plugin list and starts MPC again. Re-running upgrades in place.
Add `-y` to skip the confirmation prompt.

Then add **GlueBus** as an insert from the plugin browser. It has two screen pages:
- **Dynamics** Q-Links: Threshold, Ratio, Attack, Release, Make-up, Mix, Knee, S/C HPF, Link, VCA Drive,
  Gate Threshold, Gate Range, Gate Release, Gate Mode, Comp In, Gate In.
- **EQ** Q-Links: HPF, LPF, LF Gain/Freq, LMF Gain/Freq/Q, HMF Gain/Freq/Q, HF Gain/Freq, EQ In, EQ Position, Input, Output.
The 20 factory presets are the plugin's programs.

## Uninstall
`ssh root@<device-ip> sh /tmp/GlueBus-1.1.0/uninstall.sh` removes the plugin, its skin and the plugin-list entry.

## Install by hand
1. Copy `payload/vst/gluebus.so` to `/sdcard/vst/gluebus.so` and
   `payload/Synths/GlueBus - VST - GlueBus/` to `/sdcard/Synths/GlueBus - VST - GlueBus/`.
2. `systemctl stop acvs`
3. Back up `MPC.settings` (`/media/az01-internal/Settings/*/MPC.settings`).
4. Inside `<VALUE name="pluginList-arm"><KNOWNPLUGINS>` add the line from `plugin.xml`
   (create the `pluginList-arm` value just before `</PROPERTIES>` if it doesn't exist).
5. `systemctl start acvs`. If MPC shows default settings, restore your backup (the XML was malformed).

## Troubleshooting
- Plugin doesn't appear: it is not in the list until MPC restarts; check `grep gluebus /media/az01-internal/Settings/*/MPC.settings`.
- Appears under a different category: the entry in plugin.xml says `category="Effect" isInstrument="0"`.
- MPC crashes on load: run `uninstall.sh`, or restore the `MPC.settings.bak-gluebus-*` backup and delete `/sdcard/vst/gluebus.so`.
- Skin doesn't show (plain parameter list instead): check `/sdcard/Synths` is in MPC's SynthContentLocations; a skin-only
  change needs no restart, just remove and re-insert the plugin.
