// GlueBus - console-style channel strip (filters, 4-band EQ, gate/expander, G-style bus compressor)
// as a dependency-free VST2 for Akai MPC OS (Gen1, 32-bit ARM). Needs only libc/libm
// (linked with the C driver: no libstdc++ at all, so nothing newer than the JV-880 needs). No GUI: MPC draws the skin in /sdcard/Synths.
#include "vst2.h"
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>

#define GB_EXPORT extern "C" __attribute__((visibility("default")))

namespace
{
// Indices 0-16 are unchanged from GlueBus 1.0 (skin + Q-Links bind to these numbers).
enum ParamId
{
    P_THRESH, P_RATIO, P_ATTACK, P_RELEASE, P_MAKEUP, P_AUTOMU, P_MIX, P_HPF, P_LINK, P_DET,
    P_MODE, P_KNEE, P_DRIVE, P_IN, P_OUT, P_GR, P_BYPASS,
    // channel strip
    P_FHPF, P_FLPF, P_LFG, P_LFF, P_LMG, P_LMF, P_LMQ, P_HMG, P_HMF, P_HMQ, P_HFG, P_HFF,
    P_EQON, P_EQPOS, P_GTHR, P_GRANGE, P_GREL, P_GMODE, P_GON, P_CON,
    P_COUNT
};
enum Kind { K_FLOAT, K_CHOICE, K_BOOL, K_LOG };
enum Fmt  { F_NUM, F_HZ, F_HPF, F_LPF, F_SEC };

const char* const kRatioNames[]  { "2:1", "4:1", "10:1" };
const char* const kAttackNames[] { "0.1 ms", "0.3 ms", "1 ms", "3 ms", "10 ms", "30 ms" };
const char* const kReleaseNames[]{ "0.1 s", "0.3 s", "0.6 s", "1.2 s", "Auto" };
const char* const kHpfNames[]    { "Off", "30 Hz", "60 Hz", "90 Hz", "120 Hz" };
const char* const kDetNames[]    { "Peak", "RMS" };
const char* const kModeNames[]   { "Stereo", "Mid/Side" };
const char* const kEqPosNames[]  { "Pre Dyn", "Post Dyn" };
const char* const kGModeNames[]  { "Expand", "Gate" };

const float kRatios[]   { 2.f, 4.f, 10.f };
const float kAttackMs[] { 0.1f, 0.3f, 1.f, 3.f, 10.f, 30.f };
const float kReleaseS[] { 0.1f, 0.3f, 0.6f, 1.2f, 0.f };
const float kHpfHz[]    { 0.f, 30.f, 60.f, 90.f, 120.f };

constexpr float kHpfOff = 16.f, kLpfOff = 22000.f;   // end stops of the filter knobs = filter off

struct ParamDef
{
    const char* name; const char* unit; Kind kind;
    float lo, hi, step, def;
    const char* const* choices; int n; Fmt fmt; const char* numFmt;
};

#define CH(names) names, (int) (sizeof (names) / sizeof (names[0]))
const ParamDef kParams[P_COUNT] =
{
    { "Threshold",  "dB", K_FLOAT,  -30.f,  6.f, 0.1f, -12.f, nullptr, 0, F_NUM, "%.1f" },
    { "Ratio",      "",   K_CHOICE,   0.f,  2.f, 1.f,   1.f,  CH (kRatioNames),   F_NUM, "" },
    { "Attack",     "",   K_CHOICE,   0.f,  5.f, 1.f,   2.f,  CH (kAttackNames),  F_NUM, "" },
    { "Release",    "",   K_CHOICE,   0.f,  4.f, 1.f,   4.f,  CH (kReleaseNames), F_NUM, "" },
    { "Makeup",     "dB", K_FLOAT,    0.f, 20.f, 0.1f,  0.f,  nullptr, 0, F_NUM, "%.1f" },
    { "Auto Makeup","",   K_BOOL,     0.f,  1.f, 1.f,   0.f,  nullptr, 0, F_NUM, "" },
    { "Mix",        "%",  K_FLOAT,    0.f,100.f, 1.f, 100.f,  nullptr, 0, F_NUM, "%.0f" },
    { "SC HPF",     "",   K_CHOICE,   0.f,  4.f, 1.f,   2.f,  CH (kHpfNames),     F_NUM, "" },
    { "Stereo Link","%",  K_FLOAT,    0.f,100.f, 1.f, 100.f,  nullptr, 0, F_NUM, "%.0f" },
    { "Detector",   "",   K_CHOICE,   0.f,  1.f, 1.f,   0.f,  CH (kDetNames),     F_NUM, "" },
    { "Mode",       "",   K_CHOICE,   0.f,  1.f, 1.f,   0.f,  CH (kModeNames),    F_NUM, "" },
    { "Knee",       "dB", K_FLOAT,    0.f, 12.f, 0.1f,  6.f,  nullptr, 0, F_NUM, "%.1f" },
    { "VCA Drive",  "%",  K_FLOAT,    0.f,100.f, 1.f,   0.f,  nullptr, 0, F_NUM, "%.0f" },
    { "Input Trim", "dB", K_FLOAT,  -12.f, 12.f, 0.1f,  0.f,  nullptr, 0, F_NUM, "%.1f" },
    { "Output Trim","dB", K_FLOAT,  -12.f, 12.f, 0.1f,  0.f,  nullptr, 0, F_NUM, "%.1f" },
    { "GR Meter",   "dB", K_FLOAT,    0.f, 30.f, 0.01f, 0.f,  nullptr, 0, F_NUM, "%.1f" },   // read-only
    { "Bypass",     "",   K_BOOL,     0.f,  1.f, 1.f,   0.f,  nullptr, 0, F_NUM, "" },
    { "HP Filter",  "",   K_LOG,   kHpfOff, 400.f, 0.f, kHpfOff, nullptr, 0, F_HPF, "" },
    { "LP Filter",  "",   K_LOG,   1000.f, kLpfOff, 0.f, kLpfOff, nullptr, 0, F_LPF, "" },
    { "LF Gain",    "dB", K_FLOAT,  -15.f, 15.f, 0.1f,  0.f,  nullptr, 0, F_NUM, "%+.1f" },
    { "LF Freq",    "",   K_LOG,     30.f, 450.f, 0.f, 100.f, nullptr, 0, F_HZ, "" },
    { "LMF Gain",   "dB", K_FLOAT,  -15.f, 15.f, 0.1f,  0.f,  nullptr, 0, F_NUM, "%+.1f" },
    { "LMF Freq",   "",   K_LOG,    200.f, 2500.f, 0.f, 600.f, nullptr, 0, F_HZ, "" },
    { "LMF Q",      "",   K_FLOAT,    0.5f, 4.f, 0.01f, 1.f,  nullptr, 0, F_NUM, "%.2f" },
    { "HMF Gain",   "dB", K_FLOAT,  -15.f, 15.f, 0.1f,  0.f,  nullptr, 0, F_NUM, "%+.1f" },
    { "HMF Freq",   "",   K_LOG,    600.f, 7000.f, 0.f, 2500.f, nullptr, 0, F_HZ, "" },
    { "HMF Q",      "",   K_FLOAT,    0.5f, 4.f, 0.01f, 1.f,  nullptr, 0, F_NUM, "%.2f" },
    { "HF Gain",    "dB", K_FLOAT,  -15.f, 15.f, 0.1f,  0.f,  nullptr, 0, F_NUM, "%+.1f" },
    { "HF Freq",    "",   K_LOG,   1500.f, 16000.f, 0.f, 8000.f, nullptr, 0, F_HZ, "" },
    { "EQ In",      "",   K_BOOL,     0.f,  1.f, 1.f,   1.f,  nullptr, 0, F_NUM, "" },
    { "EQ Position","",   K_CHOICE,   0.f,  1.f, 1.f,   0.f,  CH (kEqPosNames),   F_NUM, "" },
    { "Gate Thresh","dB", K_FLOAT,  -80.f,  0.f, 0.1f,-50.f,  nullptr, 0, F_NUM, "%.1f" },
    { "Gate Range", "dB", K_FLOAT,    0.f, 40.f, 0.1f, 20.f,  nullptr, 0, F_NUM, "%.1f" },
    { "Gate Release","",  K_LOG,     0.05f, 4.f, 0.f,  0.3f,  nullptr, 0, F_SEC, "" },
    { "Gate Mode",  "",   K_CHOICE,   0.f,  1.f, 1.f,   0.f,  CH (kGModeNames),   F_NUM, "" },
    { "Gate In",    "",   K_BOOL,     0.f,  1.f, 1.f,   0.f,  nullptr, 0, F_NUM, "" },
    { "Comp In",    "",   K_BOOL,     0.f,  1.f, 1.f,   1.f,  nullptr, 0, F_NUM, "" },
};

// ---- 20 factory presets: defaults + overrides ----
struct Ov { int id; float v; };
struct Preset { const char* name; const Ov* ov; int n; };
#define PRESET(sym, ...) const Ov sym[] = { __VA_ARGS__ };
#define ENTRY(name, sym) { name, sym, (int) (sizeof (sym) / sizeof (sym[0])) }

PRESET (pInit,       { P_THRESH, -12.f })
PRESET (pMixGlue,    { P_THRESH, -14.f }, { P_RATIO, 0 }, { P_ATTACK, 5 }, { P_RELEASE, 4 }, { P_AUTOMU, 1 }, { P_DRIVE, 10 },
                     { P_FHPF, 25.f }, { P_HFG, 1.0f }, { P_HFF, 12000.f })
PRESET (pMaster,     { P_THRESH, -8.f }, { P_RATIO, 0 }, { P_ATTACK, 4 }, { P_RELEASE, 4 }, { P_AUTOMU, 1 }, { P_DET, 1 }, { P_KNEE, 8 },
                     { P_FHPF, 20.f }, { P_LFG, 0.5f }, { P_LFF, 60.f }, { P_HFG, 0.8f }, { P_HFF, 14000.f }, { P_EQPOS, 1 })
PRESET (pDrumPunch,  { P_THRESH, -16.f }, { P_RATIO, 1 }, { P_ATTACK, 4 }, { P_RELEASE, 1 }, { P_AUTOMU, 1 }, { P_DRIVE, 25 },
                     { P_LFG, 2.5f }, { P_LFF, 70.f }, { P_LMG, -2.f }, { P_LMF, 400.f }, { P_LMQ, 1.2f }, { P_HMG, 1.5f }, { P_HMF, 4000.f })
PRESET (pDrumSmash,  { P_THRESH, -22.f }, { P_RATIO, 2 }, { P_ATTACK, 3 }, { P_RELEASE, 0 }, { P_AUTOMU, 1 }, { P_HPF, 3 }, { P_KNEE, 4 },
                     { P_DRIVE, 40 }, { P_LMG, -3.f }, { P_LMF, 350.f }, { P_HFG, 2.f }, { P_HFF, 9000.f })
PRESET (pParallel,   { P_THRESH, -24.f }, { P_RATIO, 2 }, { P_ATTACK, 2 }, { P_RELEASE, 1 }, { P_AUTOMU, 1 }, { P_MIX, 40 }, { P_KNEE, 3 },
                     { P_DRIVE, 35 })
PRESET (pKick,       { P_THRESH, -14.f }, { P_RATIO, 1 }, { P_ATTACK, 4 }, { P_RELEASE, 1 }, { P_AUTOMU, 1 }, { P_HPF, 0 },
                     { P_FHPF, 30.f }, { P_LFG, 3.f }, { P_LFF, 60.f }, { P_LMG, -4.f }, { P_LMF, 350.f }, { P_LMQ, 1.5f },
                     { P_HMG, 3.f }, { P_HMF, 3500.f }, { P_HMQ, 1.5f }, { P_GON, 1 }, { P_GTHR, -35.f }, { P_GRANGE, 18.f },
                     { P_GREL, 0.15f }, { P_GMODE, 1 })
PRESET (pSnare,      { P_THRESH, -16.f }, { P_RATIO, 1 }, { P_ATTACK, 4 }, { P_RELEASE, 1 }, { P_AUTOMU, 1 }, { P_DRIVE, 20 },
                     { P_FHPF, 80.f }, { P_LMG, 2.f }, { P_LMF, 220.f }, { P_HMG, -2.f }, { P_HMF, 900.f }, { P_HMQ, 2.f },
                     { P_HFG, 3.f }, { P_HFF, 8000.f }, { P_GON, 1 }, { P_GTHR, -30.f }, { P_GRANGE, 12.f }, { P_GREL, 0.2f })
PRESET (pHats,       { P_THRESH, -18.f }, { P_RATIO, 0 }, { P_ATTACK, 2 }, { P_RELEASE, 0 }, { P_AUTOMU, 1 }, { P_HPF, 4 },
                     { P_FHPF, 250.f }, { P_HMG, -3.f }, { P_HMF, 5000.f }, { P_HMQ, 2.5f }, { P_HFG, 1.5f }, { P_HFF, 12000.f })
PRESET (pRoom,       { P_THRESH, -26.f }, { P_RATIO, 2 }, { P_ATTACK, 1 }, { P_RELEASE, 0 }, { P_AUTOMU, 1 }, { P_DRIVE, 50 },
                     { P_MIX, 60 }, { P_KNEE, 2 }, { P_FHPF, 60.f }, { P_FLPF, 9000.f }, { P_LMG, 2.f }, { P_LMF, 800.f })
PRESET (pVocal,      { P_THRESH, -15.f }, { P_RATIO, 1 }, { P_ATTACK, 3 }, { P_RELEASE, 1 }, { P_AUTOMU, 1 }, { P_DET, 1 }, { P_KNEE, 8 },
                     { P_FHPF, 90.f }, { P_LMG, -2.f }, { P_LMF, 300.f }, { P_HMG, 2.f }, { P_HMF, 3000.f }, { P_HFG, 2.f },
                     { P_HFF, 10000.f }, { P_GON, 1 }, { P_GTHR, -55.f }, { P_GRANGE, 10.f }, { P_GREL, 0.4f })
PRESET (pVocalAir,   { P_THRESH, -12.f }, { P_RATIO, 0 }, { P_ATTACK, 3 }, { P_RELEASE, 4 }, { P_AUTOMU, 1 }, { P_DET, 1 }, { P_KNEE, 8 },
                     { P_FHPF, 100.f }, { P_HMG, -1.5f }, { P_HMF, 2500.f }, { P_HMQ, 2.f }, { P_HFG, 4.f }, { P_HFF, 12000.f },
                     { P_EQPOS, 1 })
PRESET (pBgVox,      { P_THRESH, -18.f }, { P_RATIO, 1 }, { P_ATTACK, 3 }, { P_RELEASE, 4 }, { P_AUTOMU, 1 }, { P_DET, 1 }, { P_LINK, 60 },
                     { P_FHPF, 150.f }, { P_LMG, -3.f }, { P_LMF, 400.f }, { P_HFG, 2.f }, { P_HFF, 10000.f })
PRESET (pBassDI,     { P_THRESH, -16.f }, { P_RATIO, 1 }, { P_ATTACK, 5 }, { P_RELEASE, 2 }, { P_AUTOMU, 1 }, { P_DET, 1 }, { P_HPF, 0 },
                     { P_DRIVE, 20 }, { P_FHPF, 30.f }, { P_LFG, 2.f }, { P_LFF, 80.f }, { P_LMG, -2.f }, { P_LMF, 250.f },
                     { P_HMG, 2.f }, { P_HMF, 1200.f }, { P_FLPF, 8000.f })
PRESET (p808,        { P_THRESH, -14.f }, { P_RATIO, 1 }, { P_ATTACK, 5 }, { P_RELEASE, 2 }, { P_AUTOMU, 1 }, { P_DET, 1 }, { P_HPF, 0 },
                     { P_DRIVE, 30 }, { P_FHPF, 25.f }, { P_LFG, 1.5f }, { P_LFF, 50.f }, { P_LMG, -3.f }, { P_LMF, 300.f },
                     { P_FLPF, 5000.f })
PRESET (pAcoustic,   { P_THRESH, -14.f }, { P_RATIO, 0 }, { P_ATTACK, 3 }, { P_RELEASE, 4 }, { P_AUTOMU, 1 }, { P_DET, 1 },
                     { P_FHPF, 80.f }, { P_LMG, -3.f }, { P_LMF, 250.f }, { P_LMQ, 1.2f }, { P_HFG, 2.5f }, { P_HFF, 10000.f })
PRESET (pElecGtr,    { P_THRESH, -13.f }, { P_RATIO, 0 }, { P_ATTACK, 4 }, { P_RELEASE, 4 }, { P_AUTOMU, 1 }, { P_LINK, 80 },
                     { P_DRIVE, 15 }, { P_FHPF, 90.f }, { P_FLPF, 12000.f }, { P_LMG, -2.f }, { P_LMF, 500.f }, { P_HMG, 2.f },
                     { P_HMF, 2500.f })
PRESET (pKeys,       { P_THRESH, -12.f }, { P_RATIO, 0 }, { P_ATTACK, 5 }, { P_RELEASE, 4 }, { P_AUTOMU, 1 }, { P_DET, 1 }, { P_DRIVE, 25 },
                     { P_LFG, 1.5f }, { P_LFF, 150.f }, { P_HMG, -1.5f }, { P_HMF, 3000.f }, { P_FLPF, 14000.f })
PRESET (pLoFi,       { P_THRESH, -28.f }, { P_RATIO, 2 }, { P_ATTACK, 0 }, { P_RELEASE, 0 }, { P_AUTOMU, 1 }, { P_HPF, 3 }, { P_KNEE, 0 },
                     { P_DRIVE, 80 }, { P_MIX, 70 }, { P_OUT, -2.f }, { P_FHPF, 150.f }, { P_FLPF, 4000.f }, { P_LMG, 3.f },
                     { P_LMF, 1000.f }, { P_LMQ, 0.7f })
PRESET (pPump,       { P_THRESH, -20.f }, { P_RATIO, 1 }, { P_ATTACK, 1 }, { P_RELEASE, 0 }, { P_AUTOMU, 1 }, { P_KNEE, 2 }, { P_DRIVE, 20 })

const Preset kPresets[] =
{
    ENTRY ("Init", pInit),                ENTRY ("Mix Bus Glue", pMixGlue),     ENTRY ("Master Gentle", pMaster),
    ENTRY ("Drum Bus Punch", pDrumPunch), ENTRY ("Drum Bus Smash", pDrumSmash), ENTRY ("Parallel Thump", pParallel),
    ENTRY ("Kick Tight", pKick),          ENTRY ("Snare Crack", pSnare),        ENTRY ("Hi-Hat Tame", pHats),
    ENTRY ("Room Squash", pRoom),         ENTRY ("Vocal Lead", pVocal),         ENTRY ("Vocal Air", pVocalAir),
    ENTRY ("Backing Vox", pBgVox),        ENTRY ("Bass DI", pBassDI),           ENTRY ("808 Control", p808),
    ENTRY ("Acoustic Gtr", pAcoustic),    ENTRY ("Electric Gtr", pElecGtr),     ENTRY ("Keys Warmth", pKeys),
    ENTRY ("Lo-Fi Chop", pLoFi),          ENTRY ("Pump It", pPump),
};
constexpr int kNumPresets = (int) (sizeof (kPresets) / sizeof (kPresets[0]));

inline float clampf (float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
inline float flush (float x) { return std::fabs (x) < 1e-20f ? 0.f : x; }
inline float toDb (float lin) { return 6.0206f * std::log2 (lin + 1e-9f); }
inline float fromDb (float db) { return std::exp2 (db * 0.16609640f); }
inline float softSat (float x)   // tanh-like rational approximation, exact +-1 beyond |x|=3
{
    if (x >= 3.f) return 1.f;
    if (x <= -3.f) return -1.f;
    const float x2 = x * x;
    return x * (27.f + x2) / (27.f + 9.f * x2);
}

float toPlain (const ParamDef& d, float norm)
{
    norm = clampf (norm, 0.f, 1.f);
    if (d.kind == K_BOOL) return norm >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return std::floor (norm * (float) (d.n - 1) + 0.5f);
    if (d.kind == K_LOG) return d.lo * std::pow (d.hi / d.lo, norm);
    float v = d.lo + norm * (d.hi - d.lo);
    if (d.step > 0.f) v = d.lo + std::floor ((v - d.lo) / d.step + 0.5f) * d.step;
    return clampf (v, d.lo, d.hi);
}
float toNorm (const ParamDef& d, float plain)
{
    if (d.kind == K_BOOL) return plain >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return d.n > 1 ? clampf (plain / (float) (d.n - 1), 0.f, 1.f) : 0.f;
    if (d.kind == K_LOG) return clampf (std::log (clampf (plain, d.lo, d.hi) / d.lo) / std::log (d.hi / d.lo), 0.f, 1.f);
    return clampf ((plain - d.lo) / (d.hi - d.lo), 0.f, 1.f);
}
void copyStr (void* dst, const char* src, size_t max = 24)
{
    if (dst == nullptr) return;
    std::strncpy ((char*) dst, src, max - 1);
    ((char*) dst)[max - 1] = 0;
}
void fmtHz (char* out, size_t max, float hz)
{
    if (hz < 1000.f) std::snprintf (out, max, "%.0f Hz", (double) hz);
    else             std::snprintf (out, max, "%.1f kHz", (double) (hz * 0.001f));
}

// ---- RBJ biquad, transposed direct form II, stereo ----
struct Biquad
{
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
    float z1[2] {}, z2[2] {};
    bool active = false;

    inline float run (int c, float x)
    {
        const float y = b0 * x + z1[c];
        z1[c] = flush (b1 * x - a1 * y + z2[c]);
        z2[c] = flush (b2 * x - a2 * y);
        return y;
    }
    void clear() { z1[0] = z1[1] = z2[0] = z2[1] = 0.f; }
    void set (double nb0, double nb1, double nb2, double a0, double na1, double na2)
    {
        b0 = (float) (nb0 / a0); b1 = (float) (nb1 / a0); b2 = (float) (nb2 / a0);
        a1 = (float) (na1 / a0); a2 = (float) (na2 / a0);
    }
    enum Type { LP, HP, PEAK, LSHELF, HSHELF };
    void design (Type t, double fs, double f, double q, double gainDb)
    {
        f = f < 10.0 ? 10.0 : (f > 0.45 * fs ? 0.45 * fs : f);
        const double w = 2.0 * 3.14159265358979 * f / fs, cw = std::cos (w), sw = std::sin (w);
        const double A = std::pow (10.0, gainDb / 40.0);
        switch (t)
        {
            case LP: { const double al = sw / (2 * q); set ((1 - cw) / 2, 1 - cw, (1 - cw) / 2, 1 + al, -2 * cw, 1 - al); break; }
            case HP: { const double al = sw / (2 * q); set ((1 + cw) / 2, -(1 + cw), (1 + cw) / 2, 1 + al, -2 * cw, 1 - al); break; }
            case PEAK: { const double al = sw / (2 * q); set (1 + al * A, -2 * cw, 1 - al * A, 1 + al / A, -2 * cw, 1 - al / A); break; }
            case LSHELF:
            {
                const double al = sw / 2 * std::sqrt (2.0), s = 2 * std::sqrt (A) * al;
                set (A * ((A + 1) - (A - 1) * cw + s), 2 * A * ((A - 1) - (A + 1) * cw), A * ((A + 1) - (A - 1) * cw - s),
                     (A + 1) + (A - 1) * cw + s, -2 * ((A - 1) + (A + 1) * cw), (A + 1) + (A - 1) * cw - s);
                break;
            }
            case HSHELF:
            {
                const double al = sw / 2 * std::sqrt (2.0), s = 2 * std::sqrt (A) * al;
                set (A * ((A + 1) + (A - 1) * cw + s), -2 * A * ((A - 1) + (A + 1) * cw), A * ((A + 1) + (A - 1) * cw - s),
                     (A + 1) - (A - 1) * cw + s, 2 * ((A - 1) - (A + 1) * cw), (A + 1) - (A - 1) * cw - s);
                break;
            }
        }
    }
};

struct Plugin
{
    AEffect fx {};
    audioMasterCallback master = nullptr;

    std::atomic<float> v[P_COUNT];     // plain (un-normalised) parameter values
    std::atomic<float> meter { 0.f };
    int program = 0;
    float sr = 44100.f;

    // DSP state (audio thread only)
    float hp1[2] {}, hp2[2] {}, msq[2] {}, env[2][2] {};
    float sMake = 0.f, sMix = 1.f, sIn = 1.f, sOut = 1.f, sDrive = 0.f, meterHold = 0.f;
    bool snap = true;
    int meterCountdown = 0;  float meterSent = -1.f;       // live GR meter updates to the host

    enum { F_HP1, F_HP2, F_LP1, F_LP2, F_LF, F_LM, F_HM, F_HF, NF };
    Biquad filt[NF];
    float eqKey[12] {};   bool eqDirty = true;           // last designed values
    float gDet = 0.f, gGainDb = 0.f; int gHold = 0; bool gOpen = false;

    Plugin() { for (int i = 0; i < P_COUNT; ++i) v[i].store (kParams[i].def); }

    void applyPreset (int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        program = i;
        for (int p = 0; p < P_COUNT; ++p) if (p != P_GR && p != P_BYPASS) v[p].store (kParams[p].def);
        for (int k = 0; k < kPresets[i].n; ++k) v[kPresets[i].ov[k].id].store (kPresets[i].ov[k].v);
    }

    // Tell the host every parameter changed (after a preset load), then ask it to refresh its display.
    void notifyHostAll()
    {
        if (master == nullptr) return;
        for (int i = 0; i < P_COUNT; ++i)
        {
            if (i == P_GR) continue;
            const float norm = i == P_BYPASS ? (v[i].load() > 0.5f ? 1.f : 0.f) : toNorm (kParams[i], v[i].load());
            master (&fx, 0 /* audioMasterAutomate */, i, 0, nullptr, norm);
        }
        master (&fx, 42 /* audioMasterUpdateDisplay */, 0, 0, nullptr, 0.f);
    }

    // Push the GR meter to the host ~15x per second, only when it moved (MPC redraws a control only when told).
    // GR is read-only and not automatable, so hosts don't record it as automation.
    void sendMeter (int n)
    {
        if (master == nullptr) return;
        meterCountdown -= n;
        if (meterCountdown > 0) return;
        meterCountdown = (int) (sr / 15.f);
        const float m = meter.load();
        if (std::fabs (m - meterSent) < 0.25f && ! (m == 0.f && meterSent != 0.f)) return;
        meterSent = m;
        master (&fx, 0 /* audioMasterAutomate */, P_GR, 0, nullptr, clampf (m / 30.f, 0.f, 1.f));
    }

    void reset()
    {
        for (int c = 0; c < 2; ++c) { hp1[c] = hp2[c] = msq[c] = 0.f; env[c][0] = env[c][1] = 0.f; }
        for (auto& f : filt) f.clear();
        gDet = 0.f; gGainDb = 0.f; gHold = 0; gOpen = false;
        meterHold = 0.f; meter.store (0.f); snap = true; eqDirty = true;
        meterSent = -1.f; meterCountdown = 0;   // force a fresh meter update after a reset
    }

    void display (int idx, char* out, size_t max) const
    {
        const ParamDef& d = kParams[idx];
        const float p = v[idx].load();
        if (idx == P_GR) { std::snprintf (out, max, "%.1f", (double) meter.load()); return; }
        if (d.kind == K_CHOICE) { std::snprintf (out, max, "%s", d.choices[(int) clampf (p, 0.f, (float) (d.n - 1))]); return; }
        if (d.kind == K_BOOL)   { std::snprintf (out, max, "%s", p >= 0.5f ? "On" : "Off"); return; }
        switch (d.fmt)
        {
            case F_HPF: if (p <= kHpfOff * 1.02f) std::snprintf (out, max, "Off"); else fmtHz (out, max, p); return;
            case F_LPF: if (p >= kLpfOff * 0.98f) std::snprintf (out, max, "Off"); else fmtHz (out, max, p); return;
            case F_HZ:  fmtHz (out, max, p); return;
            case F_SEC: if (p < 1.f) std::snprintf (out, max, "%.0f ms", (double) (p * 1000.f)); else std::snprintf (out, max, "%.2f s", (double) p); return;
            default:    std::snprintf (out, max, d.numFmt, (double) p); return;
        }
    }

    void designEq()
    {
        const int ids[12] { P_FHPF, P_FLPF, P_LFG, P_LFF, P_LMG, P_LMF, P_LMQ, P_HMG, P_HMF, P_HMQ, P_HFG, P_HFF };
        bool changed = eqDirty;
        float cur[12];
        for (int i = 0; i < 12; ++i) { cur[i] = v[ids[i]].load(); if (cur[i] != eqKey[i]) changed = true; }
        if (! changed) return;
        for (int i = 0; i < 12; ++i) eqKey[i] = cur[i];
        eqDirty = false;
        const double fs = sr;
        // 24 dB/oct Butterworth high/low-pass (two cascaded 2nd-order sections)
        const bool hpOn = cur[0] > kHpfOff * 1.02f, lpOn = cur[1] < kLpfOff * 0.98f;
        auto enable = [] (Biquad& b, bool on) { if (on && ! b.active) b.clear(); b.active = on; };
        enable (filt[F_HP1], hpOn); enable (filt[F_HP2], hpOn);
        enable (filt[F_LP1], lpOn); enable (filt[F_LP2], lpOn);
        if (hpOn) { filt[F_HP1].design (Biquad::HP, fs, cur[0], 0.5412, 0); filt[F_HP2].design (Biquad::HP, fs, cur[0], 1.3066, 0); }
        if (lpOn) { filt[F_LP1].design (Biquad::LP, fs, cur[1], 0.5412, 0); filt[F_LP2].design (Biquad::LP, fs, cur[1], 1.3066, 0); }
        auto band = [&] (int f, Biquad::Type t, float g, float hz, float q)
        {
            const bool on = std::fabs (g) > 0.05f;   // flat band = skipped (bit-transparent)
            enable (filt[f], on);
            if (on) filt[f].design (t, fs, hz, q, g);
        };
        band (F_LF, Biquad::LSHELF, cur[2], cur[3], 0.707f);
        band (F_LM, Biquad::PEAK,   cur[4], cur[5], cur[6]);
        band (F_HM, Biquad::PEAK,   cur[7], cur[8], cur[9]);
        band (F_HF, Biquad::HSHELF, cur[10], cur[11], 0.707f);
    }

    inline void runFilters (float& l, float& r, int from, int to)
    {
        for (int f = from; f < to; ++f)
            if (filt[f].active) { l = filt[f].run (0, l); r = filt[f].run (1, r); }
    }

    void process (const float* inL, const float* inR, float* outL, float* outR, int n)
    {
        if (v[P_BYPASS].load() > 0.5f)
        {
            if (outL != inL) std::memcpy (outL, inL, sizeof (float) * (size_t) n);
            if (outR != inR) std::memcpy (outR, inR, sizeof (float) * (size_t) n);
            meter.store (0.f); meterHold = 0.f; snap = true;
            sendMeter (n);
            return;
        }
        designEq();

        // ---- compressor settings ----
        const bool  compOn = v[P_CON].load() > 0.5f;
        const float thresh = v[P_THRESH].load();
        const float ratio  = kRatios[(int) v[P_RATIO].load()];
        const float atkMs  = kAttackMs[(int) v[P_ATTACK].load()];
        const int   relIdx = (int) v[P_RELEASE].load();
        const bool  autoRel = relIdx == 4;
        const float relS   = kReleaseS[relIdx];
        const bool  autoMU = v[P_AUTOMU].load() > 0.5f;
        const float hpfHz  = kHpfHz[(int) v[P_HPF].load()];
        const bool  useRms = v[P_DET].load() > 0.5f;
        const bool  midSide = v[P_MODE].load() > 0.5f;
        const float link   = v[P_LINK].load() * 0.01f;
        const float knee   = v[P_KNEE].load();
        const float slope  = 1.f - 1.f / ratio;

        // ---- channel-strip settings ----
        const bool eqOn   = v[P_EQON].load() > 0.5f;
        const bool eqPost = v[P_EQPOS].load() > 0.5f;
        const bool gateOn = v[P_GON].load() > 0.5f;
        const bool gateHard = v[P_GMODE].load() > 0.5f;
        const float gThr  = v[P_GTHR].load();
        const float gRange = v[P_GRANGE].load();
        const float gRelC = std::exp (-1.f / (v[P_GREL].load() * sr));
        const float gAtkC = std::exp (-1.f / (0.0005f * sr));
        const float gDetC = std::exp (-1.f / (0.05f * sr));
        const int   gHoldN = (int) (0.02f * sr);

        const float autoDb = autoMU ? std::fmax (0.f, -thresh * slope * 0.5f) : 0.f;
        const float tMake = v[P_MAKEUP].load() + autoDb;
        const float tMix  = v[P_MIX].load() * 0.01f;
        const float tIn   = fromDb (v[P_IN].load());
        const float tOut  = fromDb (v[P_OUT].load());
        const float tDrv  = v[P_DRIVE].load() * 0.01f;
        if (snap) { sMake = tMake; sMix = tMix; sIn = tIn; sOut = tOut; sDrive = tDrv; snap = false; }

        const float sm     = 1.f - std::exp (-1.f / (0.02f * sr));
        const float atk    = std::exp (-1.f / (0.001f * atkMs * sr));
        const float relF   = std::exp (-1.f / ((autoRel ? 0.15f : relS) * sr));
        const float relSl  = std::exp (-1.f / ((autoRel ? 1.6f  : relS) * sr));
        const float hpfA   = hpfHz > 0.f ? std::exp (-6.2831853f * hpfHz / sr) : 0.f;
        const float rmsC   = std::exp (-1.f / (0.01f * sr));

        float blockGR = 0.f;
        for (int i = 0; i < n; ++i)
        {
            sMake += (tMake - sMake) * sm;  sMix += (tMix - sMix) * sm;  sIn += (tIn - sIn) * sm;
            sOut += (tOut - sOut) * sm;     sDrive += (tDrv - sDrive) * sm;

            float L = inL[i] * sIn, R = inR[i] * sIn;

            runFilters (L, R, F_HP1, F_LP2 + 1);                   // HP/LP filters always first
            if (eqOn && ! eqPost) runFilters (L, R, F_LF, NF);

            if (gateOn)   // stereo-linked gate / 2:1 downward expander
            {
                const float lev = std::fmax (std::fabs (L), std::fabs (R));
                gDet = flush (lev > gDet ? lev : gDet * gDetC);
                const float dDb = toDb (gDet);
                float target;
                if (gateHard)
                {
                    if (dDb > gThr) { gOpen = true; gHold = gHoldN; }
                    else if (dDb < gThr - 4.f) { if (gHold > 0) --gHold; else gOpen = false; }   // 4 dB hysteresis + hold
                    target = gOpen ? 0.f : -gRange;
                }
                else target = dDb < gThr ? std::fmax (-gRange, dDb - gThr) : 0.f;
                gGainDb = target > gGainDb ? gAtkC * gGainDb + (1.f - gAtkC) * target
                                           : gRelC * gGainDb + (1.f - gRelC) * target;
                const float g = fromDb (gGainDb);
                L *= g; R *= g;
            }

            if (compOn)
            {
                const float dry[2] { L, R };
                float sig[2] { L, R };
                if (midSide) { sig[0] = (L + R) * 0.5f; sig[1] = (L - R) * 0.5f; }

                float lvlDb[2];
                for (int c = 0; c < 2; ++c)
                {
                    float s = sig[c];
                    if (hpfA > 0.f)   // 12 dB/oct sidechain high-pass
                    {
                        hp1[c] = flush (hpfA * hp1[c] + (1.f - hpfA) * s);  s -= hp1[c];
                        hp2[c] = flush (hpfA * hp2[c] + (1.f - hpfA) * s);  s -= hp2[c];
                    }
                    float lev;
                    if (useRms) { msq[c] = flush (rmsC * msq[c] + (1.f - rmsC) * s * s); lev = std::sqrt (msq[c]) * 1.4142f; }
                    else        lev = std::fabs (s);
                    lvlDb[c] = std::fmax (toDb (lev), -100.f);
                }
                const float mx = std::fmax (lvlDb[0], lvlDb[1]);
                float out[2];
                for (int c = 0; c < 2; ++c)
                {
                    const float over = (lvlDb[c] + link * (mx - lvlDb[c])) - thresh;
                    float target;
                    if (2.f * over <= -knee) target = 0.f;
                    else if (knee > 0.01f && 2.f * over < knee) { const float x = over + knee * 0.5f; target = slope * x * x / (2.f * knee); }
                    else target = slope * over;
                    float& f = env[c][0];
                    float& s = env[c][1];
                    f = flush (target > f ? atk * f + (1.f - atk) * target : relF  * f + (1.f - relF)  * target);
                    s = flush (target > s ? atk * s + (1.f - atk) * target : relSl * s + (1.f - relSl) * target);
                    const float gr = autoRel ? 0.5f * (f + s) : f;
                    if (gr > blockGR) blockGR = gr;
                    out[c] = sig[c] * fromDb (sMake - gr);
                }
                if (sDrive > 0.001f)   // VCA-style soft saturation
                {
                    const float k = 0.05f + 1.5f * sDrive;
                    out[0] = softSat (k * out[0]) / k;
                    out[1] = softSat (k * out[1]) / k;
                }
                float wetL = out[0], wetR = out[1];
                if (midSide) { wetL = out[0] + out[1]; wetR = out[0] - out[1]; }
                L = dry[0] + sMix * (wetL - dry[0]);
                R = dry[1] + sMix * (wetR - dry[1]);
            }

            if (eqOn && eqPost) runFilters (L, R, F_LF, NF);
            outL[i] = L * sOut;
            outR[i] = R * sOut;
        }
        meterHold = std::fmax (blockGR, meterHold * std::exp (-(float) n / (0.15f * sr)));
        meter.store (clampf (meterHold, 0.f, 30.f));
        sendMeter (n);
    }
};

// ---- VST2 entry points ----
void processReplacing (AEffect* e, float** in, float** out, int32_t n)
{
    static_cast<Plugin*> (e->object)->process (in[0], in[1], out[0], out[1], n);
}

void processAccumulating (AEffect* e, float** in, float** out, int32_t n)   // legacy VST2 process()
{
    float tl[256], tr[256];
    Plugin* p = static_cast<Plugin*> (e->object);
    for (int32_t pos = 0; pos < n; pos += 256)
    {
        const int32_t m = (n - pos) < 256 ? (n - pos) : 256;
        p->process (in[0] + pos, in[1] + pos, tl, tr, m);
        for (int32_t i = 0; i < m; ++i) { out[0][pos + i] += tl[i]; out[1][pos + i] += tr[i]; }
    }
}

void setParameter (AEffect* e, int32_t i, float norm)
{
    if (i < 0 || i >= P_COUNT || i == P_GR) return;
    static_cast<Plugin*> (e->object)->v[i].store (toPlain (kParams[i], norm));
}

float getParameter (AEffect* e, int32_t i)
{
    if (i < 0 || i >= P_COUNT) return 0.f;
    Plugin* p = static_cast<Plugin*> (e->object);
    if (i == P_GR) return clampf (p->meter.load() / 30.f, 0.f, 1.f);
    return toNorm (kParams[i], p->v[i].load());
}

intptr_t dispatcher (AEffect* e, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    switch (op)
    {
        case effClose:            p->~Plugin(); std::free (p); return 0;      // AEffect is embedded in Plugin
        case effSetProgram:       p->applyPreset ((int) val); p->notifyHostAll(); return 0;
        case effGetProgram:       return p->program;
        case effGetProgramName:   copyStr (ptr, kPresets[p->program].name); return 0;
        case effGetProgramNameIndexed:
            if (idx < 0 || idx >= kNumPresets) return 0;
            copyStr (ptr, kPresets[idx].name); return 1;
        case effGetParamName:     if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].name); return 0;
        case effGetParamLabel:    if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].unit); return 0;
        case effGetParamDisplay:
            if (idx >= 0 && idx < P_COUNT && ptr != nullptr) { char b[32]; p->display (idx, b, sizeof b); copyStr (ptr, b); }
            return 0;
        case effCanBeAutomated:   return (idx >= 0 && idx < P_COUNT && idx != P_GR) ? 1 : 0;
        case effSetSampleRate:    if (opt > 1000.f) { p->sr = opt; p->snap = true; p->eqDirty = true; } return 0;
        case effMainsChanged:     p->reset(); return 0;
        case effSetBypass:        p->v[P_BYPASS].store (val ? 1.f : 0.f); return 1;
        case effGetEffectName:
        case effGetProductString: copyStr (ptr, "GlueBus", 32); return 1;
        case effGetVendorString:  copyStr (ptr, "GlueBus", 32); return 1;
        case effGetVendorVersion: return 1100;
        case effGetPlugCategory:  return kPlugCategEffect;
        case effGetVstVersion:    return 2400;
        case effGetTailSize:      return 1;
        case effSetProcessPrecision: return val == 0 ? 1 : 0;      // 32-bit float only
        case effCanDo:
            if (ptr != nullptr && std::strcmp ((const char*) ptr, "bypass") == 0) return 1;
            return 0;
        default: return 0;
    }
}
} // namespace

GB_EXPORT AEffect* VSTPluginMain (audioMasterCallback master)
{
    void* mem = std::calloc (1, sizeof (Plugin));   // no operator new: keeps libstdc++ out of the link
    if (mem == nullptr) return nullptr;
    Plugin* p = new (mem) Plugin();
    p->master = master;
    p->applyPreset (0);
    AEffect& fx = p->fx;
    fx.magic = kEffectMagic;
    fx.dispatcher = dispatcher;
    fx.process = processAccumulating;
    fx.processReplacing = processReplacing;
    fx.setParameter = setParameter;
    fx.getParameter = getParameter;
    fx.numPrograms = kNumPresets;
    fx.numParams = P_COUNT;
    fx.numInputs = 2;
    fx.numOutputs = 2;
    fx.flags = effFlagsCanReplacing;
    fx.ioRatio = 1.f;
    fx.object = p;
    fx.uniqueID = ('G' << 24) | ('l' << 16) | ('b' << 8) | 's';   // 'Glbs' = 0x476c6273
    fx.version = 1100;
    return &fx;
}
