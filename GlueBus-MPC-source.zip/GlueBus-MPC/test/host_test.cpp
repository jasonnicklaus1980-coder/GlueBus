// Offline VST2 host test: loads the .so, exercises the dispatcher, parameters, presets and audio.
#include "vst2.h"
#include <dlfcn.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static int fails = 0;
#define CHECK(cond, ...) do { if (!(cond)) { ++fails; std::printf("FAIL: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

static int automateCalls = 0, displayCalls = 0, meterCalls = 0; static float lastAutomate[64];
static intptr_t host(AEffect*, int32_t op, int32_t idx, intptr_t, void*, float opt) {
    if (op == 0) { ++automateCalls; if (idx >= 0 && idx < 64) lastAutomate[idx] = opt; if (idx == 15) ++meterCalls; }
    if (op == 42) ++displayCalls;
    return 2400;
}
static AEffect* fx;
static intptr_t D(int op, int idx = 0, intptr_t val = 0, void* p = nullptr, float opt = 0) { return fx->dispatcher(fx, op, idx, val, p, opt); }
static void setNorm(int i, float n) { fx->setParameter(fx, i, n); }
static float getNorm(int i) { return fx->getParameter(fx, i); }

static const int N = 44100;
static void makeSine(std::vector<float>& l, std::vector<float>& r, float peak, float hz = 1000.f, int n = N) {
    l.resize(n); r.resize(n);
    for (int i = 0; i < n; ++i) l[i] = r[i] = peak * std::sin(6.2831853f * hz * i / 44100.f);
}
static float peakOf(const std::vector<float>& v, int from) {
    float m = 0; for (size_t i = from; i < v.size(); ++i) m = std::fmax(m, std::fabs(v[i])); return m;
}
static float db(float x) { return 20.f * std::log10(x + 1e-12f); }
static float fromDbT(float d) { return std::pow(10.f, d / 20.f); }
static void proc(std::vector<float>& il, std::vector<float>& ir, std::vector<float>& ol, std::vector<float>& orr, int block = 512) {
    ol.assign(il.size(), 0); orr.assign(il.size(), 0);
    for (size_t pos = 0; pos < il.size(); pos += block) {
        int m = (int) std::fmin((double) block, (double)(il.size() - pos));
        float* in[2] = { &il[pos], &ir[pos] }; float* out[2] = { &ol[pos], &orr[pos] };
        fx->processReplacing(fx, in, out, m);
    }
}
static void select(int preset) { D(effSetProgram, 0, preset); }

int main(int argc, char** argv) {
    void* h = dlopen(argc > 1 ? argv[1] : "build/native/gluebus.so", RTLD_NOW);
    if (!h) { std::printf("dlopen: %s\n", dlerror()); return 2; }
    auto entry = (AEffect* (*)(audioMasterCallback)) dlsym(h, "VSTPluginMain");
    if (!entry) { std::printf("no VSTPluginMain\n"); return 2; }
    fx = entry(host);
    CHECK(fx && fx->magic == kEffectMagic, "magic");
    CHECK(fx->numInputs == 2 && fx->numOutputs == 2, "io");
    CHECK(fx->flags & effFlagsCanReplacing, "replacing flag");
    CHECK(fx->uniqueID == 0x476c6273, "uid %08x", fx->uniqueID);
    CHECK(fx->numParams == 37 && fx->numPrograms == 20, "counts %d/%d", fx->numParams, fx->numPrograms);
    CHECK(D(effGetPlugCategory) == kPlugCategEffect, "category");
    D(effOpen); D(effSetSampleRate, 0, 0, nullptr, 44100.f); D(effSetBlockSize, 0, 512); D(effMainsChanged, 0, 1);

    std::printf("Parameters:\n");
    for (int i = 0; i < fx->numParams; ++i) {
        char n[64] = {}, d[64] = {}, u[64] = {};
        D(effGetParamName, i, 0, n); D(effGetParamDisplay, i, 0, d); D(effGetParamLabel, i, 0, u);
        std::printf("  %2d %-13s %-9s %s\n", i, n, d, u);
        CHECK(std::strlen(n) > 0, "param %d name", i);
        // round trip: set -> get must be stable and within [0,1]
        if (i != 15) { setNorm(i, 0.37f); float a = getNorm(i); setNorm(i, a); CHECK(std::fabs(getNorm(i) - a) < 1e-6f, "param %d roundtrip", i); }
    }
    std::printf("Programs:\n");
    for (int i = 0; i < fx->numPrograms; ++i) { char n[64] = {}; D(effGetProgramNameIndexed, i, 0, n); std::printf("  %2d %s\n", i, n); CHECK(n[0], "preset name"); }
    automateCalls = displayCalls = 0; select(3);
    CHECK(automateCalls == 36 && displayCalls == 1, "preset change notifies host (%d automate, %d display)", automateCalls, displayCalls);
    CHECK(std::fabs(lastAutomate[0] - getNorm(0)) < 1e-6f && std::fabs(getNorm(0) - 14.f / 36.f) < 1e-3f,
          "notified threshold matches Drum Bus Punch (-16 dB)");
    select(0); CHECK(D(effGetProgram) == 0, "program 0");
    select(3); CHECK(D(effGetProgram) == 3, "program 3");

    std::vector<float> l, r, ol, orr;

    // 1) Init preset (thr -12, 4:1, 1ms, auto rel), 1 kHz @ -6 dBFS => steady GR ~ 0.75*(14-... ) computed with soft knee
    select(0); setNorm(4, 0.f);  // makeup 0
    makeSine(l, r, 0.5f);
    proc(l, r, ol, orr);
    float inDb = db(peakOf(l, N/2)), outDb = db(peakOf(ol, N/2));
    float gr = inDb - outDb; float meter = getNorm(15) * 30.f;
    std::printf("\nInit preset: in %.1f dB, out %.1f dB, GR %.2f dB, meter %.2f dB\n", inDb, outDb, gr, meter);
    // level ~-6 dB, thresh -12, over=6 => beyond knee(6): GR = 0.75*6 = 4.5 dB
    CHECK(std::fabs(gr - 4.5f) < 1.0f, "steady-state GR %.2f expected ~4.5", gr);
    CHECK(std::fabs(meter - gr) < 1.0f, "meter %.2f vs GR %.2f", meter, gr);
    CHECK(std::fabs(orr[N-100] - ol[N-100]) < 1e-6f, "L/R identical for mono input");

    // 1b) live meter: host is told about GR changes, throttled to ~15/s, and the value matches
    meterCalls = 0; select(0); setNorm(4, 0.f); makeSine(l, r, 0.5f); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
    std::printf("meter updates sent in 1 s: %d, last %.2f dB\n", meterCalls, lastAutomate[15] * 30.f);
    CHECK(meterCalls >= 1 && meterCalls <= 16, "meter update rate %d", meterCalls);
    CHECK(std::fabs(lastAutomate[15] * 30.f - gr) < 0.5f, "meter value sent to host matches GR");
    meterCalls = 0; proc(l, r, ol, orr);
    CHECK(meterCalls <= 2, "steady GR sends (almost) nothing: %d", meterCalls);

    // 2) Below threshold => transparent (input -30 dB)
    makeSine(l, r, 0.03f);
    D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
    CHECK(std::fabs(db(peakOf(ol, N/2)) - db(peakOf(l, N/2))) < 0.3f, "below-threshold transparency");

    // 3) Mix = 0 => dry; Bypass => bit-exact dry
    makeSine(l, r, 0.7f); select(0); setNorm(6, 0.f);
    proc(l, r, ol, orr);
    CHECK(std::fabs(db(peakOf(ol, N/2)) - db(peakOf(l, N/2))) < 0.1f, "mix 0 == dry");
    select(0); setNorm(16, 1.f); proc(l, r, ol, orr);
    bool exact = true; for (int i = 0; i < N; ++i) if (ol[i] != l[i]) { exact = false; break; }
    CHECK(exact, "bypass bit-exact");
    setNorm(16, 0.f);

    // 4) Ratio ordering: higher ratio => more GR
    float grs[3];
    for (int k = 0; k < 3; ++k) {
        select(0); setNorm(1, k / 2.f); setNorm(4, 0.f); makeSine(l, r, 0.5f); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
        grs[k] = db(peakOf(l, N/2)) - db(peakOf(ol, N/2));
    }
    std::printf("GR by ratio 2/4/10: %.2f %.2f %.2f dB\n", grs[0], grs[1], grs[2]);
    CHECK(grs[0] < grs[1] && grs[1] < grs[2], "ratio ordering");

    // 5) Attack: a burst after silence; slow attack lets more of the first ms through
    float firstPeak[2];
    for (int k = 0; k < 2; ++k) {
        select(0); setNorm(1, 1.f); setNorm(2, k == 0 ? 0.f : 1.f); setNorm(4, 0.f);
        makeSine(l, r, 0.9f, 1000.f, 4410); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
        firstPeak[k] = peakOf(ol, 0) ; std::vector<float> head(ol.begin(), ol.begin() + 441); firstPeak[k] = peakOf(head, 0);
    }
    std::printf("first 10ms peak, atk 0.1ms vs 30ms: %.3f vs %.3f\n", firstPeak[0], firstPeak[1]);
    CHECK(firstPeak[1] > firstPeak[0], "slow attack passes more transient");

    // 6) Auto makeup raises output relative to no makeup
    select(1); setNorm(5, 0.f); makeSine(l, r, 0.5f); D(effMainsChanged, 0, 1); proc(l, r, ol, orr); float noMk = peakOf(ol, N/2);
    select(1); setNorm(5, 1.f); D(effMainsChanged, 0, 1); proc(l, r, ol, orr); float mk = peakOf(ol, N/2);
    CHECK(mk > noMk, "auto makeup");

    // 7) Every preset: finite, bounded output on loud program material; in-place processing works
    for (int p = 0; p < fx->numPrograms; ++p) {
        select(p); D(effMainsChanged, 0, 1);
        makeSine(l, r, 0.95f, 80.f); for (int i = 0; i < N; ++i) r[i] = 0.9f * std::sin(6.2831853f * 3000.f * i / 44100.f);
        std::vector<float> al = l, ar = r;
        float* io[2] = { al.data(), ar.data() };
        for (int pos = 0; pos < N; pos += 256) { float* in[2] = { io[0] + pos, io[1] + pos }; int m = (N - pos) < 256 ? (N - pos) : 256; fx->processReplacing(fx, in, in, m); }
        bool ok = true; float mx = 0; for (int i = 0; i < N; ++i) { if (!std::isfinite(al[i]) || !std::isfinite(ar[i])) ok = false; mx = std::fmax(mx, std::fmax(std::fabs(al[i]), std::fabs(ar[i]))); }
        char nm[64] = {}; D(effGetProgramNameIndexed, p, 0, nm);
        std::printf("preset %-15s finite=%d peak=%.2f\n", nm, ok, mx);
        CHECK(ok && mx < 4.f, "preset %d output sane", p);
    }

    // 8) Silence / denormal-range input never produces NaN and GR returns to 0
    select(0); D(effMainsChanged, 0, 1);
    l.assign(N, 1e-30f); r.assign(N, 0.f); proc(l, r, ol, orr);
    bool fin = true; for (int i = 0; i < N; ++i) if (!std::isfinite(ol[i])) fin = false;
    CHECK(fin, "denormal input finite"); CHECK(getNorm(15) * 30.f < 0.1f, "GR near 0 on silence");

    // 9) Mid/Side mode with mix=0 is an identity
    select(0); setNorm(10, 1.f); setNorm(6, 0.f); makeSine(l, r, 0.5f); for (int i = 0; i < N; ++i) r[i] = -l[i];
    proc(l, r, ol, orr); CHECK(std::fabs(db(peakOf(ol, N/2)) - db(peakOf(l, N/2))) < 0.1f, "M/S dry identity");

    // 10) Legacy accumulating process() adds to the output buffer
    select(0); setNorm(6, 0.f); l.assign(512, 0.25f); r = l; std::vector<float> a(512, 1.f), b(512, 1.f);
    float* in[2] = { l.data(), r.data() }; float* out[2] = { a.data(), b.data() };
    fx->process(fx, in, out, 512); CHECK(std::fabs(a[100] - 1.25f) < 0.01f, "accumulating process %.3f", a[100]);

    // 12) Channel strip: filters, EQ bands, EQ position, gate/expander (compressor off unless noted)
    auto lin = [](int id, float v, float lo, float hi) { setNorm(id, (v - lo) / (hi - lo)); };
    auto lg  = [](int id, float v, float lo, float hi) { setNorm(id, std::log(v / lo) / std::log(hi / lo)); };
    auto gainAt = [&](float hz, float amp) {
        makeSine(l, r, amp, hz); D(effMainsChanged, 0, 1); proc(l, r, ol, orr);
        return db(peakOf(ol, N * 9 / 10)) - db(peakOf(l, N * 9 / 10));   // settled tail
    };
    auto fresh = [&]() { select(0); setNorm(36, 0.f); };   // Init, compressor out

    fresh(); makeSine(l, r, 0.5f); proc(l, r, ol, orr);
    float md = 0; for (int i = 0; i < N; ++i) md = std::fmax(md, std::fabs(ol[i] - l[i]));
    CHECK(md < 1e-7f, "flat channel strip is transparent (max diff %g)", md);

    fresh(); lg(17, 100.f, 16.f, 400.f);
    float h30 = gainAt(30.f, 0.5f), h1k = gainAt(1000.f, 0.5f);
    std::printf("\nHPF 100 Hz: 30 Hz %.1f dB, 1 kHz %.2f dB\n", h30, h1k);
    CHECK(h30 < -30.f && std::fabs(h1k) < 0.1f, "HPF");

    fresh(); lg(18, 2000.f, 1000.f, 22000.f);
    float l8k = gainAt(8000.f, 0.5f), l200 = gainAt(200.f, 0.5f);
    std::printf("LPF 2 kHz: 8 kHz %.1f dB, 200 Hz %.2f dB\n", l8k, l200);
    CHECK(l8k < -30.f && std::fabs(l200) < 0.1f, "LPF");

    fresh(); lin(19, 6.f, -15.f, 15.f); lg(20, 100.f, 30.f, 450.f);
    float lf = gainAt(30.f, 0.25f); std::printf("LF shelf +6 @100: 30 Hz %.2f dB\n", lf);
    CHECK(lf > 4.5f && lf < 6.5f, "LF shelf");

    fresh(); lin(21, 10.f, -15.f, 15.f); lg(22, 1000.f, 200.f, 2500.f); lin(23, 1.f, 0.5f, 4.f);
    float lm = gainAt(1000.f, 0.1f); std::printf("LMF bell +10 @1k: %.2f dB\n", lm);
    CHECK(std::fabs(lm - 10.f) < 0.5f, "LMF bell");

    fresh(); lin(24, -8.f, -15.f, 15.f); lg(25, 3000.f, 600.f, 7000.f); lin(26, 2.f, 0.5f, 4.f);
    float hm = gainAt(3000.f, 0.5f); std::printf("HMF bell -8 @3k: %.2f dB\n", hm);
    CHECK(std::fabs(hm + 8.f) < 0.5f, "HMF bell");

    fresh(); lin(27, -6.f, -15.f, 15.f); lg(28, 5000.f, 1500.f, 16000.f);
    float hf = gainAt(16000.f, 0.5f); std::printf("HF shelf -6 @5k: 16 kHz %.2f dB\n", hf);
    CHECK(hf < -4.5f && hf > -6.5f, "HF shelf");
    setNorm(29, 0.f); float hfOff = gainAt(16000.f, 0.5f);
    CHECK(std::fabs(hfOff) < 0.05f, "EQ In off bypasses bands (%.2f)", hfOff);

    // gate: -40 dB threshold, 20 dB range
    fresh(); setNorm(35, 1.f); setNorm(34, 1.f); lin(31, -40.f, -80.f, 0.f); lin(32, 20.f, 0.f, 40.f);
    float gLow = gainAt(1000.f, 0.001f), gHigh = gainAt(1000.f, 0.3f);
    std::printf("Gate: -60 dBFS in -> %.1f dB, -10 dBFS in -> %.2f dB\n", gLow, gHigh);
    CHECK(std::fabs(gLow + 20.f) < 1.f && std::fabs(gHigh) < 0.2f, "gate");
    setNorm(34, 0.f);   // expander 2:1
    float eLow = gainAt(1000.f, fromDbT(-50.f));
    std::printf("Expander: -50 dBFS in (thr -40) -> %.1f dB\n", eLow);
    CHECK(std::fabs(eLow + 10.f) < 1.5f, "expander");

    // EQ pre vs post dynamics must differ when the compressor works hard
    select(0); setNorm(1, 1.f); lin(19, 12.f, -15.f, 15.f); lg(20, 100.f, 30.f, 450.f);
    makeSine(l, r, 0.5f, 60.f); D(effMainsChanged, 0, 1); setNorm(30, 0.f); proc(l, r, ol, orr); float pre = peakOf(ol, N/2);
    D(effMainsChanged, 0, 1); setNorm(30, 1.f); proc(l, r, ol, orr); float post = peakOf(ol, N/2);
    std::printf("LF +12 into comp: pre %.2f dB, post %.2f dB\n", db(pre), db(post));
    CHECK(std::fabs(db(pre) - db(post)) > 0.5f, "EQ position changes the result");

    // 11) String sanity
    char s[64] = {}; D(effGetEffectName, 0, 0, s); CHECK(!std::strcmp(s, "GlueBus"), "effect name"); 
    D(effClose);
    std::printf("\n%s (%d failure%s)\n", fails ? "TESTS FAILED" : "ALL TESTS PASSED", fails, fails == 1 ? "" : "s");
    return fails ? 1 : 0;
}
